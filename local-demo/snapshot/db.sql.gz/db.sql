/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ojs
-- ------------------------------------------------------
-- Server version	11.4.13-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `announcement_settings`
--

DROP TABLE IF EXISTS `announcement_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_settings` (
  `announcement_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`announcement_setting_id`),
  UNIQUE KEY `announcement_settings_unique` (`announcement_id`,`locale`,`setting_name`),
  KEY `announcement_settings_announcement_id` (`announcement_id`),
  CONSTRAINT `announcement_settings_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`announcement_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about announcements, including localized properties like names and contents.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_settings`
--

LOCK TABLES `announcement_settings` WRITE;
/*!40000 ALTER TABLE `announcement_settings` DISABLE KEYS */;
INSERT INTO `announcement_settings` VALUES
(1,1,'en','title','Call for papers: Heat stress and animal welfare'),
(2,1,'en','descriptionShort','<p>We invite submissions for a thematic collection on climate, heat stress and animal welfare. Deadline: 31 December 2026.</p>'),
(3,1,'en','description','<p>We invite submissions for a thematic collection on climate, heat stress and animal welfare. Deadline: 31 December 2026.</p>'),
(4,2,'en','title','The journal is now accepting submissions'),
(5,2,'en','descriptionShort','<p>Our online submission system is open. Please read the Author Guidelines before submitting your manuscript.</p>'),
(6,2,'en','description','<p>Our online submission system is open. Please read the Author Guidelines before submitting your manuscript.</p>');
/*!40000 ALTER TABLE `announcement_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_type_settings`
--

DROP TABLE IF EXISTS `announcement_type_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_type_settings` (
  `announcement_type_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`announcement_type_setting_id`),
  UNIQUE KEY `announcement_type_settings_unique` (`type_id`,`locale`,`setting_name`),
  KEY `announcement_type_settings_type_id` (`type_id`),
  CONSTRAINT `announcement_type_settings_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `announcement_types` (`type_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about announcement types, including localized properties like their names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_type_settings`
--

LOCK TABLES `announcement_type_settings` WRITE;
/*!40000 ALTER TABLE `announcement_type_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement_type_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_types`
--

DROP TABLE IF EXISTS `announcement_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_types` (
  `type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`type_id`),
  KEY `announcement_types_context_id` (`context_id`),
  CONSTRAINT `announcement_types_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Announcement types allow for announcements to optionally be categorized.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_types`
--

LOCK TABLES `announcement_types` WRITE;
/*!40000 ALTER TABLE `announcement_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `announcement_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `assoc_type` smallint(6) DEFAULT NULL,
  `assoc_id` bigint(20) DEFAULT NULL,
  `type_id` bigint(20) DEFAULT NULL,
  `date_expire` date DEFAULT NULL,
  `date_posted` datetime NOT NULL,
  PRIMARY KEY (`announcement_id`),
  KEY `announcements_type_id` (`type_id`),
  KEY `announcements_assoc` (`assoc_type`,`assoc_id`),
  CONSTRAINT `announcements_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `announcement_types` (`type_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Announcements are messages that can be presented to users e.g. on the homepage.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES
(1,256,1,NULL,NULL,'2026-09-25 16:09:35'),
(2,256,1,NULL,NULL,'2026-09-25 16:09:35');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `author_affiliation_settings`
--

DROP TABLE IF EXISTS `author_affiliation_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `author_affiliation_settings` (
  `author_affiliation_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `author_affiliation_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`author_affiliation_setting_id`),
  UNIQUE KEY `author_affiliation_settings_unique` (`author_affiliation_id`,`locale`,`setting_name`),
  CONSTRAINT `author_affiliation_settings_author_affiliation_id_foreign` FOREIGN KEY (`author_affiliation_id`) REFERENCES `author_affiliations` (`author_affiliation_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about author affiliations';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author_affiliation_settings`
--

LOCK TABLES `author_affiliation_settings` WRITE;
/*!40000 ALTER TABLE `author_affiliation_settings` DISABLE KEYS */;
INSERT INTO `author_affiliation_settings` VALUES
(1,1,'en','name','Department of Animal Science, Northfield University'),
(2,2,'en','name','Institute of Poultry Research, Eastbrook College'),
(3,3,'en','name','Department of Animal Science, Northfield University'),
(4,4,'en','name','Faculty of Veterinary Medicine, Northfield University'),
(5,5,'en','name','Department of Clinical Studies, Riverside Veterinary School'),
(6,6,'en','name','Centre for Animal Welfare, Eastbrook College'),
(7,7,'en','name','Faculty of Veterinary Medicine, Northfield University'),
(8,8,'en','name','Department of Surgery, Riverside Veterinary School'),
(9,9,'en','name','Department of Surgery, Riverside Veterinary School'),
(10,10,'en','name','Faculty of Veterinary Medicine, Northfield University'),
(11,11,'en','name','Department of Animal Science, Northfield University'),
(12,12,'en','name','Department of Surgery, Riverside Veterinary School'),
(13,13,'en','name','Institute of Animal Physiology, Eastbrook College'),
(14,14,'en','name','Department of Animal Science, Northfield University'),
(15,15,'en','name','Department of Microbiology, Northfield University'),
(16,16,'en','name','Institute of Veterinary Public Health, Eastbrook College'),
(17,17,'en','name','Laboratory Animal Centre, Northfield University'),
(18,18,'en','name','Laboratory Animal Centre, Northfield University'),
(19,19,'en','name','Small Animal Teaching Hospital, Riverside Veterinary School'),
(20,20,'en','name','Department of Animal Science, Northfield University'),
(21,21,'en','name','School of Computing, Eastbrook College'),
(22,22,'en','name','Centre for Sustainable Livestock, Westmoor University'),
(23,23,'en','name','Department of Animal Nutrition, Lakeside Agricultural College'),
(24,24,'en','name','Department of Microbiology, Northfield University'),
(25,25,'en','name','State Veterinary Diagnostic Laboratory'),
(26,26,'en','name','Riverside Veterinary School');
/*!40000 ALTER TABLE `author_affiliation_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `author_affiliations`
--

DROP TABLE IF EXISTS `author_affiliations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `author_affiliations` (
  `author_affiliation_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `author_id` bigint(20) NOT NULL,
  `ror` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`author_affiliation_id`),
  KEY `author_affiliations_ror` (`ror`),
  KEY `author_affiliations_author_id_foreign` (`author_id`),
  CONSTRAINT `author_affiliations_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `authors` (`author_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Author affiliations';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author_affiliations`
--

LOCK TABLES `author_affiliations` WRITE;
/*!40000 ALTER TABLE `author_affiliations` DISABLE KEYS */;
INSERT INTO `author_affiliations` VALUES
(1,1,NULL),
(2,2,NULL),
(3,3,NULL),
(4,4,NULL),
(5,5,NULL),
(6,6,NULL),
(7,7,NULL),
(8,8,NULL),
(9,9,NULL),
(10,10,NULL),
(11,11,NULL),
(12,12,NULL),
(13,13,NULL),
(14,14,NULL),
(15,15,NULL),
(16,16,NULL),
(17,17,NULL),
(18,18,NULL),
(19,19,NULL),
(20,20,NULL),
(21,21,NULL),
(22,22,NULL),
(23,23,NULL),
(24,24,NULL),
(25,25,NULL),
(26,26,NULL);
/*!40000 ALTER TABLE `author_affiliations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `author_settings`
--

DROP TABLE IF EXISTS `author_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `author_settings` (
  `author_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`author_setting_id`),
  UNIQUE KEY `author_settings_unique` (`author_id`,`locale`,`setting_name`),
  KEY `author_settings_author_id` (`author_id`),
  CONSTRAINT `author_settings_author_id` FOREIGN KEY (`author_id`) REFERENCES `authors` (`author_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about authors, including localized properties such as their name and affiliation.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author_settings`
--

LOCK TABLES `author_settings` WRITE;
/*!40000 ALTER TABLE `author_settings` DISABLE KEYS */;
INSERT INTO `author_settings` VALUES
(1,1,'en','biography','<p>Emily Carter is an assistant professor of poultry nutrition whose work focuses on feed additives and gut health.</p>'),
(2,1,'','country','GB'),
(3,1,'en','familyName','Carter'),
(4,1,'en','givenName','Emily'),
(5,2,'','country','GB'),
(6,2,'en','familyName','Hughes'),
(7,2,'en','givenName','Daniel'),
(8,3,'','country','IE'),
(9,3,'en','familyName','Morgan'),
(10,3,'en','givenName','Rachel'),
(11,4,'','country','GB'),
(12,4,'en','familyName','Collins'),
(13,4,'en','givenName','Andrew'),
(14,5,'','country','US'),
(15,5,'en','familyName','Whitfield'),
(16,5,'en','givenName','Grace'),
(17,6,'','country','GB'),
(18,6,'en','familyName','Bennett'),
(19,6,'en','givenName','Sophie'),
(20,7,'','country','US'),
(21,7,'en','familyName','Hayes'),
(22,7,'en','givenName','Robert'),
(23,8,'en','biography','<p>Josiah Carberry is ORCID’s fictitious test researcher, used here to demonstrate the ORCID badge.</p>'),
(24,8,'','country','US'),
(25,8,'en','familyName','Carberry'),
(26,8,'en','givenName','Josiah'),
(27,8,'','orcid','https://orcid.org/0000-0002-1825-0097'),
(28,9,'','country','CA'),
(29,9,'en','familyName','Brooks'),
(30,9,'en','givenName','Hannah'),
(31,10,'','country','GB'),
(32,10,'en','familyName','Reed'),
(33,10,'en','givenName','Oliver'),
(34,11,'en','biography','<p>Sarah Mitchell is an associate professor of dairy science. Her research examines how climate affects the nutrition, health and productivity of dairy cattle.</p>'),
(35,11,'','country','GB'),
(36,11,'en','familyName','Mitchell'),
(37,11,'en','givenName','Sarah'),
(38,12,'','country','US'),
(39,12,'en','familyName','Carberry'),
(40,12,'en','givenName','Josiah'),
(41,12,'','orcid','https://orcid.org/0000-0002-1825-0097'),
(42,13,'','country','GB'),
(43,13,'en','familyName','Price'),
(44,13,'en','givenName','Eleanor'),
(45,14,'','country','AU'),
(46,14,'en','familyName','Jenkins'),
(47,14,'en','givenName','Matthew'),
(48,15,'','country','US'),
(49,15,'en','familyName','Foster'),
(50,15,'en','givenName','Natalie'),
(51,16,'','country','GB'),
(52,16,'en','familyName','Walker'),
(53,16,'en','givenName','Thomas'),
(54,17,'','country','NZ'),
(55,17,'en','familyName','Turner'),
(56,17,'en','givenName','Alexander'),
(57,18,'','country','IE'),
(58,18,'en','familyName','Donovan'),
(59,18,'en','givenName','Claire'),
(60,19,'','country','CA'),
(61,19,'en','familyName','Adams'),
(62,19,'en','givenName','Katherine'),
(63,20,'','country','GB'),
(64,20,'en','familyName','Mitchell'),
(65,20,'en','givenName','Sarah'),
(66,21,'','country','GB'),
(67,21,'en','familyName','Walker'),
(68,21,'en','givenName','Thomas'),
(69,22,'','country','GB'),
(70,22,'en','familyName','Reed'),
(71,22,'en','givenName','Oliver'),
(72,23,'','country','CA'),
(73,23,'en','familyName','Brooks'),
(74,23,'en','givenName','Hannah'),
(75,24,'','country','US'),
(76,24,'en','familyName','Foster'),
(77,24,'en','givenName','Natalie'),
(78,25,'','country','US'),
(79,25,'en','familyName','Hayes'),
(80,25,'en','givenName','Robert'),
(81,26,'','country','IE'),
(82,26,'en','familyName','Donovan'),
(83,26,'en','givenName','Claire');
/*!40000 ALTER TABLE `author_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `authors` (
  `author_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(90) NOT NULL,
  `include_in_browse` smallint(6) NOT NULL DEFAULT 1,
  `publication_id` bigint(20) NOT NULL,
  `seq` double NOT NULL DEFAULT 0,
  `user_group_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`author_id`),
  KEY `authors_user_group_id` (`user_group_id`),
  KEY `authors_publication_id` (`publication_id`),
  CONSTRAINT `authors_publication_id_foreign` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE,
  CONSTRAINT `authors_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='The authors of a publication.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES
(1,'emily.carter@example.org',1,1,0,14),
(2,'daniel.hughes@example.org',1,1,1,14),
(3,'rachel.morgan@example.org',1,1,2,14),
(4,'andrew.collins@example.org',1,2,0,14),
(5,'grace.whitfield@example.org',1,2,1,14),
(6,'sophie.bennett@example.org',1,3,0,14),
(7,'robert.hayes@example.org',1,3,1,14),
(8,'josiah.carberry@example.org',1,4,0,14),
(9,'hannah.brooks@example.org',1,4,1,14),
(10,'oliver.reed@example.org',1,4,2,14),
(11,'sarah.mitchell@example.org',1,5,0,14),
(12,'josiah.carberry@example.org',1,5,1,14),
(13,'eleanor.price@example.org',1,5,2,14),
(14,'matthew.jenkins@example.org',1,5,3,14),
(15,'natalie.foster@example.org',1,6,0,14),
(16,'thomas.walker@example.org',1,6,1,14),
(17,'alexander.turner@example.org',1,7,0,14),
(18,'claire.donovan@example.org',1,7,1,14),
(19,'katherine.adams@example.org',1,8,0,14),
(20,'sarah.mitchell@example.org',1,9,0,14),
(21,'thomas.walker@example.org',1,9,1,14),
(22,'oliver.reed@example.org',1,10,0,14),
(23,'hannah.brooks@example.org',1,10,1,14),
(24,'natalie.foster@example.org',1,11,0,14),
(25,'robert.hayes@example.org',1,11,1,14),
(26,'claire.donovan@example.org',1,12,0,14);
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `category_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `seq` bigint(20) DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `image` text DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_path` (`context_id`,`path`),
  KEY `category_context_id` (`context_id`),
  KEY `category_context_parent_id` (`context_id`,`parent_id`),
  KEY `category_parent_id` (`parent_id`),
  CONSTRAINT `categories_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Categories permit the organization of submissions into a heirarchical structure.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_settings`
--

DROP TABLE IF EXISTS `category_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_settings` (
  `category_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`category_setting_id`),
  UNIQUE KEY `category_settings_unique` (`category_id`,`locale`,`setting_name`),
  KEY `category_settings_category_id` (`category_id`),
  CONSTRAINT `category_settings_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about categories, including localized properties such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_settings`
--

LOCK TABLES `category_settings` WRITE;
/*!40000 ALTER TABLE `category_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citation_settings`
--

DROP TABLE IF EXISTS `citation_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `citation_settings` (
  `citation_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `citation_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`citation_setting_id`),
  UNIQUE KEY `citation_settings_unique` (`citation_id`,`locale`,`setting_name`),
  KEY `citation_settings_citation_id` (`citation_id`),
  CONSTRAINT `citation_settings_citation_id` FOREIGN KEY (`citation_id`) REFERENCES `citations` (`citation_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Additional data about citations, including localized content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citation_settings`
--

LOCK TABLES `citation_settings` WRITE;
/*!40000 ALTER TABLE `citation_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `citation_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citations`
--

DROP TABLE IF EXISTS `citations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `citations` (
  `citation_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `publication_id` bigint(20) NOT NULL,
  `raw_citation` text NOT NULL,
  `seq` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`citation_id`),
  UNIQUE KEY `citations_publication_seq` (`publication_id`,`seq`),
  KEY `citations_publication` (`publication_id`),
  CONSTRAINT `citations_publication` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A citation made by an associated publication.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citations`
--

LOCK TABLES `citations` WRITE;
/*!40000 ALTER TABLE `citations` DISABLE KEYS */;
INSERT INTO `citations` VALUES
(1,1,'Percie du Sert N, Hurst V, Ahluwalia A, Alam S, Avey MT, Baker M, et al. The ARRIVE guidelines 2.0: updated guidelines for reporting animal research. PLoS Biol. 2020;18(7):e3000410. https://doi.org/10.1371/journal.pbio.3000410',1),
(2,1,'Festing MFW, Altman DG. Guidelines for the design and statistical analysis of experiments using laboratory animals. ILAR J. 2002;43(4):244–258. https://doi.org/10.1093/ilar.43.4.244',2),
(3,1,'Faul F, Erdfelder E, Lang AG, Buchner A. G*Power 3: a flexible statistical power analysis program for the social, behavioral, and biomedical sciences. Behav Res Methods. 2007;39(2):175–191. https://doi.org/10.3758/BF03193146',3),
(4,1,'Bates D, Mächler M, Bolker B, Walker S. Fitting linear mixed-effects models using lme4. J Stat Softw. 2015;67(1):1–48. https://doi.org/10.18637/jss.v067.i01',4),
(5,1,'Schneider CA, Rasband WS, Eliceiri KW. NIH Image to ImageJ: 25 years of image analysis. Nat Methods. 2012;9(7):671–675. https://doi.org/10.1038/nmeth.2089',5),
(6,1,'R Core Team. R: A language and environment for statistical computing. Vienna: R Foundation for Statistical Computing; 2025. https://www.R-project.org/',6),
(7,2,'Landis JR, Koch GG. The measurement of observer agreement for categorical data. Biometrics. 1977;33(1):159–174. https://doi.org/10.2307/2529310',1),
(8,2,'Bates D, Mächler M, Bolker B, Walker S. Fitting linear mixed-effects models using lme4. J Stat Softw. 2015;67(1):1–48. https://doi.org/10.18637/jss.v067.i01',2),
(9,2,'Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc Series B Stat Methodol. 1995;57(1):289–300. https://doi.org/10.1111/j.2517-6161.1995.tb02031.x',3),
(10,2,'R Core Team. R: A language and environment for statistical computing. Vienna: R Foundation for Statistical Computing; 2025. https://www.R-project.org/',4),
(11,3,'Landis JR, Koch GG. The measurement of observer agreement for categorical data. Biometrics. 1977;33(1):159–174. https://doi.org/10.2307/2529310',1),
(12,3,'Russell WMS, Burch RL. The Principles of Humane Experimental Technique. London: Methuen; 1959.',2),
(13,3,'Kilkenny C, Browne WJ, Cuthill IC, Emerson M, Altman DG. Improving bioscience research reporting: the ARRIVE guidelines for reporting animal research. PLoS Biol. 2010;8(6):e1000412. https://doi.org/10.1371/journal.pbio.1000412',3),
(14,4,'Percie du Sert N, Hurst V, Ahluwalia A, Alam S, Avey MT, Baker M, et al. The ARRIVE guidelines 2.0: updated guidelines for reporting animal research. PLoS Biol. 2020;18(7):e3000410. https://doi.org/10.1371/journal.pbio.3000410',1),
(15,4,'Festing MFW, Altman DG. Guidelines for the design and statistical analysis of experiments using laboratory animals. ILAR J. 2002;43(4):244–258. https://doi.org/10.1093/ilar.43.4.244',2),
(16,4,'Faul F, Erdfelder E, Lang AG, Buchner A. G*Power 3: a flexible statistical power analysis program for the social, behavioral, and biomedical sciences. Behav Res Methods. 2007;39(2):175–191. https://doi.org/10.3758/BF03193146',3),
(17,4,'Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc Series B Stat Methodol. 1995;57(1):289–300. https://doi.org/10.1111/j.2517-6161.1995.tb02031.x',4),
(18,5,'Percie du Sert N, Hurst V, Ahluwalia A, Alam S, Avey MT, Baker M, et al. The ARRIVE guidelines 2.0: updated guidelines for reporting animal research. PLoS Biol. 2020;18(7):e3000410. https://doi.org/10.1371/journal.pbio.3000410',1),
(19,5,'Festing MFW, Altman DG. Guidelines for the design and statistical analysis of experiments using laboratory animals. ILAR J. 2002;43(4):244–258. https://doi.org/10.1093/ilar.43.4.244',2),
(20,5,'Faul F, Erdfelder E, Lang AG, Buchner A. G*Power 3: a flexible statistical power analysis program for the social, behavioral, and biomedical sciences. Behav Res Methods. 2007;39(2):175–191. https://doi.org/10.3758/BF03193146',3),
(21,5,'Bates D, Mächler M, Bolker B, Walker S. Fitting linear mixed-effects models using lme4. J Stat Softw. 2015;67(1):1–48. https://doi.org/10.18637/jss.v067.i01',4),
(22,5,'Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc Series B Stat Methodol. 1995;57(1):289–300. https://doi.org/10.1111/j.2517-6161.1995.tb02031.x',5),
(23,5,'Schneider CA, Rasband WS, Eliceiri KW. NIH Image to ImageJ: 25 years of image analysis. Nat Methods. 2012;9(7):671–675. https://doi.org/10.1038/nmeth.2089',6),
(24,5,'R Core Team. R: A language and environment for statistical computing. Vienna: R Foundation for Statistical Computing; 2025. https://www.R-project.org/',7),
(25,5,'Russell WMS, Burch RL. The Principles of Humane Experimental Technique. London: Methuen; 1959.',8),
(26,6,'Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ. 2021;372:n71. https://doi.org/10.1136/bmj.n71',1),
(27,6,'Hooijmans CR, Rovers MM, de Vries RBM, Leenaars M, Ritskes-Hoitinga M, Langendam MW. SYRCLE’s risk of bias tool for animal studies. BMC Med Res Methodol. 2014;14:43. https://doi.org/10.1186/1471-2288-14-43',2),
(28,6,'Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc Series B Stat Methodol. 1995;57(1):289–300. https://doi.org/10.1111/j.2517-6161.1995.tb02031.x',3),
(29,6,'R Core Team. R: A language and environment for statistical computing. Vienna: R Foundation for Statistical Computing; 2025. https://www.R-project.org/',4),
(30,7,'Russell WMS, Burch RL. The Principles of Humane Experimental Technique. London: Methuen; 1959.',1),
(31,7,'Percie du Sert N, Hurst V, Ahluwalia A, Alam S, Avey MT, Baker M, et al. The ARRIVE guidelines 2.0: updated guidelines for reporting animal research. PLoS Biol. 2020;18(7):e3000410. https://doi.org/10.1371/journal.pbio.3000410',2),
(32,7,'Festing MFW, Altman DG. Guidelines for the design and statistical analysis of experiments using laboratory animals. ILAR J. 2002;43(4):244–258. https://doi.org/10.1093/ilar.43.4.244',3),
(33,8,'Russell WMS, Burch RL. The Principles of Humane Experimental Technique. London: Methuen; 1959.',1);
/*!40000 ALTER TABLE `citations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `completed_payments`
--

DROP TABLE IF EXISTS `completed_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `completed_payments` (
  `completed_payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `payment_type` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `assoc_id` bigint(20) DEFAULT NULL,
  `amount` decimal(8,2) unsigned NOT NULL,
  `currency_code_alpha` varchar(3) DEFAULT NULL,
  `payment_method_plugin_name` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`completed_payment_id`),
  KEY `completed_payments_context_id` (`context_id`),
  KEY `completed_payments_user_id` (`user_id`),
  CONSTRAINT `completed_payments_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `completed_payments_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A list of completed (fulfilled) payments relating to a payment type such as a subscription payment.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `completed_payments`
--

LOCK TABLES `completed_payments` WRITE;
/*!40000 ALTER TABLE `completed_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `completed_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controlled_vocab_entries`
--

DROP TABLE IF EXISTS `controlled_vocab_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `controlled_vocab_entries` (
  `controlled_vocab_entry_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `controlled_vocab_id` bigint(20) NOT NULL,
  `seq` double DEFAULT NULL,
  PRIMARY KEY (`controlled_vocab_entry_id`),
  KEY `controlled_vocab_entries_controlled_vocab_id` (`controlled_vocab_id`),
  KEY `controlled_vocab_entries_cv_id` (`controlled_vocab_id`,`seq`),
  CONSTRAINT `controlled_vocab_entries_controlled_vocab_id_foreign` FOREIGN KEY (`controlled_vocab_id`) REFERENCES `controlled_vocabs` (`controlled_vocab_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='The order that a word or phrase used in a controlled vocabulary should appear. For example, the order of keywords in a publication.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controlled_vocab_entries`
--

LOCK TABLES `controlled_vocab_entries` WRITE;
/*!40000 ALTER TABLE `controlled_vocab_entries` DISABLE KEYS */;
INSERT INTO `controlled_vocab_entries` VALUES
(6,1,1),
(7,1,2),
(8,1,3),
(9,1,4),
(10,1,5),
(16,5,1),
(17,5,2),
(18,5,3),
(19,5,4),
(20,5,5),
(25,9,1),
(26,9,2),
(27,9,3),
(28,9,4),
(34,13,1),
(35,13,2),
(36,13,3),
(37,13,4),
(38,13,5),
(45,17,1),
(46,17,2),
(47,17,3),
(48,17,4),
(49,17,5),
(50,17,6),
(57,21,1),
(58,21,2),
(59,21,3),
(60,21,4),
(61,21,5),
(62,21,6),
(68,25,1),
(69,25,2),
(70,25,3),
(71,25,4),
(72,25,5),
(77,29,1),
(78,29,2),
(79,29,3),
(80,29,4),
(86,33,1),
(87,33,2),
(88,33,3),
(89,33,4),
(90,33,5),
(96,37,1),
(97,37,2),
(98,37,3),
(99,37,4),
(100,37,5),
(105,41,1),
(106,41,2),
(107,41,3),
(108,41,4),
(113,45,1),
(114,45,2),
(115,45,3),
(116,45,4);
/*!40000 ALTER TABLE `controlled_vocab_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controlled_vocab_entry_settings`
--

DROP TABLE IF EXISTS `controlled_vocab_entry_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `controlled_vocab_entry_settings` (
  `controlled_vocab_entry_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `controlled_vocab_entry_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`controlled_vocab_entry_setting_id`),
  UNIQUE KEY `c_v_e_s_pkey` (`controlled_vocab_entry_id`,`locale`,`setting_name`),
  KEY `c_v_e_s_entry_id` (`controlled_vocab_entry_id`),
  CONSTRAINT `c_v_e_s_entry_id` FOREIGN KEY (`controlled_vocab_entry_id`) REFERENCES `controlled_vocab_entries` (`controlled_vocab_entry_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about a controlled vocabulary entry, including localized properties such as the actual word or phrase.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controlled_vocab_entry_settings`
--

LOCK TABLES `controlled_vocab_entry_settings` WRITE;
/*!40000 ALTER TABLE `controlled_vocab_entry_settings` DISABLE KEYS */;
INSERT INTO `controlled_vocab_entry_settings` VALUES
(6,6,'en','name','broiler'),
(7,7,'en','name','probiotic'),
(8,8,'en','name','Bacillus subtilis'),
(9,9,'en','name','villus height'),
(10,10,'en','name','feed conversion ratio'),
(16,16,'en','name','dairy cattle'),
(17,17,'en','name','subclinical mastitis'),
(18,18,'en','name','California mastitis test'),
(19,19,'en','name','risk factors'),
(20,20,'en','name','smallholder'),
(25,25,'en','name','animal welfare'),
(26,26,'en','name','donkey'),
(27,27,'en','name','working equids'),
(28,28,'en','name','body condition score'),
(34,34,'en','name','feline'),
(35,35,'en','name','anaesthesia'),
(36,36,'en','name','alfaxalone'),
(37,37,'en','name','propofol'),
(38,38,'en','name','ovariohysterectomy'),
(45,45,'en','name','heat stress'),
(46,46,'en','name','dairy cow'),
(47,47,'en','name','rumen fermentation'),
(48,48,'en','name','temperature–humidity index'),
(49,49,'en','name','milk yield'),
(50,50,'en','name','volatile fatty acids'),
(57,57,'en','name','antimicrobial resistance'),
(58,58,'en','name','dogs'),
(59,59,'en','name','cats'),
(60,60,'en','name','surveillance'),
(61,61,'en','name','systematic review'),
(62,62,'en','name','One Health'),
(68,68,'en','name','laboratory animals'),
(69,69,'en','name','rabbit'),
(70,70,'en','name','reference intervals'),
(71,71,'en','name','clinical biochemistry'),
(72,72,'en','name','environmental enrichment'),
(77,77,'en','name','dog'),
(78,78,'en','name','gastric dilatation–volvulus'),
(79,79,'en','name','gastropexy'),
(80,80,'en','name','emergency surgery'),
(86,86,'en','name','lameness'),
(87,87,'en','name','dairy cow'),
(88,88,'en','name','accelerometer'),
(89,89,'en','name','machine learning'),
(90,90,'en','name','precision livestock farming'),
(96,96,'en','name','methane'),
(97,97,'en','name','sheep'),
(98,98,'en','name','seaweed'),
(99,99,'en','name','Asparagopsis'),
(100,100,'en','name','grazing'),
(105,105,'en','name','Toxoplasma gondii'),
(106,106,'en','name','chickens'),
(107,107,'en','name','seroprevalence'),
(108,108,'en','name','One Health'),
(113,113,'en','name','alpaca'),
(114,114,'en','name','portosystemic shunt'),
(115,115,'en','name','camelid surgery'),
(116,116,'en','name','case report');
/*!40000 ALTER TABLE `controlled_vocab_entry_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controlled_vocabs`
--

DROP TABLE IF EXISTS `controlled_vocabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `controlled_vocabs` (
  `controlled_vocab_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `symbolic` varchar(64) NOT NULL,
  `assoc_type` bigint(20) NOT NULL DEFAULT 0,
  `assoc_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`controlled_vocab_id`),
  UNIQUE KEY `controlled_vocab_symbolic` (`symbolic`,`assoc_type`,`assoc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Every word or phrase used in a controlled vocabulary. Controlled vocabularies are used for submission metadata like keywords and subjects, reviewer interests, and wherever a similar dictionary of words or phrases is required. Each entry corresponds to a word or phrase like "cellular reproduction" and a type like "submissionKeyword".';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controlled_vocabs`
--

LOCK TABLES `controlled_vocabs` WRITE;
/*!40000 ALTER TABLE `controlled_vocabs` DISABLE KEYS */;
INSERT INTO `controlled_vocabs` VALUES
(4,'submissionAgency',1048588,1),
(8,'submissionAgency',1048588,2),
(12,'submissionAgency',1048588,3),
(16,'submissionAgency',1048588,4),
(20,'submissionAgency',1048588,5),
(24,'submissionAgency',1048588,6),
(28,'submissionAgency',1048588,7),
(32,'submissionAgency',1048588,8),
(36,'submissionAgency',1048588,9),
(40,'submissionAgency',1048588,10),
(44,'submissionAgency',1048588,11),
(48,'submissionAgency',1048588,12),
(3,'submissionDiscipline',1048588,1),
(7,'submissionDiscipline',1048588,2),
(11,'submissionDiscipline',1048588,3),
(15,'submissionDiscipline',1048588,4),
(19,'submissionDiscipline',1048588,5),
(23,'submissionDiscipline',1048588,6),
(27,'submissionDiscipline',1048588,7),
(31,'submissionDiscipline',1048588,8),
(35,'submissionDiscipline',1048588,9),
(39,'submissionDiscipline',1048588,10),
(43,'submissionDiscipline',1048588,11),
(47,'submissionDiscipline',1048588,12),
(1,'submissionKeyword',1048588,1),
(5,'submissionKeyword',1048588,2),
(9,'submissionKeyword',1048588,3),
(13,'submissionKeyword',1048588,4),
(17,'submissionKeyword',1048588,5),
(21,'submissionKeyword',1048588,6),
(25,'submissionKeyword',1048588,7),
(29,'submissionKeyword',1048588,8),
(33,'submissionKeyword',1048588,9),
(37,'submissionKeyword',1048588,10),
(41,'submissionKeyword',1048588,11),
(45,'submissionKeyword',1048588,12),
(2,'submissionSubject',1048588,1),
(6,'submissionSubject',1048588,2),
(10,'submissionSubject',1048588,3),
(14,'submissionSubject',1048588,4),
(18,'submissionSubject',1048588,5),
(22,'submissionSubject',1048588,6),
(26,'submissionSubject',1048588,7),
(30,'submissionSubject',1048588,8),
(34,'submissionSubject',1048588,9),
(38,'submissionSubject',1048588,10),
(42,'submissionSubject',1048588,11),
(46,'submissionSubject',1048588,12);
/*!40000 ALTER TABLE `controlled_vocabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_issue_orders`
--

DROP TABLE IF EXISTS `custom_issue_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_issue_orders` (
  `custom_issue_order_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(20) NOT NULL,
  `journal_id` bigint(20) NOT NULL,
  `seq` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`custom_issue_order_id`),
  UNIQUE KEY `custom_issue_orders_unique` (`issue_id`),
  KEY `custom_issue_orders_issue_id` (`issue_id`),
  KEY `custom_issue_orders_journal_id` (`journal_id`),
  CONSTRAINT `custom_issue_orders_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE,
  CONSTRAINT `custom_issue_orders_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Ordering information for the issue list, when custom issue ordering is specified.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_issue_orders`
--

LOCK TABLES `custom_issue_orders` WRITE;
/*!40000 ALTER TABLE `custom_issue_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_issue_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_section_orders`
--

DROP TABLE IF EXISTS `custom_section_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_section_orders` (
  `custom_section_order_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(20) NOT NULL,
  `section_id` bigint(20) NOT NULL,
  `seq` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`custom_section_order_id`),
  UNIQUE KEY `custom_section_orders_unique` (`issue_id`,`section_id`),
  KEY `custom_section_orders_issue_id` (`issue_id`),
  KEY `custom_section_orders_section_id` (`section_id`),
  CONSTRAINT `custom_section_orders_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE,
  CONSTRAINT `custom_section_orders_section_id` FOREIGN KEY (`section_id`) REFERENCES `sections` (`section_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Ordering information for sections within issues, when issue-specific section ordering is specified.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_section_orders`
--

LOCK TABLES `custom_section_orders` WRITE;
/*!40000 ALTER TABLE `custom_section_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_section_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_object_tombstone_oai_set_objects`
--

DROP TABLE IF EXISTS `data_object_tombstone_oai_set_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_object_tombstone_oai_set_objects` (
  `object_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tombstone_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  PRIMARY KEY (`object_id`),
  KEY `data_object_tombstone_oai_set_objects_tombstone_id` (`tombstone_id`),
  CONSTRAINT `data_object_tombstone_oai_set_objects_tombstone_id` FOREIGN KEY (`tombstone_id`) REFERENCES `data_object_tombstones` (`tombstone_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Relationships between tombstones and other data that can be collected in OAI sets, e.g. sections.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_object_tombstone_oai_set_objects`
--

LOCK TABLES `data_object_tombstone_oai_set_objects` WRITE;
/*!40000 ALTER TABLE `data_object_tombstone_oai_set_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_object_tombstone_oai_set_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_object_tombstone_settings`
--

DROP TABLE IF EXISTS `data_object_tombstone_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_object_tombstone_settings` (
  `tombstone_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tombstone_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`tombstone_setting_id`),
  UNIQUE KEY `data_object_tombstone_settings_unique` (`tombstone_id`,`locale`,`setting_name`),
  KEY `data_object_tombstone_settings_tombstone_id` (`tombstone_id`),
  CONSTRAINT `data_object_tombstone_settings_tombstone_id` FOREIGN KEY (`tombstone_id`) REFERENCES `data_object_tombstones` (`tombstone_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about data object tombstones, including localized content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_object_tombstone_settings`
--

LOCK TABLES `data_object_tombstone_settings` WRITE;
/*!40000 ALTER TABLE `data_object_tombstone_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_object_tombstone_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_object_tombstones`
--

DROP TABLE IF EXISTS `data_object_tombstones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_object_tombstones` (
  `tombstone_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data_object_id` bigint(20) NOT NULL,
  `date_deleted` datetime NOT NULL,
  `set_spec` varchar(255) NOT NULL,
  `set_name` varchar(255) NOT NULL,
  `oai_identifier` varchar(255) NOT NULL,
  PRIMARY KEY (`tombstone_id`),
  KEY `data_object_tombstones_data_object_id` (`data_object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Entries for published data that has been removed. Usually used in the OAI endpoint.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_object_tombstones`
--

LOCK TABLES `data_object_tombstones` WRITE;
/*!40000 ALTER TABLE `data_object_tombstones` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_object_tombstones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doi_settings`
--

DROP TABLE IF EXISTS `doi_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doi_settings` (
  `doi_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doi_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`doi_setting_id`),
  UNIQUE KEY `doi_settings_unique` (`doi_id`,`locale`,`setting_name`),
  KEY `doi_settings_doi_id` (`doi_id`),
  CONSTRAINT `doi_settings_doi_id_foreign` FOREIGN KEY (`doi_id`) REFERENCES `dois` (`doi_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about DOIs, including the registration agency.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doi_settings`
--

LOCK TABLES `doi_settings` WRITE;
/*!40000 ALTER TABLE `doi_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `doi_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dois`
--

DROP TABLE IF EXISTS `dois`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dois` (
  `doi_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `doi` varchar(255) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT 1,
  PRIMARY KEY (`doi_id`),
  KEY `dois_context_id` (`context_id`),
  CONSTRAINT `dois_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Stores all DOIs used in the system.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dois`
--

LOCK TABLES `dois` WRITE;
/*!40000 ALTER TABLE `dois` DISABLE KEYS */;
/*!40000 ALTER TABLE `dois` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edit_decisions`
--

DROP TABLE IF EXISTS `edit_decisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `edit_decisions` (
  `edit_decision_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) NOT NULL,
  `review_round_id` bigint(20) DEFAULT NULL,
  `stage_id` bigint(20) DEFAULT NULL,
  `round` smallint(6) DEFAULT NULL,
  `editor_id` bigint(20) NOT NULL,
  `decision` smallint(6) NOT NULL COMMENT 'A numeric constant indicating the decision that was taken. Possible values are listed in the Decision class.',
  `date_decided` datetime NOT NULL,
  PRIMARY KEY (`edit_decision_id`),
  KEY `edit_decisions_submission_id` (`submission_id`),
  KEY `edit_decisions_editor_id` (`editor_id`),
  KEY `edit_decisions_review_round_id` (`review_round_id`),
  CONSTRAINT `edit_decisions_editor_id` FOREIGN KEY (`editor_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `edit_decisions_review_round_id_foreign` FOREIGN KEY (`review_round_id`) REFERENCES `review_rounds` (`review_round_id`) ON DELETE CASCADE,
  CONSTRAINT `edit_decisions_submission_id` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Editorial decisions recorded on a submission, such as decisions to accept or decline the submission, as well as decisions to send for review, send to copyediting, request revisions, and more.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edit_decisions`
--

LOCK TABLES `edit_decisions` WRITE;
/*!40000 ALTER TABLE `edit_decisions` DISABLE KEYS */;
INSERT INTO `edit_decisions` VALUES
(1,10,NULL,1,NULL,1,3,'2026-10-06 21:06:22');
/*!40000 ALTER TABLE `edit_decisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `sender_id` bigint(20) DEFAULT NULL,
  `date_sent` datetime NOT NULL,
  `event_type` bigint(20) DEFAULT NULL,
  `from_address` varchar(255) DEFAULT NULL,
  `recipients` text DEFAULT NULL,
  `cc_recipients` text DEFAULT NULL,
  `bcc_recipients` text DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `body` text DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `email_log_sender_id` (`sender_id`),
  KEY `email_log_assoc` (`assoc_type`,`assoc_id`),
  CONSTRAINT `email_log_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A record of email messages that are sent in relation to an associated entity, such as a submission.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log`
--

LOCK TABLES `email_log` WRITE;
/*!40000 ALTER TABLE `email_log` DISABLE KEYS */;
INSERT INTO `email_log` VALUES
(1,1048585,10,1,'2026-10-06 21:06:52',1073741833,'\"admin admin\" <admin@example.org>','\"Peter Lawson\" <peter.lawson@example.org>','','','Invitation to review','<p>Dear Peter Lawson,</p>\r\n<p>I believe that you would serve as an excellent reviewer for a submission to Demo Journal of Animal Science. The submission\'s title and abstract are below, and I hope that you will consider undertaking this important task for us.</p>\r\n<p>If you are able to review this submission, your review is due by 2026-11-03. You can view the submission, upload review files, and submit your review by logging into the journal site and following the steps at the link below.</p>\r\n<p><a href=\"http://localhost:8080/djas/reviewer/submission?submissionId=10\">Dietary seaweed supplementation and enteric methane emissions in grazing sheep</a></p>\r\n<p><strong>Abstract</strong></p>\r\n<p>We measured enteric methane in 48 grazing ewes receiving 0%, 0.5% or 1% dietary <em>Asparagopsis</em> for 60 days. Methane yield fell by 31% at the highest inclusion rate without affecting live weight gain.</p>\r\n<p>Please <a href=\"http://localhost:8080/djas/reviewer/submission?submissionId=10\">accept or decline</a> the review by <strong>2026-11-03</strong>.</p>\r\n<p>You may contact me with any questions about the submission or the review process.</p>\r\n<p>Thank you for considering this request. Your help is much appreciated.</p>\r\n<p>Kind regards,</p>\r\n<p>admin admin</p>'),
(2,1048585,10,1,'2026-10-06 21:07:04',1073741833,'\"admin admin\" <admin@example.org>','\"Helen Carter\" <helen.carter@example.org>','','','Invitation to review','<p>Dear Helen Carter,</p>\r\n<p>I believe that you would serve as an excellent reviewer for a submission to Demo Journal of Animal Science. The submission\'s title and abstract are below, and I hope that you will consider undertaking this important task for us.</p>\r\n<p>If you are able to review this submission, your review is due by 2026-11-03. You can view the submission, upload review files, and submit your review by logging into the journal site and following the steps at the link below.</p>\r\n<p><a href=\"http://localhost:8080/djas/reviewer/submission?submissionId=10\">Dietary seaweed supplementation and enteric methane emissions in grazing sheep</a></p>\r\n<p><strong>Abstract</strong></p>\r\n<p>We measured enteric methane in 48 grazing ewes receiving 0%, 0.5% or 1% dietary <em>Asparagopsis</em> for 60 days. Methane yield fell by 31% at the highest inclusion rate without affecting live weight gain.</p>\r\n<p>Please <a href=\"http://localhost:8080/djas/reviewer/submission?submissionId=10\">accept or decline</a> the review by <strong>2026-11-03</strong>.</p>\r\n<p>You may contact me with any questions about the submission or the review process.</p>\r\n<p>Thank you for considering this request. Your help is much appreciated.</p>\r\n<p>Kind regards,</p>\r\n<p>admin admin</p>'),
(3,1048585,10,212,'2026-10-06 21:08:52',1073741830,'\"Helen Carter\" <helen.carter@example.org>','\"Editorial Office\" <editor@example.org>','','','Unable to Review','<p><strong>Reason for declining:</strong> It is outside my area of expertise</p><p><strong>Comments to the editor:</strong><br>The manuscript focuses on rumen microbiology, which is outside my area. Dr Ahmed and Dr Novak work on methane mitigation in small ruminants and would be well placed to review it.</p><p><strong>Suggested alternative reviewers:</strong></p><ul><li>Samir Ahmed &lt;samir.ahmed@example.org&gt;, Institute of Animal Science, Eastbrook College</li><li>Laura Novak &lt;laura.novak@example.org&gt;, Faculty of Agriculture, Southgate University</li></ul><hr>Editors:<br />\r\n<br />\r\nI am afraid that at this time I am unable to review the submission, &quot;Dietary seaweed supplementation and enteric methane emissions in grazing sheep,&quot; for Demo Journal of Animal Science. Thank you for thinking of me, and another time feel free to call on me.<br />\r\n<br />\r\nHelen Carter');
/*!40000 ALTER TABLE `email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log_users`
--

DROP TABLE IF EXISTS `email_log_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_log_users` (
  `email_log_user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email_log_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`email_log_user_id`),
  UNIQUE KEY `email_log_user_id` (`email_log_id`,`user_id`),
  KEY `email_log_users_email_log_id` (`email_log_id`),
  KEY `email_log_users_user_id` (`user_id`),
  CONSTRAINT `email_log_users_email_log_id_foreign` FOREIGN KEY (`email_log_id`) REFERENCES `email_log` (`log_id`) ON DELETE CASCADE,
  CONSTRAINT `email_log_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A record of users associated with an email log entry.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log_users`
--

LOCK TABLES `email_log_users` WRITE;
/*!40000 ALTER TABLE `email_log_users` DISABLE KEYS */;
INSERT INTO `email_log_users` VALUES
(1,1,211),
(2,2,212);
/*!40000 ALTER TABLE `email_log_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `email_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email_key` varchar(255) NOT NULL COMMENT 'Unique identifier for this email.',
  `context_id` bigint(20) NOT NULL,
  `alternate_to` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`email_id`),
  UNIQUE KEY `email_templates_email_key` (`email_key`,`context_id`),
  KEY `email_templates_context_id` (`context_id`),
  KEY `email_templates_alternate_to` (`alternate_to`),
  CONSTRAINT `email_templates_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Custom email templates created by each context, and overrides of the default templates.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES
(1,'COPYEDIT_REQUEST',1,'DISCUSSION_NOTIFICATION_COPYEDITING'),
(2,'EDITOR_ASSIGN_SUBMISSION',1,'DISCUSSION_NOTIFICATION_SUBMISSION'),
(3,'EDITOR_ASSIGN_REVIEW',1,'DISCUSSION_NOTIFICATION_REVIEW'),
(4,'EDITOR_ASSIGN_PRODUCTION',1,'DISCUSSION_NOTIFICATION_PRODUCTION'),
(5,'LAYOUT_REQUEST',1,'DISCUSSION_NOTIFICATION_PRODUCTION'),
(6,'LAYOUT_COMPLETE',1,'DISCUSSION_NOTIFICATION_PRODUCTION');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates_default_data`
--

DROP TABLE IF EXISTS `email_templates_default_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates_default_data` (
  `email_templates_default_data_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email_key` varchar(255) NOT NULL COMMENT 'Unique identifier for this email.',
  `locale` varchar(28) NOT NULL DEFAULT 'en',
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text DEFAULT NULL,
  PRIMARY KEY (`email_templates_default_data_id`),
  UNIQUE KEY `email_templates_default_data_unique` (`email_key`,`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Default email templates created for every installed locale.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates_default_data`
--

LOCK TABLES `email_templates_default_data` WRITE;
/*!40000 ALTER TABLE `email_templates_default_data` DISABLE KEYS */;
INSERT INTO `email_templates_default_data` VALUES
(1,'PASSWORD_RESET_CONFIRM','en','Password Reset Confirm','Password Reset Confirmation','We have received a request to reset your password for the {$siteTitle} web site.<br />\n<br />\nIf you did not make this request, please ignore this email and your password will not be changed. If you wish to reset your password, click on the below URL.<br />\n<br />\nReset my password: {$passwordResetUrl}<br />\n<br />\n{$siteContactName}'),
(2,'USER_REGISTER','en','User Created','Journal Registration','{$recipientName}<br />\n<br />\nYou have now been registered as a user with {$contextName}. We have included your username and password in this email, which are needed for all work with this journal through its website. At any point, you can ask to be removed from the journal\'s list of users by contacting me.<br />\n<br />\nUsername: {$recipientUsername}<br />\nPassword: {$password}<br />\n<br />\nThank you,<br />\n{$signature}'),
(3,'USER_VALIDATE_CONTEXT','en','Validate Email (Journal Registration)','Validate Your Account','{$recipientName}<br />\n<br />\nYou have created an account with {$contextName}, but before you can start using it, you need to validate your email account. To do this, simply follow the link below:<br />\n<br />\n{$activateUrl}<br />\n<br />\nThank you,<br />\n{$contextSignature}'),
(4,'USER_VALIDATE_SITE','en','Validate Email (Site)','Validate Your Account','{$recipientName}<br />\n<br />\nYou have created an account with {$siteTitle}, but before you can start using it, you need to validate your email account. To do this, simply follow the link below:<br />\n<br />\n{$activateUrl}<br />\n<br />\nThank you,<br />\n{$siteSignature}'),
(5,'REVIEWER_REGISTER','en','Reviewer Register','Registration as Reviewer with {$contextName}','<p>Dear {$recipientName},</p><p>In light of your expertise, we have registered your name in the reviewer database for {$contextName}. This does not entail any form of commitment on your part, but simply enables us to approach you with a submission to possibly review. On being invited to review, you will have an opportunity to see the title and abstract of the paper in question, and you\'ll always be in a position to accept or decline the invitation. You can also ask at any point to have your name removed from this reviewer list.</p><p>We are providing you with a username and password, which is used in all interactions with the journal through its website. You may wish, for example, to update your profile, including your reviewing interests.</p><p>Username: {$recipientUsername}<br />Password: {$password}</p><p>Thank you,</p>{$signature}'),
(6,'ISSUE_PUBLISH_NOTIFY','en','Issue Published Notify','Just published: {$issueIdentification} of {$contextName}','<p>Dear {$recipientName},</p><p>We are pleased to announce the publication of <a href=\"{$issueUrl}\">{$issueIdentification}</a> of {$contextName}.  We invite you to read and share this work with your scholarly community.</p><p>Many thanks to our authors, reviewers, and editors for their valuable contributions, and to our readers for your continued interest.</p><div>{$issueToc}</div><p>Thank you,</p>{$signature}'),
(7,'SUBMISSION_ACK','en','Submission Confirmation','Thank you for your submission to {$contextName}','<p>Dear {$recipientName},</p><p>Thank you for your submission to {$contextName}. We have received your submission, \"{$submissionTitle}\", and a member of our editorial team will see it soon. You will be sent an email when an initial decision is made, and we may contact you for further information.</p><p>You can view your submission and track its progress through the editorial process at the following location:</p><p>Submission URL: {$authorSubmissionUrl}</p><p>If you have been logged out, you can login again with the username {$recipientUsername}.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Thank you for considering {$contextName} as a venue for your work.</p>{$contextSignature}'),
(8,'SUBMISSION_ACK_NOT_USER','en','Submission Confirmation (Other Authors)','Submission confirmation','<p>Dear {$recipientName},</p><p>You have been named as a co-author on a submission to {$contextName}. The submitter, {$submitterName}, provided the following details:</p><p>\"{$submissionTitle}\"<br>{$authorsWithAffiliation}</p><p>If any of these details are incorrect, or you do not wish to be named on this submission, please contact me.</p><p>Thank you for considering {$contextName} as a venue for your work.</p><p>Kind regards,</p>{$contextSignature}'),
(9,'EDITOR_ASSIGN','en','Editor Assigned','You have been assigned as an editor on a submission to {$contextName}','<p>Dear {$recipientName},</p><p>The following submission has been assigned to you to see through the editorial process.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>If you find the submission to be relevant for {$contextName}, please forward the submission to the review stage by selecting \"Send to Review\" and then assign reviewers by clicking \"Add Reviewer\".</p><p>If the submission is not appropriate for this journal, please decline the submission.</p><p>Thank you in advance.</p><p>Kind regards,</p>{$contextSignature}'),
(10,'REVIEW_CANCEL','en','Reviewer Unassign','Request for Review Cancelled','<p>Dear {$recipientName},</p><p>Recently, we asked you to review a submission to {$contextName}. We have decided to cancel the request for you to reivew the submission, {$submissionTitle}.</p><p>We apologize any inconvenience this may cause you and hope that we will be able to call on you to assist with this journal\'s review process in the future.</p><p>If you have any questions, please contact me.</p>{$signature}'),
(11,'REVIEW_REINSTATE','en','Reviewer Reinstate','Can you still review something for {$contextName}?','<p>Dear {$recipientName},</p><p>We recently cancelled our request for you to review a submission, {$submissionTitle}, for {$contextName}. We\'ve reversed that decision and we hope that you are still able to conduct the review.</p><p>If you are able to assist with this submission\'s review, you can <a href=\"{$reviewAssignmentUrl}\">login to the journal</a> to view the submission, upload review files, and submit your review request.</p><p>If you have any questions, please contact me.</p><p>Kind regards,</p>{$signature}'),
(12,'REVIEW_RESEND_REQUEST','en','Resend Review Request to Reviewer','Requesting your review again for {$contextName}','<p>Dear {$recipientName},</p><p>Recently, you declined our request to review a submission, \"{$submissionTitle}\", for {$contextName}. I\'m writing to see if you are able to conduct the review after all.</p><p>We would be grateful if you\'re able to perform this review, but we understand if that is not possible at this time. Either way, please <a href=\"{$reviewAssignmentUrl}\">accept or decline the request</a> by {$responseDueDate}, so that we can find an alternate reviewer.</p><p>If you have any questions, please contact me.</p><p>Kind regards,</p>{$signature}'),
(13,'REVIEW_REQUEST','en','Review Request','Invitation to review','<p>Dear {$recipientName},</p><p>I believe that you would serve as an excellent reviewer for a submission  to {$contextName}. The submission\'s title and abstract are below, and I hope that you will consider undertaking this important task for us.</p><p>If you are able to review this submission, your review is due by {$reviewDueDate}. You can view the submission, upload review files, and submit your review by logging into the journal site and following the steps at the link below.</p><p><a href=\"{$reviewAssignmentUrl}\">{$submissionTitle}</a></p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please <a href=\"{$reviewAssignmentUrl}\">accept or decline</a> the review by <b>{$responseDueDate}</b>.</p><p>You may contact me with any questions about the submission or the review process.</p><p>Thank you for considering this request. Your help is much appreciated.</p><p>Kind regards,</p>{$signature}'),
(14,'REVIEW_REQUEST_SUBSEQUENT','en','Review Request Subsequent','Request to review a revised submission','<p>Dear {$recipientName},</p><p>Thank you for your review of <a href=\"{$reviewAssignmentUrl}\">{$submissionTitle}</a>. The authors have considered the reviewers\' feedback and have now submitted a revised version of their work. I\'m writing to ask if you would conduct a second round of peer review for this submission.</p><p>If you are able to review this submission, your review is due by {$reviewDueDate}. You can <a href=\"{$reviewAssignmentUrl}\">follow the review steps</a> to view the submission, upload review files, and submit your review comments.<p><p><a href=\"{$reviewAssignmentUrl}\">{$submissionTitle}</a></p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please <a href=\"{$reviewAssignmentUrl}\">accept or decline</a> the review by <b>{$responseDueDate}</b>.</p><p>Please feel free to contact me with any questions about the submission or the review process.</p><p>Thank you for considering this request. Your help is much appreciated.</p><p>Kind regards,</p>{$signature}'),
(15,'REVIEW_RESPONSE_OVERDUE_AUTO','en','Review Response Overdue (Automated)','Will you be able to review this for us?','<p>Dear {$recipientName},</p><p>This email is an automated reminder from {$contextName} in regards to our request for your review of the submission, \"{$submissionTitle}.\"</p><p>You are receiving this email because we have not yet received a confirmation from you indicating whether or not you are able to undertake the review of this submission.</p><p>Please let us know whether or not you are able to undertake this review by using our submission management software to accept or decline this request.</p><p>If you are able to review this submission, your review is due by {$reviewDueDate}. You can follow the review steps to view the submission, upload review files, and submit your review comments.</p><p><a href=\"{$reviewAssignmentUrl}\">{$submissionTitle}</a></p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please feel free to contact me with any questions about the submission or the review process.</p><p>Thank you for considering this request. Your help is much appreciated.</p><p>Kind regards,</p>{$contextSignature}'),
(16,'REVIEW_CONFIRM','en','Review Confirm','Review accepted: {$reviewerName} accepted review assignment for #{$submissionId} {$authorsShort} — \"{$submissionTitle}\"','<p>Dear {$recipientName},</p><p>{$reviewerName} has accepted the following review:</p><p><a href=\"{$submissionUrl}\">#{$submissionId} {$authorsShort} — \"{$submissionTitle}\"</a><br /><b>Type:</b> {$reviewMethod}</p><p><b>Review Due:</b> {$reviewDueDate}</p><p>Login to <a href=\"{$submissionUrl}\">view all reviewer assignments</a> for this submission.</p><br><br>—<br>This is an automated message from <a href=\"{$contextUrl}\">{$contextName}</a>.'),
(17,'REVIEW_DECLINE','en','Review Decline','Unable to Review','Editors:<br />\n<br />\nI am afraid that at this time I am unable to review the submission, &quot;{$submissionTitle},&quot; for {$contextName}. Thank you for thinking of me, and another time feel free to call on me.<br />\n<br />\n{$senderName}'),
(18,'REVIEW_ACK','en','Review Acknowledgement','Thank you for your review','<p>Dear {$recipientName},</p>\n<p>Thank you for completing your review of the submission, \"{$submissionTitle}\", for {$contextName}. We appreciate your time and expertise in contributing to the quality of the work that we publish.</p>\n<p>It has been a pleasure to work with you as a reviewer for {$contextName}, and we hope to have the opportunity to work with you again in the future.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>'),
(19,'REVIEW_REMIND','en','Review Reminder','A reminder to please complete your review','<p>Dear {$recipientName},</p><p>Just a gentle reminder of our request for your review of the submission, \"{$submissionTitle},\" for {$contextName}. We were expecting to have this review by {$reviewDueDate} and we would be pleased to receive it as soon as you are able to prepare it.</p><p>You can <a href=\"{$reviewAssignmentUrl}\">login to the journal</a> and follow the review steps to view the submission, upload review files, and submit your review comments.</p><p>If you need an extension of the deadline, please contact me. I look forward to hearing from you.</p><p>Thank you in advance and kind regards,</p>{$signature}'),
(20,'REVIEW_REMIND_AUTO','en','Review Reminder (Automated)','A reminder to please complete your review','<p>Dear {$recipientName}:</p><p>This email is an automated reminder from {$contextName} in regards to our request for your review of the submission, \"{$submissionTitle}.\"</p><p>We were expecting to have this review by {$reviewDueDate} and we would be pleased to receive it as soon as you are able to prepare it.</p><p>Please <a href=\"{$reviewAssignmentUrl}\">login to the journal</a> and follow the review steps to view the submission, upload review files, and submit your review comments.</p><p>If you need an extension of the deadline, please contact me. I look forward to hearing from you.</p><p>Thank you in advance and kind regards,</p>{$contextSignature}'),
(21,'REVIEW_COMPLETE','en','Review Completed','Review complete: {$reviewerName} recommends {$reviewRecommendation} for #{$submissionId} {$authorsShort} — \"{$submissionTitle}\"','<p>Dear {$recipientName},</p><p>{$reviewerName} completed the following review:</p><p><a href=\"{$submissionUrl}\">#{$submissionId} {$authorsShort} — \"{$submissionTitle}\"</a><br /><b>Recommendation:</b> {$reviewRecommendation}<br /><b>Type:</b> {$reviewMethod}</p><p>Login to <a href=\"{$submissionUrl}\">view all files and comments</a> provided by this reviewer.</p>'),
(22,'REVIEW_EDIT','en','Review Edited','Your review assignment has been changed for {$contextName}','<p>Dear {$recipientName},</p><p>An editor has made changes to your review assignment for {$contextName}. Please review the details below and let us know if you have any questions.</p><p><a href=\"{$reviewAssignmentUrl}\">\"{$submissionTitle}\"</a><br /><b>Type:</b> {$reviewMethod}<br /><b>Accept or Decline By:</b> {$responseDueDate}<br /><b>Submit Review By:</b> {$reviewDueDate}</p><p>You can login to <a href=\"{$reviewAssignmentUrl}\">complete this review</a> at any time.</p>'),
(23,'EDITOR_DECISION_ACCEPT','en','Submission Accepted','Your submission has been accepted to {$contextName}','<p>Dear {$recipientName},</p><p>I am pleased to inform you that we have decided to accept your submission without further revision. After careful review, we found your submission, {$submissionTitle}, to meet or exceed our expectations. We are excited to publish your piece in {$contextName} and we thank you for choosing our journal as a venue for your work.</p><p>Your submission is now forthcoming in a future issue of {$contextName} and you are welcome to include it in your list of publications. We recognize the hard work that goes into every successful submission and we want to congratulate you on reaching this stage.</p><p>Your submission will now undergo copy editing and formatting to prepare it for publication.</p><p>You will shortly receive further instructions.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Kind regards,</p>{$signature}'),
(24,'EDITOR_DECISION_SEND_TO_EXTERNAL','en','Sent to Review','Your submission has been sent for review','<p>Dear {$recipientName},</p><p>I am pleased to inform you that an editor has reviewed your submission, \"{$submissionTitle}\", and has decided to send it for peer review. An editor will identify qualified reviewers who will provide feedback on your submission.</p><p>{$reviewTypeDescription} You will hear from us with feedback from the reviewers and information about the next steps.</p><p>Please note that sending the submission to peer review does not guarantee that it will be published. We will consider the reviewers\' recommendations before deciding to accept the submission for publication. You may be asked to make revisions and respond to the reviewers\' comments before a final decision is made.</p><p>If you have any questions, please contact me from your submission dashboard.</p><p>{$signature}</p>'),
(25,'EDITOR_DECISION_SEND_TO_PRODUCTION','en','Sent to Production','Next steps for publishing your submission','<p>Dear {$recipientName},</p><p>I am writing from {$contextName} to let you know that the editing of your submission, \"{$submissionTitle}\", is complete. Your submission will now advance to the production stage, where the final galleys will be prepared for publication. We will contact you if we need any further assistance.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Kind regards,</p>{$signature}'),
(26,'EDITOR_DECISION_REVISIONS','en','Revisions Requested','Your submission has been reviewed and we encourage you to submit revisions','<p>Dear {$recipientName},</p><p>Your submission \"{$submissionTitle}\" has been reviewed and we would like to encourage you to submit revisions that address the reviewers\' comments. An editor will review these revisions and if they address the concerns adequately, your submission may be accepted for publication.</p><p>The reviewers\' comments are included at the bottom of this email. Please respond to each point in the reviewers\' comments and identify what changes you have made. If you find any of the reviewer\'s comments to be unjustified or inappropriate, please explain your perspective.</p><p>When you have completed your revisions, you can upload revised documents along with your response to the reviewers\' comments at your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>. If you have been logged out, you can login again with the username {$recipientUsername}.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>We look forward to receiving your revised submission.</p><p>Kind regards,</p>{$signature}<hr><p>The following comments were received from reviewers.</p>{$allReviewerComments}'),
(27,'EDITOR_DECISION_RESUBMIT','en','Resubmit for Review','Your submission has been reviewed - please revise and resubmit','<p>Dear {$recipientName},</p><p>After reviewing your submission, \"{$submissionTitle}\", the reviewers have recommended that your submission cannot be accepted for publication in its current form. However, we would like to encourage you to submit a revised version that addresses the reviewers\' comments. Your revisions will be reviewed by an editor and may be sent out for another round of peer review.</p><p>Please note that resubmitting your work does not guarantee that it will be accepted.</p><p>The reviewers\' comments are included at the bottom of this email. Please respond to each point and identify what changes you have made. If you find any of the reviewer\'s comments inappropriate, please explain your perspective. If you have questions about the recommendations in your review, please include these in your response.</p><p>When you have completed your revisions, you can upload revised documents along with your response to the reviewers\' comments <a href=\"{$authorSubmissionUrl}\">at your submission dashboard</a>. If you have been logged out, you can login again with the username {$recipientUsername}.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>We look forward to receiving your revised submission.</p><p>Kind regards,</p>{$signature}<hr><p>The following comments were received from reviewers.</p>{$allReviewerComments}'),
(28,'EDITOR_DECISION_DECLINE','en','Submission Declined','Your submission has been declined','<p>Dear {$recipientName},</p><p>While we appreciate receiving your submission, we are unable to accept \"{$submissionTitle}\" for publication on the basis of the comments from reviewers.</p><p>The reviewers\' comments are included at the bottom of this email.</p><p>Thank you for submitting to {$contextName}. Although it is disappointing to have a submission declined, I hope you find the reviewers\' comments to be constructive and helpful.</p><p>You are now free to submit the work elsewhere if you choose to do so.</p><p>Kind regards,</p>{$signature}<hr><p>The following comments were received from reviewers.</p>{$allReviewerComments}'),
(29,'EDITOR_DECISION_INITIAL_DECLINE','en','Submission Declined (Pre-Review)','Your submission has been declined','<p>Dear {$recipientName},</p><p>I’m sorry to inform you that, after reviewing your submission, \"{$submissionTitle}\", the editor has found that it does not meet our requirements for publication in {$contextName}.</p><p>I wish you success if you consider submitting your work elsewhere.</p><p>Kind regards,</p>{$signature}'),
(30,'EDITOR_RECOMMENDATION','en','Recommendation Made','Editor Recommendation','<p>Dear {$recipientName},</p><p>After considering the reviewers\' feedback, I would like to make the following recommendation regarding the submission \"{$submissionTitle}\".</p><p>My recommendation is: {$recommendation}.</p><p>Please visit the submission\'s <a href=\"{$submissionUrl}\">editorial workflow</a> to act on this recommendation.</p><p>Please feel free to contact me with any questions.</p><p>Kind regards,</p><p>{$senderName}</p>'),
(31,'EDITOR_DECISION_NOTIFY_OTHER_AUTHORS','en','Notify Other Authors','An update regarding your submission','<p>The following email was sent to {$submittingAuthorName} from {$contextName} regarding \"{$submissionTitle}\".</p>\n<p>You are receiving a copy of this notification because you are identified as an author of the submission. Any instructions in the message below are intended for the submitting author, {$submittingAuthorName}, and no action is required of you at this time.</p>\n\n{$messageToSubmittingAuthor}'),
(32,'EDITOR_DECISION_NOTIFY_REVIEWERS','en','Notify Reviewers of Decision','Thank you for your review','<p>Dear {$recipientName},</p>\n<p>Thank you for completing your review of the submission, \"{$submissionTitle}\", for {$contextName}. We appreciate your time and expertise in contributing to the quality of the work that we publish. We have shared your comments with the authors, along with our other reviewers\' comments and the editor\'s decision.</p>\n<p>Based on the feedback we received, we have notified the authors of the following:</p>\n<p>{$decisionDescription}</p>\n<p>Your recommendation was considered alongside the recommendations of other reviewers before coming to a decision. Occasionally the editor\'s decision may differ from the recommendation made by one or more reviewers. The editor considers many factors, and does not take these decisions lightly. We are grateful for our reviewers\' expertise and suggestions.</p>\n<p>It has been a pleasure to work with you as a reviewer for {$contextName}, and we hope to have the opportunity to work with you again in the future.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>'),
(33,'EDITOR_DECISION_NEW_ROUND','en','New Review Round Initiated','Your submission has been sent for another round of review','<p>Dear {$recipientName},</p>\n<p>Your revised submission, \"{$submissionTitle}\", has been sent for a new round of peer review. \nYou will hear from us with feedback from the reviewers and information about the next steps.</p>\n<p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>\n'),
(34,'EDITOR_DECISION_REVERT_DECLINE','en','Reinstate Declined Submission','We have reversed the decision to decline your submission','<p>Dear {$recipientName},</p>\n<p>The decision to decline your submission, \"{$submissionTitle}\", has been reversed. \nAn editor will complete the round of review and you will be notified when a \ndecision is made.</p>\n<p>Occasionally, a decision to decline a submission will be recorded accidentally in \nour system and must be reverted. I apologize for any confusion this may have caused.</p>\n<p>We will contact you if we need any further assistance.</p>\n<p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>\n'),
(35,'EDITOR_DECISION_REVERT_INITIAL_DECLINE','en','Reinstate Submission Declined Without Review','We have reversed the decision to decline your submission','<p>Dear {$recipientName},</p>\n<p>The decision to decline your submission, \"{$submissionTitle}\", has been reversed. \nAn editor will look further at your submission before deciding whether to decline \nthe submission or send it for review.</p>\n<p>Occasionally, a decision to decline a submission will be recorded accidentally in \nour system and must be reverted. I apologize for any confusion this may have caused.</p>\n<p>We will contact you if we need any further assistance.</p>\n<p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>\n'),
(36,'EDITOR_DECISION_SKIP_REVIEW','en','Submission Accepted (Without Review)','Your submission has been sent for copyediting','<p>Dear {$recipientName},</p>\n<p>I am pleased to inform you that we have decided to accept your submission without peer review. We found your submission, {$submissionTitle}, to meet our expectations, and we do not require that work of this type undergo peer review. We are excited to publish your piece in {$contextName} and we thank you for choosing our journal as a venue for your work.</p>\nYour submission is now forthcoming in a future issue of {$contextName} and you are welcome to include it in your list of publications. We recognize the hard work that goes into every successful submission and we want to congratulate you on your efforts.</p>\n<p>Your submission will now undergo copy editing and formatting to prepare it for publication. </p>\n<p>You will shortly receive further instructions.</p>\n<p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>\n'),
(37,'EDITOR_DECISION_BACK_FROM_PRODUCTION','en','Submission Sent Back to Copyediting','Your submission has been sent back to copyediting','<p>Dear {$recipientName},</p><p>Your submission, \"{$submissionTitle}\", has been sent back to the copyediting stage, where it will undergo further copyediting and formatting to prepare it for publication.</p><p>Occasionally, a submission is sent to the production stage before it is ready for the final galleys to be prepared for publication. Your submission is still forthcoming. I apologize for any confusion.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>We will contact you if we need any further assistance.</p><p>Kind regards,</p><p>{$signature}</p>'),
(38,'EDITOR_DECISION_BACK_FROM_COPYEDITING','en','Submission Sent Back from Copyediting','Your submission has been sent back to review','<p>Dear {$recipientName},</p><p>Your submission, \"{$submissionTitle}\", has been sent back to the review stage. It will undergo further review before it can be accepted for publication.</p><p>Occasionally, a decision to accept a submission will be recorded accidentally in our system and we must send it back to review. I apologize for any confusion this has caused. We will work to complete any further review quickly so that you have a final decision as soon as possible.</p><p>We will contact you if we need any further assistance.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Kind regards,</p><p>{$signature}</p>'),
(39,'EDITOR_DECISION_CANCEL_REVIEW_ROUND','en','Review Round Cancelled','A review round for your submission has been cancelled','<p>Dear {$recipientName},</p><p>We recently opened a new review round for your submission, \"{$submissionTitle}\". We are closing this review round now.</p><p>Occasionally, a decision to open a round of review will be recorded accidentally in our system and we must cancel this review round. I apologize for any confusion this may have caused.</p><p>We will contact you if we need any further assistance.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Kind regards,</p><p>{$signature}</p>'),
(40,'SUBSCRIPTION_NOTIFY','en','Subscription Notify','Subscription Notification','{$recipientName}:<br />\n<br />\nYou have now been registered as a subscriber in our online journal management system for {$contextName}, with the following subscription:<br />\n<br />\n{$subscriptionType}<br />\n<br />\nTo access content that is available only to subscribers, simply log in to the system with your username, &quot;{$recipientUsername}&quot;.<br />\n<br />\nOnce you have logged in to the system you can change your profile details and password at any point.<br />\n<br />\nPlease note that if you have an institutional subscription, there is no need for users at your institution to log in, since requests for subscription content will be automatically authenticated by the system.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionSignature}'),
(41,'OPEN_ACCESS_NOTIFY','en','Open Access Notify','Free to read: {$issueIdentification} of {$contextName} is now open access','<p>Dear {$recipientName},</p><p>We are pleased to inform you that <a href=\"{$issueUrl}\">{$issueIdentification}</a> of {$contextName} is now available under open access.  A subscription is no longer required to read this issue.</p><p>Thank you for your continuing interest in our work.</p>{$contextSignature}'),
(42,'SUBSCRIPTION_BEFORE_EXPIRY','en','Subscription Expires Soon','Notice of Subscription Expiry','{$recipientName}:<br />\n<br />\nYour {$contextName} subscription is about to expire.<br />\n<br />\n{$subscriptionType}<br />\nExpiry date: {$expiryDate}<br />\n<br />\nTo ensure the continuity of your access to this journal, please go to the journal website and renew your subscription. You are able to log in to the system with your username, &quot;{$recipientUsername}&quot;.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionSignature}'),
(43,'SUBSCRIPTION_AFTER_EXPIRY','en','Subscription Expired','Subscription Expired','{$recipientName}:<br />\n<br />\nYour {$contextName} subscription has expired.<br />\n<br />\n{$subscriptionType}<br />\nExpiry date: {$expiryDate}<br />\n<br />\nTo renew your subscription, please go to the journal website. You are able to log in to the system with your username, &quot;{$recipientUsername}&quot;.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionSignature}'),
(44,'SUBSCRIPTION_AFTER_EXPIRY_LAST','en','Subscription Expired Last','Subscription Expired - Final Reminder','{$recipientName}:<br />\n<br />\nYour {$contextName} subscription has expired.<br />\nPlease note that this is the final reminder that will be emailed to you.<br />\n<br />\n{$subscriptionType}<br />\nExpiry date: {$expiryDate}<br />\n<br />\nTo renew your subscription, please go to the journal website. You are able to log in to the system with your username, &quot;{$recipientUsername}&quot;.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionSignature}'),
(45,'SUBSCRIPTION_PURCHASE_INDL','en','Purchase Individual Subscription','Subscription Purchase: Individual','An individual subscription has been purchased online for {$contextName} with the following details.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nUser:<br />\n{$subscriberDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n'),
(46,'SUBSCRIPTION_PURCHASE_INSTL','en','Purchase Institutional Subscription','Subscription Purchase: Institutional','An institutional subscription has been purchased online for {$contextName} with the following details. To activate this subscription, please use the provided Subscription URL and set the subscription status to \'Active\'.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nInstitution:<br />\n{$institutionName}<br />\n{$institutionMailingAddress}<br />\n<br />\nDomain (if provided):<br />\n{$domain}<br />\n<br />\nIP Ranges (if provided):<br />\n{$ipRanges}<br />\n<br />\nContact Person:<br />\n{$subscriberDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n'),
(47,'SUBSCRIPTION_RENEW_INDL','en','Renew Individual Subscription','Subscription Renewal: Individual','An individual subscription has been renewed online for {$contextName} with the following details.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nUser:<br />\n{$subscriberDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n'),
(48,'SUBSCRIPTION_RENEW_INSTL','en','Renew Institutional Subscription','Subscription Renewal: Institutional','An institutional subscription has been renewed online for {$contextName} with the following details.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nInstitution:<br />\n{$institutionName}<br />\n{$institutionMailingAddress}<br />\n<br />\nDomain (if provided):<br />\n{$domain}<br />\n<br />\nIP Ranges (if provided):<br />\n{$ipRanges}<br />\n<br />\nContact Person:<br />\n{$subscriberDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n'),
(49,'REVISED_VERSION_NOTIFY','en','Revised Version Notification','Revised Version Uploaded','<p>Dear {$recipientName},</p><p>The author has uploaded revisions for the submission, <b>{$authorsShort} — {$submissionTitle}</b>. <p>As an assigned editor, we ask that you login and <a href=\"{$submissionUrl}\">view the revisions</a> and make a decision to accept, decline or send the submission for further review.</p><br><br>—<br>This is an automated message from <a href=\"{$contextUrl}\">{$contextName}</a>.'),
(50,'STATISTICS_REPORT_NOTIFICATION','en','Statistics Report Notification','Editorial activity for {$month}, {$year}','\n{$recipientName}, <br />\n<br />\nYour journal health report for {$month}, {$year} is now available. Your key stats for this month are below.<br />\n<ul>\n	<li>New submissions this month: {$newSubmissions}</li>\n	<li>Declined submissions this month: {$declinedSubmissions}</li>\n	<li>Accepted submissions this month: {$acceptedSubmissions}</li>\n	<li>Total submissions in the system: {$totalSubmissions}</li>\n</ul>\nLogin to the journal to view more detailed <a href=\"{$editorialStatsLink}\">editorial trends</a> and <a href=\"{$publicationStatsLink}\">published article stats</a>. A full copy of this month\'s editorial trends is attached.<br />\n<br />\nSincerely,<br />\n{$contextSignature}'),
(51,'ANNOUNCEMENT','en','New Announcement','{$announcementTitle}','<b>{$announcementTitle}</b><br />\n<br />\n{$announcementSummary}<br />\n<br />\nVisit our website to read the <a href=\"{$announcementUrl}\">full announcement</a>.'),
(52,'DISCUSSION_NOTIFICATION_SUBMISSION','en','Discussion (Submission)','A message regarding {$contextName}','Please enter your message.'),
(53,'DISCUSSION_NOTIFICATION_REVIEW','en','Discussion (Review)','A message regarding {$contextName}','Please enter your message.'),
(54,'DISCUSSION_NOTIFICATION_COPYEDITING','en','Discussion (Copyediting)','A message regarding {$contextName}','Please enter your message.'),
(55,'DISCUSSION_NOTIFICATION_PRODUCTION','en','Discussion (Production)','A message regarding {$contextName}','Please enter your message.'),
(56,'COPYEDIT_REQUEST','en','Request Copyedit','Submission {$submissionId} is ready to be copyedited for {$contextAcronym}','<p>Dear {$recipientName},</p><p>A new submission is ready to be copyedited:</p><p><a href\"{$submissionUrl}\">{$submissionId} — \"{$submissionTitle}\"</a><br />{$contextName}</p><p>Please follow these steps to complete this task:</p><ol><li>Click on the Submission URL below.</li><li>Open any files available under Draft Files and edit the files. Use the Copyediting Discussions area if you need to contact the editor(s) or author(s).</li><li>Save the copyedited file(s) and upload them to the Copyedited panel.</li><li>Use the Copyediting Discussions to notify the editor(s) that all files have been prepared, and that the Production process may begin.</li></ol><p>If you are unable to undertake this work at this time or have any questions, please contact me. Thank you for your contribution to {$contextName}.</p><p>Kind regards,</p>{$signature}'),
(57,'EDITOR_ASSIGN_SUBMISSION','en','Assign Editor','You have been assigned as an editor on a submission to {$contextName}','<p>Dear {$recipientName},</p><p>The following submission has been assigned to you to see through the editorial process.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>If you find the submission to be relevant for {$contextName}, please forward the submission to the review stage by selecting \"Send to Review\" and then assign reviewers by clicking \"Add Reviewer\".</p><p>If the submission is not appropriate for this journal, please decline the submission.</p><p>Thank you in advance.</p><p>Kind regards,</p>{$contextSignature}'),
(58,'EDITOR_ASSIGN_REVIEW','en','Assign Editor','You have been assigned as an editor on a submission to {$contextName}','<p>Dear {$recipientName},</p><p>The following submission has been assigned to you to see through the peer review process.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please login to <a href=\"{$submissionUrl}\">view the submission</a> and assign qualified reviewers. You can assign a reviewer by clicking \"Add Reviewer\".</p><p>Thank you in advance.</p><p>Kind regards,</p>{$signature}'),
(59,'EDITOR_ASSIGN_PRODUCTION','en','Assign Editor','You have been assigned as an editor on a submission to {$contextName}','<p>Dear {$recipientName},</p><p>The following submission has been assigned to you to see through the production stage.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please login to <a href=\"{$submissionUrl}\">view the submission</a>. Once production-ready files are available, upload them under the <strong>Publication > Galleys</strong> section. Then schedule the work for publication by clicking the <strong>Schedule for Publication</strong> button.</p><p>Thank you in advance.</p><p>Kind regards,</p>{$signature}'),
(60,'LAYOUT_REQUEST','en','Ready for Production','Submission {$submissionId} is ready for production at {$contextAcronym}','<p>Dear {$recipientName},</p><p>A new submission is ready for layout editing:</p><p><a href=\"{$submissionUrl}\">{$submissionId} — {$submissionTitle}</a><br />{$contextName}</p><ol><li>Click on the Submission URL above.</li><li>Download the Production Ready files and use them to create the galleys according to the journal\'s standards.</li><li>Upload the galleys to the Publication section of the submission.</li><li>Use the  Production Discussions to notify the editor that the galleys are ready.</li></ol><p>If you are unable to undertake this work at this time or have any questions, please contact me. Thank you for your contribution to this journal.</p><p>Kind regards,</p>{$signature}'),
(61,'LAYOUT_COMPLETE','en','Galleys Complete','Galleys Complete','<p>Dear {$recipientName},</p><p>Galleys have now been prepared for the following submission and are ready for final review.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$contextName}</p><p>If you have any questions, please contact me.</p><p>Kind regards,</p><p>{$signature}</p>'),
(62,'VERSION_CREATED','en','Version Created','A new version was created for \"{$submissionTitle}\"','<p>Dear {$recipientName}, </p><p>This is an automated message to inform you that a new version of your submission, \"{$submissionTitle}\", was created. You can view this version from your submission dashboard at the following link:</p><p><a href=\"{$submissionUrl}\">\"{$submissionTitle}\"</a></p><hr><p>This is an automatic email sent from <a href=\"{$contextUrl}\">{$contextName}</a>.</p>'),
(63,'EDITORIAL_REMINDER','en','Editorial Reminder','Outstanding editorial tasks for {$contextName}','<p>Dear {$recipientName},</p><p>You are currently assigned to {$numberOfSubmissions} submissions in <a href=\"{$contextUrl}\">{$contextName}</a>. The following submissions are <b>waiting for your response</b>.</p>{$outstandingTasks}<p>View all of your assignments in your <a href=\"{$submissionsUrl}\">submission dashboard</a>.</p><p>If you have any questions about your assignments, please contact {$contactName} at {$contactEmail}.</p>'),
(64,'SUBMISSION_SAVED_FOR_LATER','en','Submission Saved for Later','Resume your submission to {$contextName}','<p>Dear {$recipientName},</p><p>Your submission details have been saved in our system, but it has not yet been submitted for consideration. You can return to complete your submission at any time by following the link below.</p><p><a href=\"{$submissionWizardUrl}\">{$authorsShort} — \"{$submissionTitle}\"</a></p><hr><p>This is an automated email from <a href=\"{$contextUrl}\">{$contextName}</a>.</p>'),
(65,'SUBMISSION_NEEDS_EDITOR','en','Submission Needs Editor','A new submission needs an editor to be assigned: \"{$submissionTitle}\"','<p>Dear {$recipientName},</p><p>The following submission has been submitted and there is no editor assigned.</p><p><a href=\"{$submissionUrl}\">\"{$submissionTitle}\"</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please assign an editor who will be responsible for the submission by clicking the title above and assigning an editor under the Participants section.</p><hr><p>This is an automated email from <a href=\"{$contextUrl}\">{$contextName}</a>.</p>'),
(66,'PAYMENT_REQUEST_NOTIFICATION','en','Payment Request','Payment Request Notification','<p>Dear {$recipientName},</p><p>Congratulations on the acceptance of your submission, {$submissionTitle}, to {$contextName}. Now that your submission has been accepted, we would like to request payment of the publication fee.</p><p>This fee covers the production costs of bringing your submission to publication. To make the payment, please visit <a href=\"{$queuedPaymentUrl}\">{$queuedPaymentUrl}</a>.</p><p>If you have any questions, please see our <a href=\"{$submissionGuidelinesUrl}\">Submission Guidelines</a></p>'),
(67,'CHANGE_EMAIL','en','Change Email Address Invitation','Confirm account contact email change request','<p>Dear {$recipientName},</p><p>You are receiving this email because someone has requested a change of your email to {$newEmail}.</p><p>If you have made this request please <a href=\"{$acceptInvitationUrl}\">confirm</a> the email change.</p><p>You can always <a href=\"{$declineInvitationUrl}\">reject</a> this email change.</p><p>Please feel free to contact me with any questions about the submission or the review process.</p><p>Kind regards,</p>{$siteContactName}'),
(68,'ORCID_COLLECT_AUTHOR_ID','en','orcidCollectAuthorId','Submission ORCID','Dear {$recipientName},<br/>\n<br/>\nYou have been listed as an author on a manuscript submission to {$contextName}.<br/>\nTo confirm your authorship, please add your ORCID id to this submission by visiting the link provided below.<br/>\n<br/>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://info.orcid.org/wp-content/uploads/2020/12/ORCIDiD_icon16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or connect your ORCID iD</a><br/>\n<br/>\n<br>\n<a href=\"{$orcidAboutUrl}\">More information about ORCID at {$contextName}</a><br/>\n<br/>\nIf you have any questions, please contact me.<br/>\n<br/>\n{$principalContactSignature}<br/>\n'),
(69,'ORCID_REQUEST_AUTHOR_AUTHORIZATION','en','orcidRequestAuthorAuthorization','Requesting ORCID record access','Dear {$recipientName},<br>\n<br>\nYou have been listed as an author on the manuscript submission \"{$submissionTitle}\" to {$contextName}.\n<br>\n<br>\nPlease allow us to add your ORCID id to this submission and also to add the submission to your ORCID profile on publication.<br>\nVisit the link to the official ORCID website, login with your profile and authorize the access by following the instructions.<br>\n<br>\n<a href=\"{$authorOrcidUrl}\" style=\"display: inline-flex; align-items: center; background-color: white; text-align: center; padding: 10px 20px; text-decoration: none; border-radius: 5px; border: 2px solid #d7d4d4;\"><img id=\"orcid-id-logo\" src=\"https://info.orcid.org/wp-content/uploads/2020/12/ORCIDiD_icon16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or Connect your ORCID iD</a><br/>\n<br>\n<br>\nClick here to verify your account with ORCID: <a href=\"{$authorOrcidUrl}\">{$authorOrcidUrl}.</a>\n<br>\n<br>\n<a href=\"{$orcidAboutUrl}\">More about ORCID at {$contextName}</a><br/>\n<br>\n<br>\nIf you have any questions, please contact me.<br>\n<br>\n{$principalContactSignature}<br>\n'),
(70,'USER_ROLE_ASSIGNMENT_INVITATION','en','User Invited to Role Notification','You are invited to new roles','<div class=\'email-container\'>    <div class=\'email-header\'>        <h2>Invitation to New Role</h2>    </div>    <div class=\'email-content\'>        <p>Dear {$recipientName},</p>        <p>In light of your expertise, you have been invited by {$inviterName} to take on new roles at {$contextName}</p>        <p>At {$contextName}, we value your privacy. As such, we have taken steps to ensure that we are fully GDPR compliant. These steps include you being accountable to enter your own data and choosing who can see what information. For additional information on how we handled your data, please refer to our Privacy Policy.</p>        <div>{$existingRoles}</div>        <div>{$rolesAdded}</div>        <p>On accepting the invite, you will be redirected to {$contextName}.</p>        <p>Feel free to contact me with any questions about the process.</p>        <table class=\'btn-wrap\' role=\'presentation\' border=\'0\' cellpadding=\'0\' cellspacing=\'10\'>            <tr><td class=\'btn-cell btn-accept\'  bgcolor=\'#28a745\'><a class=\'btn\' href=\'{$acceptUrl}\'>Accept Invitation</a></td></tr>            <tr><td class=\'btn-cell btn-decline\' bgcolor=\'#dc3545\'><a class=\'btn\' href=\'{$declineUrl}\'>Decline Invitation</a></td></tr>        </table>        <p>Kind regards,</p>        <p>{$contextName}</p>    </div></div>'),
(71,'USER_ROLE_END','en','User Role Ended Notification','You have been removed from a role','<div class=\'email-container\'>    <div class=\'email-header\'>        <h2>Removed from a Role</h2>    </div>    <div class=\'email-content\'>        <p>Dear {$recipientName},</p>        <p>Thank you very much for your participation in the role of {$roleRemoved} at {$contextName}.</p>        <p>This is a notice to let you know that you have been removed from the following role at {$contextName}: <b>{$roleRemoved}</b>.</p>        <p>Your account with {$contextName} is still active and any other roles you previously held are still active.</p>        <p>Feel free to contact me with any questions about the process.</p>        <p>Kind regards,</p>        <p>{$contextName}</p>    </div></div>'),
(72,'USER_ROLE_MASTHEAD_UPDATE','en','User Role Masthead Visibility Update Notification','Your journal masthead visibility has been updated','<div class=\'email-container\'>    <div class=\'email-header\'>        <h2>Updated role masthead visibility</h2>    </div>    <div class=\'email-content\'>        <p>Dear {$recipientName},</p>        <p>Your journal masthead visibility for the role {$roleNameAndDates} in {$contextName} has been updated.</p>        <p>New setting: {$appearOnMasthead}</p>        <p>If you have questions about this change, please contact the journal manager.</p>        <p>Kind regards,</p>        <p>{$contextName}</p>    </div></div>'),
(73,'ORCID_REQUEST_UPDATE_SCOPE','en','orcidRequestUpdateScope','Requesting updated ORCID record access','Dear {$recipientName},<br>\n<br>\nYou are listed as a contributor (author or reviewer) on the manuscript submission \"{$submissionTitle}\" to {$contextName}.\n<br>\n<br>\nYou have previously authorized {$contextName} to list your ORCID id on the site, and we require updateded permissions to add your contribution to your ORCID profile.<br>\nVisit the link to the official ORCID website, login with your profile and authorize the access by following the instructions.<br>\n<br>\n<a href=\"{$authorOrcidUrl}\" style=\"display: inline-flex; align-items: center; background-color: white; text-align: center; padding: 10px 20px; text-decoration: none; border-radius: 5px; border: 2px solid #d7d4d4;\"><img id=\"orcid-id-logo\" src=\"https://info.orcid.org/wp-content/uploads/2020/12/ORCIDiD_icon16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or Connect your ORCID iD</a><br/>\n<br>\n<br>\nClick here to update your account with ORCID: <a href=\"{$authorOrcidUrl}\">{$authorOrcidUrl}.</a>\n<br>\n<br>\n<a href=\"{$orcidAboutUrl}\">More about ORCID at {$contextName}</a><br/>\n<br>\n<br>\nIf you have any questions, please contact me.<br>\n<br>\n{$principalContactSignature}<br>\n'),
(74,'MANUAL_PAYMENT_NOTIFICATION','en','Manual Payment Notify','Manual Payment Notification','A manual payment needs to be processed for the journal {$contextName} and the user &quot;{$senderUsername}&quot;.<br />\n<br />\nThe item being paid for is &quot;{$paymentName}&quot;.<br />\nThe cost is {$paymentAmount} ({$paymentCurrencyCode}).<br />\n<br />\nThis email was generated by Open Journal Systems\' Manual Payment plugin.');
/*!40000 ALTER TABLE `email_templates_default_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates_settings`
--

DROP TABLE IF EXISTS `email_templates_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates_settings` (
  `email_template_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`email_template_setting_id`),
  UNIQUE KEY `email_templates_settings_unique` (`email_id`,`locale`,`setting_name`),
  KEY `email_templates_settings_email_id` (`email_id`),
  CONSTRAINT `email_templates_settings_email_id` FOREIGN KEY (`email_id`) REFERENCES `email_templates` (`email_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about custom email templates, including localized properties such as the subject and body.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates_settings`
--

LOCK TABLES `email_templates_settings` WRITE;
/*!40000 ALTER TABLE `email_templates_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_templates_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_log`
--

DROP TABLE IF EXISTS `event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL COMMENT 'NULL if it''s system or automated event',
  `date_logged` datetime NOT NULL,
  `event_type` bigint(20) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_translated` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `event_log_user_id` (`user_id`),
  KEY `event_log_assoc` (`assoc_type`,`assoc_id`),
  CONSTRAINT `event_log_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A log of all events related to an object like a submission.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_log`
--

LOCK TABLES `event_log` WRITE;
/*!40000 ALTER TABLE `event_log` DISABLE KEYS */;
INSERT INTO `event_log` VALUES
(1,515,1,1,'2026-09-25 16:09:35',1342177281,'submission.event.fileUploaded',0),
(2,1048585,1,1,'2026-09-25 16:09:35',1342177288,'submission.event.fileRevised',0),
(3,515,1,1,'2026-09-25 16:09:36',1342177296,'submission.event.fileEdited',0),
(4,515,2,1,'2026-09-25 16:09:36',1342177281,'submission.event.fileUploaded',0),
(5,1048585,2,1,'2026-09-25 16:09:36',1342177288,'submission.event.fileRevised',0),
(6,515,2,1,'2026-09-25 16:09:36',1342177296,'submission.event.fileEdited',0),
(7,515,3,1,'2026-09-25 16:09:36',1342177281,'submission.event.fileUploaded',0),
(8,1048585,3,1,'2026-09-25 16:09:36',1342177288,'submission.event.fileRevised',0),
(9,515,3,1,'2026-09-25 16:09:36',1342177296,'submission.event.fileEdited',0),
(10,515,4,1,'2026-09-25 16:09:36',1342177281,'submission.event.fileUploaded',0),
(11,1048585,4,1,'2026-09-25 16:09:36',1342177288,'submission.event.fileRevised',0),
(12,515,4,1,'2026-09-25 16:09:36',1342177296,'submission.event.fileEdited',0),
(13,515,5,1,'2026-09-25 16:09:36',1342177281,'submission.event.fileUploaded',0),
(14,1048585,5,1,'2026-09-25 16:09:36',1342177288,'submission.event.fileRevised',0),
(15,515,6,1,'2026-09-25 16:09:36',1342177281,'submission.event.fileUploaded',0),
(16,1048585,5,1,'2026-09-25 16:09:36',1342177288,'submission.event.fileRevised',0),
(17,515,5,1,'2026-09-25 16:09:36',1342177296,'submission.event.fileEdited',0),
(18,515,6,1,'2026-09-25 16:09:36',1342177296,'submission.event.fileEdited',0),
(19,515,7,1,'2026-09-25 16:09:36',1342177281,'submission.event.fileUploaded',0),
(20,1048585,6,1,'2026-09-25 16:09:36',1342177288,'submission.event.fileRevised',0),
(21,515,7,1,'2026-09-25 16:09:36',1342177296,'submission.event.fileEdited',0),
(22,515,8,1,'2026-09-25 16:09:36',1342177281,'submission.event.fileUploaded',0),
(23,1048585,7,1,'2026-09-25 16:09:36',1342177288,'submission.event.fileRevised',0),
(24,515,8,1,'2026-09-25 16:09:36',1342177296,'submission.event.fileEdited',0),
(25,515,9,1,'2026-09-25 16:09:36',1342177281,'submission.event.fileUploaded',0),
(26,1048585,8,1,'2026-09-25 16:09:36',1342177288,'submission.event.fileRevised',0),
(27,515,9,1,'2026-09-25 16:09:36',1342177296,'submission.event.fileEdited',0),
(28,515,10,1,'2026-09-25 17:47:52',1342177281,'submission.event.fileUploaded',0),
(29,1048585,9,1,'2026-09-25 17:47:52',1342177288,'submission.event.fileRevised',0),
(30,515,11,1,'2026-09-25 17:47:52',1342177281,'submission.event.fileUploaded',0),
(31,1048585,10,1,'2026-09-25 17:47:52',1342177288,'submission.event.fileRevised',0),
(32,515,12,1,'2026-09-25 17:47:52',1342177281,'submission.event.fileUploaded',0),
(33,1048585,11,1,'2026-09-25 17:47:52',1342177288,'submission.event.fileRevised',0),
(34,515,13,1,'2026-09-25 17:47:52',1342177281,'submission.event.fileUploaded',0),
(35,1048585,12,1,'2026-09-25 17:47:52',1342177288,'submission.event.fileRevised',0),
(36,1048585,10,1,'2026-10-06 21:06:22',805306371,'editor.submission.decision.sendExternalReview.log',0),
(37,515,14,1,'2026-10-06 21:06:22',1342177281,'submission.event.fileUploaded',0),
(38,1048585,10,1,'2026-10-06 21:06:22',1342177288,'submission.event.fileRevised',0),
(39,1048585,10,1,'2026-10-06 21:06:51',1073741825,'log.review.reviewerAssigned',0),
(40,1048585,10,1,'2026-10-06 21:07:04',1073741825,'log.review.reviewerAssigned',0),
(41,1048585,10,212,'2026-10-06 21:08:52',1073741831,'log.review.reviewDeclined',NULL);
/*!40000 ALTER TABLE `event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_log_settings`
--

DROP TABLE IF EXISTS `event_log_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_log_settings` (
  `event_log_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`event_log_setting_id`),
  UNIQUE KEY `event_log_settings_unique` (`log_id`,`setting_name`,`locale`),
  KEY `event_log_settings_log_id` (`log_id`),
  KEY `event_log_settings_name_value` (`setting_name`(50),`setting_value`(150)),
  CONSTRAINT `event_log_settings_log_id` FOREIGN KEY (`log_id`) REFERENCES `event_log` (`log_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=238 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Data about an event log entry. This data is commonly used to display information about an event to a user.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_log_settings`
--

LOCK TABLES `event_log_settings` WRITE;
/*!40000 ALTER TABLE `event_log_settings` DISABLE KEYS */;
INSERT INTO `event_log_settings` VALUES
(1,1,'','fileId','1'),
(2,1,'en','filename','djas-1-1-1.pdf'),
(3,1,'','fileStage','10'),
(4,1,'','submissionFileId','1'),
(5,1,'','submissionId','1'),
(6,1,'','username','admin'),
(7,2,'','fileId','1'),
(8,2,'en','filename','djas-1-1-1.pdf'),
(9,2,'','fileStage','10'),
(10,2,'','submissionFileId','1'),
(11,2,'','submissionId','1'),
(12,2,'','username','admin'),
(13,3,'','fileId','1'),
(14,3,'en','filename','djas-1-1-1.pdf'),
(15,3,'','fileStage','10'),
(16,3,'','submissionFileId','1'),
(17,3,'','submissionId','1'),
(18,3,'','username','admin'),
(19,4,'','fileId','2'),
(20,4,'en','filename','djas-1-1-2.pdf'),
(21,4,'','fileStage','10'),
(22,4,'','submissionFileId','2'),
(23,4,'','submissionId','2'),
(24,4,'','username','admin'),
(25,5,'','fileId','2'),
(26,5,'en','filename','djas-1-1-2.pdf'),
(27,5,'','fileStage','10'),
(28,5,'','submissionFileId','2'),
(29,5,'','submissionId','2'),
(30,5,'','username','admin'),
(31,6,'','fileId','2'),
(32,6,'en','filename','djas-1-1-2.pdf'),
(33,6,'','fileStage','10'),
(34,6,'','submissionFileId','2'),
(35,6,'','submissionId','2'),
(36,6,'','username','admin'),
(37,7,'','fileId','3'),
(38,7,'en','filename','djas-1-1-3.pdf'),
(39,7,'','fileStage','10'),
(40,7,'','submissionFileId','3'),
(41,7,'','submissionId','3'),
(42,7,'','username','admin'),
(43,8,'','fileId','3'),
(44,8,'en','filename','djas-1-1-3.pdf'),
(45,8,'','fileStage','10'),
(46,8,'','submissionFileId','3'),
(47,8,'','submissionId','3'),
(48,8,'','username','admin'),
(49,9,'','fileId','3'),
(50,9,'en','filename','djas-1-1-3.pdf'),
(51,9,'','fileStage','10'),
(52,9,'','submissionFileId','3'),
(53,9,'','submissionId','3'),
(54,9,'','username','admin'),
(55,10,'','fileId','4'),
(56,10,'en','filename','djas-1-1-4.pdf'),
(57,10,'','fileStage','10'),
(58,10,'','submissionFileId','4'),
(59,10,'','submissionId','4'),
(60,10,'','username','admin'),
(61,11,'','fileId','4'),
(62,11,'en','filename','djas-1-1-4.pdf'),
(63,11,'','fileStage','10'),
(64,11,'','submissionFileId','4'),
(65,11,'','submissionId','4'),
(66,11,'','username','admin'),
(67,12,'','fileId','4'),
(68,12,'en','filename','djas-1-1-4.pdf'),
(69,12,'','fileStage','10'),
(70,12,'','submissionFileId','4'),
(71,12,'','submissionId','4'),
(72,12,'','username','admin'),
(73,13,'','fileId','5'),
(74,13,'en','filename','djas-1-2-1.pdf'),
(75,13,'','fileStage','10'),
(76,13,'','submissionFileId','5'),
(77,13,'','submissionId','5'),
(78,13,'','username','admin'),
(79,14,'','fileId','5'),
(80,14,'en','filename','djas-1-2-1.pdf'),
(81,14,'','fileStage','10'),
(82,14,'','submissionFileId','5'),
(83,14,'','submissionId','5'),
(84,14,'','username','admin'),
(85,15,'','fileId','6'),
(86,15,'en','filename','djas-1-2-1.html'),
(87,15,'','fileStage','10'),
(88,15,'','submissionFileId','6'),
(89,15,'','submissionId','5'),
(90,15,'','username','admin'),
(91,16,'','fileId','6'),
(92,16,'en','filename','djas-1-2-1.html'),
(93,16,'','fileStage','10'),
(94,16,'','submissionFileId','6'),
(95,16,'','submissionId','5'),
(96,16,'','username','admin'),
(97,17,'','fileId','5'),
(98,17,'en','filename','djas-1-2-1.pdf'),
(99,17,'','fileStage','10'),
(100,17,'','submissionFileId','5'),
(101,17,'','submissionId','5'),
(102,17,'','username','admin'),
(103,18,'','fileId','6'),
(104,18,'en','filename','djas-1-2-1.html'),
(105,18,'','fileStage','10'),
(106,18,'','submissionFileId','6'),
(107,18,'','submissionId','5'),
(108,18,'','username','admin'),
(109,19,'','fileId','7'),
(110,19,'en','filename','djas-1-2-2.pdf'),
(111,19,'','fileStage','10'),
(112,19,'','submissionFileId','7'),
(113,19,'','submissionId','6'),
(114,19,'','username','admin'),
(115,20,'','fileId','7'),
(116,20,'en','filename','djas-1-2-2.pdf'),
(117,20,'','fileStage','10'),
(118,20,'','submissionFileId','7'),
(119,20,'','submissionId','6'),
(120,20,'','username','admin'),
(121,21,'','fileId','7'),
(122,21,'en','filename','djas-1-2-2.pdf'),
(123,21,'','fileStage','10'),
(124,21,'','submissionFileId','7'),
(125,21,'','submissionId','6'),
(126,21,'','username','admin'),
(127,22,'','fileId','8'),
(128,22,'en','filename','djas-1-2-3.pdf'),
(129,22,'','fileStage','10'),
(130,22,'','submissionFileId','8'),
(131,22,'','submissionId','7'),
(132,22,'','username','admin'),
(133,23,'','fileId','8'),
(134,23,'en','filename','djas-1-2-3.pdf'),
(135,23,'','fileStage','10'),
(136,23,'','submissionFileId','8'),
(137,23,'','submissionId','7'),
(138,23,'','username','admin'),
(139,24,'','fileId','8'),
(140,24,'en','filename','djas-1-2-3.pdf'),
(141,24,'','fileStage','10'),
(142,24,'','submissionFileId','8'),
(143,24,'','submissionId','7'),
(144,24,'','username','admin'),
(145,25,'','fileId','9'),
(146,25,'en','filename','djas-1-2-4.pdf'),
(147,25,'','fileStage','10'),
(148,25,'','submissionFileId','9'),
(149,25,'','submissionId','8'),
(150,25,'','username','admin'),
(151,26,'','fileId','9'),
(152,26,'en','filename','djas-1-2-4.pdf'),
(153,26,'','fileStage','10'),
(154,26,'','submissionFileId','9'),
(155,26,'','submissionId','8'),
(156,26,'','username','admin'),
(157,27,'','fileId','9'),
(158,27,'en','filename','djas-1-2-4.pdf'),
(159,27,'','fileStage','10'),
(160,27,'','submissionFileId','9'),
(161,27,'','submissionId','8'),
(162,27,'','username','admin'),
(163,28,'','fileId','10'),
(164,28,'en','filename','manuscript-101.pdf'),
(165,28,'','fileStage','2'),
(166,28,'','submissionFileId','10'),
(167,28,'','submissionId','9'),
(168,28,'','username','admin'),
(169,29,'','fileId','10'),
(170,29,'en','filename','manuscript-101.pdf'),
(171,29,'','fileStage','2'),
(172,29,'','submissionFileId','10'),
(173,29,'','submissionId','9'),
(174,29,'','username','admin'),
(175,30,'','fileId','11'),
(176,30,'en','filename','manuscript-102.pdf'),
(177,30,'','fileStage','2'),
(178,30,'','submissionFileId','11'),
(179,30,'','submissionId','10'),
(180,30,'','username','admin'),
(181,31,'','fileId','11'),
(182,31,'en','filename','manuscript-102.pdf'),
(183,31,'','fileStage','2'),
(184,31,'','submissionFileId','11'),
(185,31,'','submissionId','10'),
(186,31,'','username','admin'),
(187,32,'','fileId','12'),
(188,32,'en','filename','manuscript-103.pdf'),
(189,32,'','fileStage','2'),
(190,32,'','submissionFileId','12'),
(191,32,'','submissionId','11'),
(192,32,'','username','admin'),
(193,33,'','fileId','12'),
(194,33,'en','filename','manuscript-103.pdf'),
(195,33,'','fileStage','2'),
(196,33,'','submissionFileId','12'),
(197,33,'','submissionId','11'),
(198,33,'','username','admin'),
(199,34,'','fileId','13'),
(200,34,'en','filename','manuscript-104.pdf'),
(201,34,'','fileStage','2'),
(202,34,'','submissionFileId','13'),
(203,34,'','submissionId','12'),
(204,34,'','username','admin'),
(205,35,'','fileId','13'),
(206,35,'en','filename','manuscript-104.pdf'),
(207,35,'','fileStage','2'),
(208,35,'','submissionFileId','13'),
(209,35,'','submissionId','12'),
(210,35,'','username','admin'),
(211,36,'','editorName','admin admin'),
(212,37,'','fileId','11'),
(213,37,'en','filename','manuscript-102.pdf'),
(214,37,'','fileStage','4'),
(215,37,'','sourceSubmissionFileId','11'),
(216,37,'','submissionFileId','14'),
(217,37,'','submissionId','10'),
(218,37,'','username','admin'),
(219,38,'','fileId','11'),
(220,38,'en','filename','manuscript-102.pdf'),
(221,38,'','fileStage','4'),
(222,38,'','sourceSubmissionFileId','11'),
(223,38,'','submissionFileId','14'),
(224,38,'','submissionId','10'),
(225,38,'','username','admin'),
(226,39,'','reviewerName','Peter Lawson'),
(227,39,'','round','1'),
(228,39,'','stageId','3'),
(229,39,'','submissionId','10'),
(230,40,'','reviewerName','Helen Carter'),
(231,40,'','round','1'),
(232,40,'','stageId','3'),
(233,40,'','submissionId','10'),
(234,41,'','reviewAssignmentId','2'),
(235,41,'','reviewerName','Helen Carter'),
(236,41,'','round','1'),
(237,41,'','submissionId','10');
/*!40000 ALTER TABLE `event_log_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A log of all failed jobs.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `mimetype` varchar(255) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Records information in the database about files tracked by the system, linking them to the local filesystem.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES
(1,'journals/1/articles/1/6ab69cbfebce0.pdf','application/pdf'),
(2,'journals/1/articles/2/6ab69cc01d42c.pdf','application/pdf'),
(3,'journals/1/articles/3/6ab69cc035d69.pdf','application/pdf'),
(4,'journals/1/articles/4/6ab69cc04e660.pdf','application/pdf'),
(5,'journals/1/articles/5/6ab69cc071232.pdf','application/pdf'),
(6,'journals/1/articles/5/6ab69cc0753c4.html','text/html'),
(7,'journals/1/articles/6/6ab69cc0972cc.pdf','application/pdf'),
(8,'journals/1/articles/7/6ab69cc0ac8c8.pdf','application/pdf'),
(9,'journals/1/articles/8/6ab69cc0c4a36.pdf','application/pdf'),
(10,'journals/1/articles/9/6ab6b3c85cfa4.pdf','application/pdf'),
(11,'journals/1/articles/10/6ab6b3c877194.pdf','application/pdf'),
(12,'journals/1/articles/11/6ab6b3c88b402.pdf','application/pdf'),
(13,'journals/1/articles/12/6ab6b3c89d028.pdf','application/pdf');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_groups`
--

DROP TABLE IF EXISTS `filter_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter_groups` (
  `filter_group_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `symbolic` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `input_type` varchar(255) DEFAULT NULL,
  `output_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`filter_group_id`),
  UNIQUE KEY `filter_groups_symbolic` (`symbolic`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Filter groups are used to organized filters into named sets, which can be retrieved by the application for invocation.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_groups`
--

LOCK TABLES `filter_groups` WRITE;
/*!40000 ALTER TABLE `filter_groups` DISABLE KEYS */;
INSERT INTO `filter_groups` VALUES
(1,'issue=>crossref-xml','plugins.importexport.crossref.displayName','plugins.importexport.crossref.description','class::classes.issue.Issue[]','xml::schema(https://www.crossref.org/schemas/crossref5.4.0.xsd)'),
(2,'article=>crossref-xml','plugins.importexport.crossref.displayName','plugins.importexport.crossref.description','class::classes.submission.Submission[]','xml::schema(https://www.crossref.org/schemas/crossref5.4.0.xsd)'),
(3,'issue=>datacite-xml','plugins.importexport.datacite.displayName','plugins.importexport.datacite.description','class::classes.issue.Issue','xml::schema(http://schema.datacite.org/meta/kernel-4/metadata.xsd)'),
(4,'article=>datacite-xml','plugins.importexport.datacite.displayName','plugins.importexport.datacite.description','class::classes.submission.Submission','xml::schema(http://schema.datacite.org/meta/kernel-4/metadata.xsd)'),
(5,'galley=>datacite-xml','plugins.importexport.datacite.displayName','plugins.importexport.datacite.description','class::lib.pkp.classes.galley.Galley','xml::schema(http://schema.datacite.org/meta/kernel-4/metadata.xsd)'),
(6,'article=>dc11','plugins.metadata.dc11.articleAdapter.displayName','plugins.metadata.dc11.articleAdapter.description','class::classes.submission.Submission','metadata::APP\\plugins\\metadata\\dc11\\schema\\Dc11Schema(ARTICLE)'),
(7,'user=>user-xml','plugins.importexport.users.displayName','plugins.importexport.users.description','class::PKP\\user\\User[]','xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)'),
(8,'user-xml=>user','plugins.importexport.users.displayName','plugins.importexport.users.description','xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)','class::PKP\\user\\User[]'),
(9,'usergroup=>user-xml','plugins.importexport.users.displayName','plugins.importexport.users.description','class::PKP\\userGroup\\UserGroup[]','xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)'),
(10,'user-xml=>usergroup','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)','class::PKP\\userGroup\\UserGroup[]'),
(11,'article=>pubmed-xml','plugins.importexport.pubmed.displayName','plugins.importexport.pubmed.description','class::classes.submission.Submission[]','xml::dtd'),
(12,'article=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.submission.Submission[]','xml::schema(plugins/importexport/native/native.xsd)'),
(13,'native-xml=>article','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.submission.Submission[]'),
(14,'issue=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.issue.Issue[]','xml::schema(plugins/importexport/native/native.xsd)'),
(15,'native-xml=>issue','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.issue.Issue[]'),
(16,'issuegalley=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.issue.IssueGalley[]','xml::schema(plugins/importexport/native/native.xsd)'),
(17,'native-xml=>issuegalley','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.issue.IssueGalley[]'),
(18,'author=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.author.Author[]','xml::schema(plugins/importexport/native/native.xsd)'),
(19,'native-xml=>author','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.author.Author[]'),
(20,'SubmissionFile=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::lib.pkp.classes.submissionFile.SubmissionFile','xml::schema(plugins/importexport/native/native.xsd)'),
(21,'native-xml=>SubmissionFile','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::lib.pkp.classes.submissionFile.SubmissionFile[]'),
(22,'article-galley=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::lib.pkp.classes.galley.Galley','xml::schema(plugins/importexport/native/native.xsd)'),
(23,'native-xml=>ArticleGalley','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::lib.pkp.classes.galley.Galley[]'),
(24,'publication=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.publication.Publication','xml::schema(plugins/importexport/native/native.xsd)'),
(25,'native-xml=>Publication','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.publication.Publication[]'),
(26,'article=>doaj-xml','plugins.importexport.doaj.displayName','plugins.importexport.doaj.description','class::classes.submission.Submission[]','xml::schema(plugins/importexport/doaj/doajArticles.xsd)'),
(27,'article=>doaj-json','plugins.importexport.doaj.displayName','plugins.importexport.doaj.description','class::classes.submission.Submission','primitive::string');
/*!40000 ALTER TABLE `filter_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_settings`
--

DROP TABLE IF EXISTS `filter_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter_settings` (
  `filter_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filter_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`filter_setting_id`),
  UNIQUE KEY `filter_settings_unique` (`filter_id`,`locale`,`setting_name`),
  KEY `filter_settings_id` (`filter_id`),
  CONSTRAINT `filter_settings_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `filters` (`filter_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about filters, including localized content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_settings`
--

LOCK TABLES `filter_settings` WRITE;
/*!40000 ALTER TABLE `filter_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `filter_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters`
--

DROP TABLE IF EXISTS `filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `filters` (
  `filter_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `filter_group_id` bigint(20) NOT NULL,
  `context_id` bigint(20) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `is_template` smallint(6) NOT NULL DEFAULT 0,
  `parent_filter_id` bigint(20) DEFAULT NULL,
  `seq` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`filter_id`),
  KEY `filters_filter_group_id` (`filter_group_id`),
  KEY `filters_context_id` (`context_id`),
  KEY `filters_parent_filter_id` (`parent_filter_id`),
  CONSTRAINT `filters_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `filters_filter_group_id_foreign` FOREIGN KEY (`filter_group_id`) REFERENCES `filter_groups` (`filter_group_id`) ON DELETE CASCADE,
  CONSTRAINT `filters_parent_filter_id_foreign` FOREIGN KEY (`parent_filter_id`) REFERENCES `filters` (`filter_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Filters represent a transformation of a supported piece of data from one form to another, such as a PHP object into an XML document.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filters`
--

LOCK TABLES `filters` WRITE;
/*!40000 ALTER TABLE `filters` DISABLE KEYS */;
INSERT INTO `filters` VALUES
(1,1,NULL,'Crossref XML issue export','APP\\plugins\\generic\\crossref\\filter\\IssueCrossrefXmlFilter',0,NULL,0),
(2,2,NULL,'Crossref XML article export','APP\\plugins\\generic\\crossref\\filter\\ArticleCrossrefXmlFilter',0,NULL,0),
(3,3,NULL,'DataCite XML export','APP\\plugins\\generic\\datacite\\filter\\DataciteXmlFilter',0,NULL,0),
(4,4,NULL,'DataCite XML export','APP\\plugins\\generic\\datacite\\filter\\DataciteXmlFilter',0,NULL,0),
(5,5,NULL,'DataCite XML export','APP\\plugins\\generic\\datacite\\filter\\DataciteXmlFilter',0,NULL,0),
(6,6,NULL,'Extract metadata from a(n) Submission','APP\\plugins\\metadata\\dc11\\filter\\Dc11SchemaArticleAdapter',0,NULL,0),
(7,7,NULL,'User XML user export','PKP\\plugins\\importexport\\users\\filter\\PKPUserUserXmlFilter',0,NULL,0),
(8,8,NULL,'User XML user import','PKP\\plugins\\importexport\\users\\filter\\UserXmlPKPUserFilter',0,NULL,0),
(9,9,NULL,'Native XML user group export','PKP\\plugins\\importexport\\users\\filter\\UserGroupNativeXmlFilter',0,NULL,0),
(10,10,NULL,'Native XML user group import','PKP\\plugins\\importexport\\users\\filter\\NativeXmlUserGroupFilter',0,NULL,0),
(11,11,NULL,'APP\\plugins\\importexport\\pubmed\\filter\\ArticlePubMedXmlFilter','APP\\plugins\\importexport\\pubmed\\filter\\ArticlePubMedXmlFilter',0,NULL,0),
(12,12,NULL,'Native XML submission export','APP\\plugins\\importexport\\native\\filter\\ArticleNativeXmlFilter',0,NULL,0),
(13,13,NULL,'Native XML submission import','APP\\plugins\\importexport\\native\\filter\\NativeXmlArticleFilter',0,NULL,0),
(14,14,NULL,'Native XML issue export','APP\\plugins\\importexport\\native\\filter\\IssueNativeXmlFilter',0,NULL,0),
(15,15,NULL,'Native XML issue import','APP\\plugins\\importexport\\native\\filter\\NativeXmlIssueFilter',0,NULL,0),
(16,16,NULL,'Native XML issue galley export','APP\\plugins\\importexport\\native\\filter\\IssueGalleyNativeXmlFilter',0,NULL,0),
(17,17,NULL,'Native XML issue galley import','APP\\plugins\\importexport\\native\\filter\\NativeXmlIssueGalleyFilter',0,NULL,0),
(18,18,NULL,'Native XML author export','APP\\plugins\\importexport\\native\\filter\\AuthorNativeXmlFilter',0,NULL,0),
(19,19,NULL,'Native XML author import','APP\\plugins\\importexport\\native\\filter\\NativeXmlAuthorFilter',0,NULL,0),
(20,21,NULL,'Native XML submission file import','APP\\plugins\\importexport\\native\\filter\\NativeXmlArticleFileFilter',0,NULL,0),
(21,20,NULL,'Native XML submission file export','PKP\\plugins\\importexport\\native\\filter\\SubmissionFileNativeXmlFilter',0,NULL,0),
(22,22,NULL,'Native XML representation export','APP\\plugins\\importexport\\native\\filter\\ArticleGalleyNativeXmlFilter',0,NULL,0),
(23,23,NULL,'Native XML representation import','APP\\plugins\\importexport\\native\\filter\\NativeXmlArticleGalleyFilter',0,NULL,0),
(24,24,NULL,'Native XML Publication export','APP\\plugins\\importexport\\native\\filter\\PublicationNativeXmlFilter',0,NULL,0),
(25,25,NULL,'Native XML publication import','APP\\plugins\\importexport\\native\\filter\\NativeXmlPublicationFilter',0,NULL,0),
(26,26,NULL,'DOAJ XML export','APP\\plugins\\importexport\\doaj\\filter\\DOAJXmlFilter',0,NULL,0),
(27,27,NULL,'DOAJ JSON export','APP\\plugins\\importexport\\doaj\\filter\\DOAJJsonFilter',0,NULL,0);
/*!40000 ALTER TABLE `filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genre_settings`
--

DROP TABLE IF EXISTS `genre_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `genre_settings` (
  `genre_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `genre_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`genre_setting_id`),
  UNIQUE KEY `genre_settings_unique` (`genre_id`,`locale`,`setting_name`),
  KEY `genre_settings_genre_id` (`genre_id`),
  CONSTRAINT `genre_settings_genre_id_foreign` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`genre_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about file genres, including localized properties such as the genre name.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genre_settings`
--

LOCK TABLES `genre_settings` WRITE;
/*!40000 ALTER TABLE `genre_settings` DISABLE KEYS */;
INSERT INTO `genre_settings` VALUES
(1,1,'en','name','Article Text','string'),
(2,2,'en','name','Research Instrument','string'),
(3,3,'en','name','Research Materials','string'),
(4,4,'en','name','Research Results','string'),
(5,5,'en','name','Transcripts','string'),
(6,6,'en','name','Data Analysis','string'),
(7,7,'en','name','Data Set','string'),
(8,8,'en','name','Source Texts','string'),
(9,9,'en','name','Multimedia','string'),
(10,10,'en','name','Image','string'),
(11,11,'en','name','HTML Stylesheet','string'),
(12,12,'en','name','Other','string');
/*!40000 ALTER TABLE `genre_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genres`
--

DROP TABLE IF EXISTS `genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `genres` (
  `genre_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `seq` bigint(20) NOT NULL,
  `enabled` smallint(6) NOT NULL DEFAULT 1,
  `category` bigint(20) NOT NULL DEFAULT 1,
  `dependent` smallint(6) NOT NULL DEFAULT 0,
  `supplementary` smallint(6) NOT NULL DEFAULT 0,
  `required` smallint(6) NOT NULL DEFAULT 0 COMMENT 'Whether or not at least one file of this genre is required for a new submission.',
  `entry_key` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`genre_id`),
  KEY `genres_context_id` (`context_id`),
  CONSTRAINT `genres_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='The types of submission files configured for each context, such as Article Text, Data Set, Transcript, etc.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genres`
--

LOCK TABLES `genres` WRITE;
/*!40000 ALTER TABLE `genres` DISABLE KEYS */;
INSERT INTO `genres` VALUES
(1,1,0,1,1,0,0,1,'SUBMISSION'),
(2,1,1,1,3,0,1,0,'RESEARCHINSTRUMENT'),
(3,1,2,1,3,0,1,0,'RESEARCHMATERIALS'),
(4,1,3,1,3,0,1,0,'RESEARCHRESULTS'),
(5,1,4,1,3,0,1,0,'TRANSCRIPTS'),
(6,1,5,1,3,0,1,0,'DATAANALYSIS'),
(7,1,6,1,3,0,1,0,'DATASET'),
(8,1,7,1,3,0,1,0,'SOURCETEXTS'),
(9,1,8,1,1,1,1,0,'MULTIMEDIA'),
(10,1,9,1,2,1,0,0,'IMAGE'),
(11,1,10,1,1,1,0,0,'STYLE'),
(12,1,11,1,3,0,1,0,'OTHER');
/*!40000 ALTER TABLE `genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `highlight_settings`
--

DROP TABLE IF EXISTS `highlight_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `highlight_settings` (
  `highlight_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `highlight_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`highlight_setting_id`),
  UNIQUE KEY `highlight_settings_unique` (`highlight_id`,`locale`,`setting_name`),
  KEY `highlight_settings_highlight_id` (`highlight_id`),
  CONSTRAINT `highlight_settings_highlight_id_foreign` FOREIGN KEY (`highlight_id`) REFERENCES `highlights` (`highlight_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about highlights, including localized properties like title and description.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `highlight_settings`
--

LOCK TABLES `highlight_settings` WRITE;
/*!40000 ALTER TABLE `highlight_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `highlight_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `highlights`
--

DROP TABLE IF EXISTS `highlights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `highlights` (
  `highlight_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) DEFAULT NULL,
  `sequence` bigint(20) NOT NULL,
  `url` varchar(2047) NOT NULL,
  PRIMARY KEY (`highlight_id`),
  KEY `highlights_context_id` (`context_id`),
  CONSTRAINT `highlights_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Highlights are featured items that can be presented to users, for example on the homepage.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `highlights`
--

LOCK TABLES `highlights` WRITE;
/*!40000 ALTER TABLE `highlights` DISABLE KEYS */;
/*!40000 ALTER TABLE `highlights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institution_ip`
--

DROP TABLE IF EXISTS `institution_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `institution_ip` (
  `institution_ip_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `institution_id` bigint(20) NOT NULL,
  `ip_string` varchar(40) NOT NULL,
  `ip_start` bigint(20) NOT NULL,
  `ip_end` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`institution_ip_id`),
  KEY `institution_ip_institution_id` (`institution_id`),
  KEY `institution_ip_start` (`ip_start`),
  KEY `institution_ip_end` (`ip_end`),
  CONSTRAINT `institution_ip_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Records IP address ranges and associates them with institutions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institution_ip`
--

LOCK TABLES `institution_ip` WRITE;
/*!40000 ALTER TABLE `institution_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `institution_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institution_settings`
--

DROP TABLE IF EXISTS `institution_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `institution_settings` (
  `institution_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `institution_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`institution_setting_id`),
  UNIQUE KEY `institution_settings_unique` (`institution_id`,`locale`,`setting_name`),
  KEY `institution_settings_institution_id` (`institution_id`),
  CONSTRAINT `institution_settings_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about institutions, including localized properties like names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institution_settings`
--

LOCK TABLES `institution_settings` WRITE;
/*!40000 ALTER TABLE `institution_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `institution_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institutional_subscriptions`
--

DROP TABLE IF EXISTS `institutional_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `institutional_subscriptions` (
  `institutional_subscription_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint(20) NOT NULL,
  `institution_id` bigint(20) NOT NULL,
  `mailing_address` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`institutional_subscription_id`),
  KEY `institutional_subscriptions_subscription_id` (`subscription_id`),
  KEY `institutional_subscriptions_institution_id` (`institution_id`),
  KEY `institutional_subscriptions_domain` (`domain`),
  CONSTRAINT `institutional_subscriptions_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE,
  CONSTRAINT `institutional_subscriptions_subscription_id` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`subscription_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A list of institutional subscriptions, linking a subscription with an institution.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institutional_subscriptions`
--

LOCK TABLES `institutional_subscriptions` WRITE;
/*!40000 ALTER TABLE `institutional_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `institutional_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institutions`
--

DROP TABLE IF EXISTS `institutions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `institutions` (
  `institution_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `ror` varchar(255) DEFAULT NULL COMMENT 'ROR (Research Organization Registry) ID',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`institution_id`),
  KEY `institutions_context_id` (`context_id`),
  CONSTRAINT `institutions_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Institutions for statistics and subscriptions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institutions`
--

LOCK TABLES `institutions` WRITE;
/*!40000 ALTER TABLE `institutions` DISABLE KEYS */;
/*!40000 ALTER TABLE `institutions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invitations`
--

DROP TABLE IF EXISTS `invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invitations` (
  `invitation_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `key_hash` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `inviter_id` bigint(20) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `status` enum('INITIALIZED','PENDING','ACCEPTED','DECLINED','CANCELLED') NOT NULL,
  `email` varchar(255) DEFAULT NULL COMMENT 'When present, the email address of the invitation recipient; when null, user_id must be set and the email can be fetched from the users table.',
  `context_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`invitation_id`),
  KEY `invitations_user_id` (`user_id`),
  KEY `invitations_inviter_id` (`inviter_id`),
  KEY `invitations_context_id` (`context_id`),
  KEY `invitations_status_context_id_user_id_type_index` (`status`,`context_id`,`user_id`,`type`),
  KEY `invitations_expiry_date_index` (`expiry_date`),
  CONSTRAINT `invitations_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `invitations_inviter_id_foreign` FOREIGN KEY (`inviter_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `invitations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Invitations are sent to request a person (by email) to allow them to accept or reject an operation or position, such as a board membership or a submission peer review.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitations`
--

LOCK TABLES `invitations` WRITE;
/*!40000 ALTER TABLE `invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_files`
--

DROP TABLE IF EXISTS `issue_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_files` (
  `file_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(20) NOT NULL,
  `file_name` varchar(90) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `content_type` bigint(20) NOT NULL,
  `original_file_name` varchar(127) DEFAULT NULL,
  `date_uploaded` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  KEY `issue_files_issue_id` (`issue_id`),
  CONSTRAINT `issue_files_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Relationships between issues and issue files, such as cover images.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_files`
--

LOCK TABLES `issue_files` WRITE;
/*!40000 ALTER TABLE `issue_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_galley_settings`
--

DROP TABLE IF EXISTS `issue_galley_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_galley_settings` (
  `issue_galley_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `galley_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`issue_galley_setting_id`),
  UNIQUE KEY `issue_galley_settings_unique` (`galley_id`,`locale`,`setting_name`),
  KEY `issue_galley_settings_galley_id` (`galley_id`),
  CONSTRAINT `issue_galleys_settings_galley_id` FOREIGN KEY (`galley_id`) REFERENCES `issue_galleys` (`galley_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about issue galleys, including localized content such as labels.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_galley_settings`
--

LOCK TABLES `issue_galley_settings` WRITE;
/*!40000 ALTER TABLE `issue_galley_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_galley_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_galleys`
--

DROP TABLE IF EXISTS `issue_galleys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_galleys` (
  `galley_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `locale` varchar(28) DEFAULT NULL,
  `issue_id` bigint(20) NOT NULL,
  `file_id` bigint(20) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `seq` double NOT NULL DEFAULT 0,
  `url_path` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`galley_id`),
  KEY `issue_galleys_issue_id` (`issue_id`),
  KEY `issue_galleys_file_id` (`file_id`),
  KEY `issue_galleys_url_path` (`url_path`),
  CONSTRAINT `issue_galleys_file_id` FOREIGN KEY (`file_id`) REFERENCES `issue_files` (`file_id`) ON DELETE CASCADE,
  CONSTRAINT `issue_galleys_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Issue galleys are representations of the entire issue in a single file, such as a complete issue PDF.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_galleys`
--

LOCK TABLES `issue_galleys` WRITE;
/*!40000 ALTER TABLE `issue_galleys` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_galleys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_settings`
--

DROP TABLE IF EXISTS `issue_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_settings` (
  `issue_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`issue_setting_id`),
  UNIQUE KEY `issue_settings_unique` (`issue_id`,`locale`,`setting_name`),
  KEY `issue_settings_issue_id` (`issue_id`),
  KEY `issue_settings_name_value` (`setting_name`(50),`setting_value`(150)),
  CONSTRAINT `issue_settings_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about issues, including localized properties such as issue titles.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_settings`
--

LOCK TABLES `issue_settings` WRITE;
/*!40000 ALTER TABLE `issue_settings` DISABLE KEYS */;
INSERT INTO `issue_settings` VALUES
(1,1,'en','coverImage','cover-v1-n1.png'),
(2,1,'en','coverImageAltText','Cover of Volume 1, Issue 1'),
(3,1,'en','description','<p>The inaugural issue: nutrition, udder health, equine welfare and feline anaesthesia.</p>'),
(4,2,'en','coverImage','cover-v1-n2.png'),
(5,2,'en','coverImageAltText','Cover of Volume 1, Issue 2'),
(6,2,'en','description','<p>This issue brings together work on heat stress in dairy cattle, antimicrobial resistance surveillance, laboratory rabbit reference intervals and emergency surgery in large-breed dogs.</p>');
/*!40000 ALTER TABLE `issue_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `issues` (
  `issue_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `journal_id` bigint(20) NOT NULL,
  `volume` smallint(6) DEFAULT NULL,
  `number` varchar(40) DEFAULT NULL,
  `year` smallint(6) DEFAULT NULL,
  `published` smallint(6) NOT NULL DEFAULT 0,
  `date_published` datetime DEFAULT NULL,
  `date_notified` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `access_status` smallint(6) NOT NULL DEFAULT 1,
  `open_access_date` datetime DEFAULT NULL,
  `show_volume` smallint(6) NOT NULL DEFAULT 0,
  `show_number` smallint(6) NOT NULL DEFAULT 0,
  `show_year` smallint(6) NOT NULL DEFAULT 0,
  `show_title` smallint(6) NOT NULL DEFAULT 0,
  `style_file_name` varchar(90) DEFAULT NULL,
  `original_style_file_name` varchar(255) DEFAULT NULL,
  `url_path` varchar(64) DEFAULT NULL,
  `doi_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`issue_id`),
  KEY `issues_journal_id` (`journal_id`),
  KEY `issues_doi_id` (`doi_id`),
  KEY `issues_url_path` (`url_path`),
  CONSTRAINT `issues_doi_id_foreign` FOREIGN KEY (`doi_id`) REFERENCES `dois` (`doi_id`) ON DELETE SET NULL,
  CONSTRAINT `issues_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A list of all journal issues, with identifying information like year, number, volume, etc.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES
(1,1,1,'1',2026,1,'2026-03-15 00:00:00',NULL,'2026-09-25 16:09:36',1,NULL,1,1,1,0,NULL,NULL,NULL,NULL),
(2,1,1,'2',2026,1,'2026-06-15 00:00:00',NULL,'2026-09-25 16:09:36',1,NULL,1,1,1,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` text NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Job batches allow jobs to be collected into groups for managed processing.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
INSERT INTO `job_batches` VALUES
('a2d4e4ed-57d7-40d7-8d5c-9659e81e4d31','',1,0,0,'[]','a:0:{}',NULL,1790352575,1790352575),
('a2d4e4ed-7b5e-4150-a9d6-fa92b5454dfb','',1,0,0,'[]','a:0:{}',NULL,1790352575,1790352575);
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='All pending or in-progress jobs.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_settings`
--

DROP TABLE IF EXISTS `journal_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal_settings` (
  `journal_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `journal_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`journal_setting_id`),
  UNIQUE KEY `journal_settings_unique` (`journal_id`,`locale`,`setting_name`),
  KEY `journal_settings_journal_id` (`journal_id`),
  CONSTRAINT `journal_settings_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about journals, including localized properties like policies.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_settings`
--

LOCK TABLES `journal_settings` WRITE;
/*!40000 ALTER TABLE `journal_settings` DISABLE KEYS */;
INSERT INTO `journal_settings` VALUES
(1,1,'en','acronym','DJAS'),
(2,1,'en','authorGuidelines','<p>Authors are invited to make a submission to this journal. All submissions will be assessed by an editor to determine whether they meet the aims and scope of this journal. Those considered to be a good fit will be sent for peer review before determining whether they will be accepted or rejected.</p><p>Before making a submission, authors are responsible for obtaining permission to publish any material included with the submission, such as photos, documents and datasets. All authors identified on the submission must consent to be identified as an author. Where appropriate, research should be approved by an appropriate ethics committee in accordance with the legal requirements of the study\'s country.</p><p>An editor may desk reject a submission if it does not meet minimum standards of quality. Before submitting, please ensure that the study design and research argument are structured and articulated properly. The title should be concise and the abstract should be able to stand on its own. This will increase the likelihood of reviewers agreeing to review the paper. When you\'re satisfied that your submission meets this standard, please follow the checklist below to prepare your submission.</p>'),
(3,1,'en','authorInformation','Interested in submitting to this journal? We recommend that you review the <a href=\"http://localhost:8080/djas/about\">About the Journal</a> page for the journal\'s section policies, as well as the <a href=\"http://localhost:8080/djas/about/submissions#authorGuidelines\">Author Guidelines</a>. Authors need to <a href=\"http://localhost:8080/djas/user/register\">register</a> with the journal prior to submitting or, if already registered, can simply <a href=\"http://localhost:8080/index/login\">log in</a> and begin the five-step process.'),
(4,1,'en','beginSubmissionHelp','<p>Thank you for submitting to the Demo Journal of Animal Science. You will be asked to upload files, identify co-authors, and provide information such as the title and abstract.</p><p>Please read our <a href=\"http://localhost:8080/djas/about/submissions\" target=\"_blank\">Submission Guidelines</a> if you have not done so already. When filling out the forms, provide as many details as possible in order to help our editors evaluate your work.</p><p>Once you begin, you can save your submission and come back to it later. You will be able to review and correct any information before you submit.</p>'),
(5,1,'','citations','request'),
(6,1,'','contactEmail','editor@example.org'),
(7,1,'','contactName','Editorial Office'),
(8,1,'en','contributorsHelp','<p>Add details for all of the contributors to this submission. Contributors added here will be sent an email confirmation of the submission, as well as a copy of all editorial decisions recorded against this submission.</p><p>If a contributor can not be contacted by email, because they must remain anonymous or do not have an email account, please do not enter a fake email address. You can add information about this contributor in a message to the editor at a later step in the submission process.</p>'),
(9,1,'','country','GB'),
(10,1,'','defaultReviewMode','2'),
(11,1,'en','detailsHelp','<p>Please provide the following details to help us manage your submission in our system.</p>'),
(12,1,'','copySubmissionAckPrimaryContact','0'),
(13,1,'','copySubmissionAckAddress',''),
(14,1,'','emailSignature','<br><br>—<br><p>This is an automated message from <a href=\"http://localhost:8080/djas\">Demo Journal of Animal Science</a>.</p>'),
(15,1,'','enableDois','1'),
(16,1,'','doiSuffixType','default'),
(17,1,'','registrationAgency',''),
(18,1,'','disableSubmissions','0'),
(19,1,'','editorialStatsEmail','1'),
(20,1,'en','forTheEditorsHelp','<p>Please provide the following details in order to help our editorial team manage your submission.</p><p>When entering metadata, provide entries that you think would be most helpful to the person managing your submission. This information can be changed before publication.</p>'),
(21,1,'','itemsPerPage','25'),
(22,1,'','keywords','request'),
(23,1,'en','librarianInformation','We encourage research librarians to list this journal among their library\'s electronic journal holdings. As well, it may be worth noting that this journal\'s open source publishing system is suitable for libraries to host for their faculty members to use with journals they are involved in editing (see <a href=\"https://pkp.sfu.ca/ojs\">Open Journal Systems</a>).'),
(24,1,'en','name','Demo Journal of Animal Science'),
(25,1,'','notifyAllAuthors','1'),
(26,1,'','numPageLinks','10'),
(27,1,'','numWeeksPerResponse','4'),
(28,1,'','numWeeksPerReview','4'),
(29,1,'','numReviewsPerSubmission','0'),
(30,1,'en','openAccessPolicy','This journal provides immediate open access to its content on the principle that making research freely available to the public supports a greater global exchange of knowledge.'),
(31,1,'','orcidCity',''),
(32,1,'','orcidClientId',''),
(33,1,'','orcidClientSecret',''),
(34,1,'','orcidEnabled','0'),
(35,1,'','orcidLogLevel','ERROR'),
(36,1,'','orcidSendMailToAuthorsOnPublication','0'),
(37,1,'en','privacyStatement','<p>The names and email addresses entered in this journal site will be used exclusively for the stated purposes of this journal and will not be made available for any other purpose or to any other party.</p>'),
(38,1,'en','readerInformation','We encourage readers to sign up for the publishing notification service for this journal. Use the <a href=\"http://localhost:8080/djas/user/register\">Register</a> link at the top of the home page for the journal. This registration will result in the reader receiving the Table of Contents by email for each new issue of the journal. This list also allows the journal to claim a certain level of support or readership. See the journal\'s <a href=\"http://localhost:8080/djas/about/submissions#privacyStatement\">Privacy Statement</a>, which assures readers that their name and email address will not be used for other purposes.'),
(39,1,'en','reviewHelp','<p>Review the information you have entered before you complete your submission. You can change any of the details displayed here by clicking the edit button at the top of each section.</p><p>Once you complete your submission, a member of our editorial team will be assigned to review it. Please ensure the details you have entered here are as accurate as possible.</p>'),
(40,1,'','submissionAcknowledgement','allAuthors'),
(41,1,'en','submissionChecklist','<p>All submissions must meet the following requirements.</p><ul><li>This submission meets the requirements outlined in the <a href=\"http://localhost:8080/djas/about/submissions\">Author Guidelines</a>.</li><li>This submission has not been previously published, nor is it before another journal for consideration.</li><li>All references have been checked for accuracy and completeness.</li><li>All tables and figures have been numbered and labeled.</li><li>Permission has been obtained to publish all photos, datasets and other material provided with this submission.</li></ul>'),
(42,1,'','submitWithCategories','0'),
(43,1,'','supportedAddedSubmissionLocales','[\"en\"]'),
(44,1,'','supportedDefaultSubmissionLocale','en'),
(45,1,'','supportedFormLocales','[\"en\"]'),
(46,1,'','supportedLocales','[\"en\"]'),
(47,1,'','supportedSubmissionLocales','[\"en\"]'),
(48,1,'','supportedSubmissionMetadataLocales','[\"en\"]'),
(49,1,'','themePluginPath','meridian'),
(50,1,'en','uploadFilesHelp','<p>Provide any files our editorial team may need to evaluate your submission. In addition to the main work, you may wish to submit data sets, conflict of interest statements, or other supplementary files if these will be helpful for our editors.</p>'),
(52,1,'','enableInstitutionUsageStats','0'),
(53,1,'','isSushiApiPublic','1'),
(54,1,'en','abbreviation','Demo J. Anim. Sci.'),
(55,1,'en','clockssLicense','This journal utilizes the CLOCKSS system to create a distributed archiving system among participating libraries and permits those libraries to create permanent archives of the journal for purposes of preservation and restoration. <a href=\"https://clockss.org\">More...</a>'),
(56,1,'','copyrightYearBasis','issue'),
(57,1,'','enabledDoiTypes','[\"publication\"]'),
(58,1,'','doiCreationTime','copyEditCreationTime'),
(59,1,'','enableOai','1'),
(60,1,'en','lockssLicense','This journal utilizes the LOCKSS system to create a distributed archiving system among participating libraries and permits those libraries to create permanent archives of the journal for purposes of preservation and restoration. <a href=\"https://www.lockss.org\">More...</a>'),
(61,1,'','membershipFee','0'),
(62,1,'','publicationFee','0'),
(63,1,'','purchaseArticleFee','0'),
(64,1,'','doiVersioning','0'),
(65,1,'en','reviewerSuggestionsHelp','<p>When submitting, you have the option to suggest several potential reviewers. This can help streamline the review process and provide valueable input for the editorial team. Please choose reviewers who are expert in your field and have no conflict of interest with your work. This feature aims to enhance the review process and support a more efficient experience for both authors and editorial team.</p>'),
(66,1,'en','about','<p>The <em>Demo Journal of Animal Science</em> is a placeholder journal used to design and test this website. All articles, authors and affiliations shown are fictional.</p><p>The journal follows a double-anonymous peer-review process, publishes under the Creative Commons Attribution 4.0 licence and charges no fees to read.</p>'),
(67,1,'','copyrightHolderType','author'),
(68,1,'en','description','<p>An international, peer-reviewed, open access journal publishing original research, reviews and case reports across animal and veterinary science — from animal health and welfare to production, nutrition and laboratory animal medicine.</p>'),
(69,1,'','enableAnnouncements','1'),
(70,1,'','licenseUrl','https://creativecommons.org/licenses/by/4.0/'),
(71,1,'','numAnnouncementsHomepage','3'),
(72,1,'','supportEmail','support@example.org'),
(73,1,'','supportName','Technical Support'),
(74,1,'','onlineIssn','0000-0000'),
(75,1,'','publisherInstitution','Demo Academic Publishing'),
(76,1,'','reviewerSuggestionEnabled','1'),
(77,1,'','enableGeoUsageStats','country');
/*!40000 ALTER TABLE `journal_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journals`
--

DROP TABLE IF EXISTS `journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `journals` (
  `journal_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `path` varchar(32) NOT NULL,
  `seq` double NOT NULL DEFAULT 0 COMMENT 'Used to order lists of journals',
  `primary_locale` varchar(28) NOT NULL,
  `enabled` smallint(6) NOT NULL DEFAULT 1 COMMENT 'Controls whether or not the journal is considered "live" and will appear on the website. (Note that disabled journals may still be accessible, but only if the user knows the URL.)',
  `current_issue_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`journal_id`),
  UNIQUE KEY `journals_path` (`path`),
  KEY `journals_issue_id` (`current_issue_id`),
  CONSTRAINT `journals_current_issue_id_foreign` FOREIGN KEY (`current_issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A list of all journals in the installation of OJS.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journals`
--

LOCK TABLES `journals` WRITE;
/*!40000 ALTER TABLE `journals` DISABLE KEYS */;
INSERT INTO `journals` VALUES
(1,'djas',1,'en',1,2);
/*!40000 ALTER TABLE `journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_file_settings`
--

DROP TABLE IF EXISTS `library_file_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_file_settings` (
  `library_file_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object|date)',
  PRIMARY KEY (`library_file_setting_id`),
  UNIQUE KEY `library_file_settings_unique` (`file_id`,`locale`,`setting_name`),
  KEY `library_file_settings_file_id` (`file_id`),
  CONSTRAINT `library_file_settings_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `library_files` (`file_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about library files, including localized content such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_file_settings`
--

LOCK TABLES `library_file_settings` WRITE;
/*!40000 ALTER TABLE `library_file_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_file_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_files`
--

DROP TABLE IF EXISTS `library_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_files` (
  `file_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `original_file_name` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `type` smallint(6) NOT NULL,
  `date_uploaded` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `submission_id` bigint(20) DEFAULT NULL,
  `public_access` smallint(6) DEFAULT 0,
  PRIMARY KEY (`file_id`),
  KEY `library_files_context_id` (`context_id`),
  KEY `library_files_submission_id` (`submission_id`),
  CONSTRAINT `library_files_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `library_files_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Library files can be associated with the context (press/server/journal) or with individual submissions, and are typically forms, agreements, and other administrative documents that are not part of the scholarly content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_files`
--

LOCK TABLES `library_files` WRITE;
/*!40000 ALTER TABLE `library_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_context`
--

DROP TABLE IF EXISTS `metrics_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_context` (
  `metrics_context_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `date` date NOT NULL,
  `metric` int(11) NOT NULL,
  PRIMARY KEY (`metrics_context_id`),
  KEY `metrics_context_load_id` (`load_id`),
  KEY `metrics_context_context_id` (`context_id`),
  CONSTRAINT `metrics_context_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Daily statistics for views of the homepage.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_context`
--

LOCK TABLES `metrics_context` WRITE;
/*!40000 ALTER TABLE `metrics_context` DISABLE KEYS */;
INSERT INTO `metrics_context` VALUES
(1,'demo-seed',1,'2026-10-06',32),
(2,'demo-seed',1,'2026-10-05',36),
(3,'demo-seed',1,'2026-10-04',22),
(4,'demo-seed',1,'2026-10-03',37),
(5,'demo-seed',1,'2026-10-02',19),
(6,'demo-seed',1,'2026-10-01',39),
(7,'demo-seed',1,'2026-09-30',34),
(8,'demo-seed',1,'2026-09-29',25),
(9,'demo-seed',1,'2026-09-28',27),
(10,'demo-seed',1,'2026-09-27',30),
(11,'demo-seed',1,'2026-09-26',30),
(12,'demo-seed',1,'2026-09-25',30),
(13,'demo-seed',1,'2026-09-24',32),
(14,'demo-seed',1,'2026-09-23',19),
(15,'demo-seed',1,'2026-09-22',27),
(16,'demo-seed',1,'2026-09-21',29),
(17,'demo-seed',1,'2026-09-20',31),
(18,'demo-seed',1,'2026-09-19',38),
(19,'demo-seed',1,'2026-09-18',28),
(20,'demo-seed',1,'2026-09-17',27),
(21,'demo-seed',1,'2026-09-16',27),
(22,'demo-seed',1,'2026-09-15',23),
(23,'demo-seed',1,'2026-09-14',29),
(24,'demo-seed',1,'2026-09-13',32),
(25,'demo-seed',1,'2026-09-12',18),
(26,'demo-seed',1,'2026-09-11',22),
(27,'demo-seed',1,'2026-09-10',38),
(28,'demo-seed',1,'2026-09-09',35),
(29,'demo-seed',1,'2026-09-08',37),
(30,'demo-seed',1,'2026-09-07',30),
(31,'demo-seed',1,'2026-08-15',710),
(32,'demo-seed',1,'2026-07-15',571),
(33,'demo-seed',1,'2026-06-15',713),
(34,'demo-seed',1,'2026-05-15',907),
(35,'demo-seed',1,'2026-04-15',438),
(36,'demo-seed',1,'2026-03-15',719),
(37,'demo-seed',1,'2026-02-15',422),
(38,'demo-seed',1,'2026-01-15',357),
(39,'demo-seed',1,'2025-12-15',578),
(40,'demo-seed',1,'2025-11-15',379),
(41,'demo-seed',1,'2025-10-15',524),
(42,'demo-seed',1,'2025-09-15',448);
/*!40000 ALTER TABLE `metrics_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_counter_submission_daily`
--

DROP TABLE IF EXISTS `metrics_counter_submission_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_counter_submission_daily` (
  `metrics_counter_submission_daily_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `date` date NOT NULL,
  `metric_investigations` int(11) NOT NULL,
  `metric_investigations_unique` int(11) NOT NULL,
  `metric_requests` int(11) NOT NULL,
  `metric_requests_unique` int(11) NOT NULL,
  PRIMARY KEY (`metrics_counter_submission_daily_id`),
  UNIQUE KEY `msd_uc_load_id_context_id_submission_id_date` (`load_id`,`context_id`,`submission_id`,`date`),
  KEY `msd_load_id` (`load_id`),
  KEY `metrics_counter_submission_daily_context_id` (`context_id`),
  KEY `metrics_counter_submission_daily_submission_id` (`submission_id`),
  KEY `msd_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msd_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msd_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Daily statistics matching the COUNTER R5 protocol for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_counter_submission_daily`
--

LOCK TABLES `metrics_counter_submission_daily` WRITE;
/*!40000 ALTER TABLE `metrics_counter_submission_daily` DISABLE KEYS */;
INSERT INTO `metrics_counter_submission_daily` VALUES
(1,'demo-seed',1,1,'2026-09-07',15,8,5,4),
(2,'demo-seed',1,1,'2026-09-08',9,5,3,2),
(3,'demo-seed',1,1,'2026-09-09',12,6,5,4),
(4,'demo-seed',1,1,'2026-09-10',12,7,4,3),
(5,'demo-seed',1,1,'2026-09-11',10,6,3,2),
(6,'demo-seed',1,1,'2026-09-12',10,4,5,4),
(7,'demo-seed',1,1,'2026-09-13',13,7,4,3),
(8,'demo-seed',1,1,'2026-09-14',12,7,4,3),
(9,'demo-seed',1,1,'2026-09-15',10,5,4,3),
(10,'demo-seed',1,1,'2026-09-16',10,4,5,4),
(11,'demo-seed',1,1,'2026-09-17',12,8,2,2),
(12,'demo-seed',1,1,'2026-09-18',12,7,3,2),
(13,'demo-seed',1,1,'2026-09-19',11,6,4,3),
(14,'demo-seed',1,1,'2026-09-20',10,4,5,4),
(15,'demo-seed',1,1,'2026-09-21',14,8,4,3),
(16,'demo-seed',1,1,'2026-09-22',9,4,4,3),
(17,'demo-seed',1,1,'2026-09-23',15,8,5,4),
(18,'demo-seed',1,1,'2026-09-24',12,7,4,3),
(19,'demo-seed',1,1,'2026-09-25',15,8,5,4),
(20,'demo-seed',1,1,'2026-09-26',14,8,4,3),
(21,'demo-seed',1,1,'2026-09-27',8,5,2,2),
(22,'demo-seed',1,1,'2026-09-28',11,7,3,2),
(23,'demo-seed',1,1,'2026-09-29',9,6,2,2),
(24,'demo-seed',1,1,'2026-09-30',13,7,4,3),
(25,'demo-seed',1,1,'2026-10-01',15,8,5,4),
(26,'demo-seed',1,1,'2026-10-02',13,7,5,4),
(27,'demo-seed',1,1,'2026-10-03',12,8,2,2),
(28,'demo-seed',1,1,'2026-10-04',9,5,3,2),
(29,'demo-seed',1,1,'2026-10-05',8,5,2,2),
(30,'demo-seed',1,1,'2026-10-06',12,7,3,2),
(31,'demo-seed',1,2,'2026-09-07',9,5,3,2),
(32,'demo-seed',1,2,'2026-09-08',11,7,3,2),
(33,'demo-seed',1,2,'2026-09-09',13,7,4,3),
(34,'demo-seed',1,2,'2026-09-10',10,6,3,2),
(35,'demo-seed',1,2,'2026-09-11',7,4,2,2),
(36,'demo-seed',1,2,'2026-09-12',10,6,3,2),
(37,'demo-seed',1,2,'2026-09-13',10,7,2,2),
(38,'demo-seed',1,2,'2026-09-14',8,4,3,2),
(39,'demo-seed',1,2,'2026-09-15',12,7,4,3),
(40,'demo-seed',1,2,'2026-09-16',8,5,2,2),
(41,'demo-seed',1,2,'2026-09-17',11,7,3,2),
(42,'demo-seed',1,2,'2026-09-18',12,7,3,2),
(43,'demo-seed',1,2,'2026-09-19',10,7,2,2),
(44,'demo-seed',1,2,'2026-09-20',8,3,4,3),
(45,'demo-seed',1,2,'2026-09-21',8,3,4,3),
(46,'demo-seed',1,2,'2026-09-22',8,3,4,3),
(47,'demo-seed',1,2,'2026-09-23',9,6,2,2),
(48,'demo-seed',1,2,'2026-09-24',11,7,2,2),
(49,'demo-seed',1,2,'2026-09-25',12,7,3,2),
(50,'demo-seed',1,2,'2026-09-26',14,7,5,4),
(51,'demo-seed',1,2,'2026-09-27',10,6,3,2),
(52,'demo-seed',1,2,'2026-09-28',9,4,4,3),
(53,'demo-seed',1,2,'2026-09-29',10,4,5,4),
(54,'demo-seed',1,2,'2026-09-30',11,7,2,2),
(55,'demo-seed',1,2,'2026-10-01',11,7,3,2),
(56,'demo-seed',1,2,'2026-10-02',13,7,4,3),
(57,'demo-seed',1,2,'2026-10-03',8,4,3,2),
(58,'demo-seed',1,2,'2026-10-04',9,6,2,2),
(59,'demo-seed',1,2,'2026-10-05',7,4,2,2),
(60,'demo-seed',1,2,'2026-10-06',8,5,2,2),
(61,'demo-seed',1,3,'2026-09-07',10,6,3,2),
(62,'demo-seed',1,3,'2026-09-08',17,11,3,2),
(63,'demo-seed',1,3,'2026-09-09',21,12,6,5),
(64,'demo-seed',1,3,'2026-09-10',18,9,7,6),
(65,'demo-seed',1,3,'2026-09-11',21,12,6,5),
(66,'demo-seed',1,3,'2026-09-12',14,7,6,5),
(67,'demo-seed',1,3,'2026-09-13',15,9,4,3),
(68,'demo-seed',1,3,'2026-09-14',18,11,5,4),
(69,'demo-seed',1,3,'2026-09-15',15,10,3,2),
(70,'demo-seed',1,3,'2026-09-16',21,11,7,6),
(71,'demo-seed',1,3,'2026-09-17',18,11,5,4),
(72,'demo-seed',1,3,'2026-09-18',15,9,4,3),
(73,'demo-seed',1,3,'2026-09-19',21,12,6,5),
(74,'demo-seed',1,3,'2026-09-20',12,7,3,2),
(75,'demo-seed',1,3,'2026-09-21',17,9,6,5),
(76,'demo-seed',1,3,'2026-09-22',19,10,7,6),
(77,'demo-seed',1,3,'2026-09-23',20,11,7,6),
(78,'demo-seed',1,3,'2026-09-24',19,11,6,5),
(79,'demo-seed',1,3,'2026-09-25',16,11,3,2),
(80,'demo-seed',1,3,'2026-09-26',20,12,5,4),
(81,'demo-seed',1,3,'2026-09-27',22,12,7,6),
(82,'demo-seed',1,3,'2026-09-28',19,11,5,4),
(83,'demo-seed',1,3,'2026-09-29',22,12,7,6),
(84,'demo-seed',1,3,'2026-09-30',15,9,4,3),
(85,'demo-seed',1,3,'2026-10-01',19,11,5,4),
(86,'demo-seed',1,3,'2026-10-02',18,12,3,2),
(87,'demo-seed',1,3,'2026-10-03',19,11,6,5),
(88,'demo-seed',1,3,'2026-10-04',12,7,3,2),
(89,'demo-seed',1,3,'2026-10-05',13,8,3,2),
(90,'demo-seed',1,3,'2026-10-06',16,8,6,5),
(91,'demo-seed',1,4,'2026-09-07',6,3,2,2),
(92,'demo-seed',1,4,'2026-09-08',6,3,2,2),
(93,'demo-seed',1,4,'2026-09-09',8,4,3,2),
(94,'demo-seed',1,4,'2026-09-10',8,4,3,2),
(95,'demo-seed',1,4,'2026-09-11',5,3,1,1),
(96,'demo-seed',1,4,'2026-09-12',5,2,2,2),
(97,'demo-seed',1,4,'2026-09-13',9,5,3,2),
(98,'demo-seed',1,4,'2026-09-14',6,3,2,2),
(99,'demo-seed',1,4,'2026-09-15',9,5,3,2),
(100,'demo-seed',1,4,'2026-09-16',7,3,3,2),
(101,'demo-seed',1,4,'2026-09-17',8,5,2,2),
(102,'demo-seed',1,4,'2026-09-18',5,3,1,1),
(103,'demo-seed',1,4,'2026-09-19',7,4,2,2),
(104,'demo-seed',1,4,'2026-09-20',5,2,2,2),
(105,'demo-seed',1,4,'2026-09-21',8,5,2,2),
(106,'demo-seed',1,4,'2026-09-22',6,4,1,1),
(107,'demo-seed',1,4,'2026-09-23',8,4,3,2),
(108,'demo-seed',1,4,'2026-09-24',7,3,3,2),
(109,'demo-seed',1,4,'2026-09-25',6,4,1,1),
(110,'demo-seed',1,4,'2026-09-26',5,3,1,1),
(111,'demo-seed',1,4,'2026-09-27',7,5,1,1),
(112,'demo-seed',1,4,'2026-09-28',8,4,3,2),
(113,'demo-seed',1,4,'2026-09-29',7,3,3,2),
(114,'demo-seed',1,4,'2026-09-30',9,5,3,2),
(115,'demo-seed',1,4,'2026-10-01',5,3,1,1),
(116,'demo-seed',1,4,'2026-10-02',4,2,1,1),
(117,'demo-seed',1,4,'2026-10-03',7,3,3,2),
(118,'demo-seed',1,4,'2026-10-04',6,4,1,1),
(119,'demo-seed',1,4,'2026-10-05',5,2,2,2),
(120,'demo-seed',1,4,'2026-10-06',6,2,3,2),
(121,'demo-seed',1,5,'2026-09-07',22,13,6,5),
(122,'demo-seed',1,5,'2026-09-08',16,7,8,6),
(123,'demo-seed',1,5,'2026-09-09',16,7,8,6),
(124,'demo-seed',1,5,'2026-09-10',19,9,8,6),
(125,'demo-seed',1,5,'2026-09-11',18,10,6,5),
(126,'demo-seed',1,5,'2026-09-12',20,13,4,3),
(127,'demo-seed',1,5,'2026-09-13',14,8,4,3),
(128,'demo-seed',1,5,'2026-09-14',20,11,7,6),
(129,'demo-seed',1,5,'2026-09-15',21,11,7,6),
(130,'demo-seed',1,5,'2026-09-16',16,8,6,5),
(131,'demo-seed',1,5,'2026-09-17',20,13,4,3),
(132,'demo-seed',1,5,'2026-09-18',20,12,5,4),
(133,'demo-seed',1,5,'2026-09-19',15,8,5,4),
(134,'demo-seed',1,5,'2026-09-20',17,8,7,6),
(135,'demo-seed',1,5,'2026-09-21',20,13,4,3),
(136,'demo-seed',1,5,'2026-09-22',24,14,7,6),
(137,'demo-seed',1,5,'2026-09-23',24,14,7,6),
(138,'demo-seed',1,5,'2026-09-24',15,9,4,3),
(139,'demo-seed',1,5,'2026-09-25',17,7,8,6),
(140,'demo-seed',1,5,'2026-09-26',12,7,3,2),
(141,'demo-seed',1,5,'2026-09-27',19,9,8,6),
(142,'demo-seed',1,5,'2026-09-28',19,9,8,6),
(143,'demo-seed',1,5,'2026-09-29',17,11,4,3),
(144,'demo-seed',1,5,'2026-09-30',16,9,5,4),
(145,'demo-seed',1,5,'2026-10-01',16,10,4,3),
(146,'demo-seed',1,5,'2026-10-02',16,11,3,2),
(147,'demo-seed',1,5,'2026-10-03',19,11,5,4),
(148,'demo-seed',1,5,'2026-10-04',16,7,8,6),
(149,'demo-seed',1,5,'2026-10-05',16,10,4,3),
(150,'demo-seed',1,5,'2026-10-06',18,8,8,6),
(151,'demo-seed',1,6,'2026-09-07',12,8,2,2),
(152,'demo-seed',1,6,'2026-09-08',11,6,4,3),
(153,'demo-seed',1,6,'2026-09-09',12,6,5,4),
(154,'demo-seed',1,6,'2026-09-10',9,6,2,2),
(155,'demo-seed',1,6,'2026-09-11',9,5,3,2),
(156,'demo-seed',1,6,'2026-09-12',13,8,3,2),
(157,'demo-seed',1,6,'2026-09-13',13,8,3,2),
(158,'demo-seed',1,6,'2026-09-14',12,7,3,2),
(159,'demo-seed',1,6,'2026-09-15',11,7,2,2),
(160,'demo-seed',1,6,'2026-09-16',9,4,4,3),
(161,'demo-seed',1,6,'2026-09-17',12,7,4,3),
(162,'demo-seed',1,6,'2026-09-18',15,9,4,3),
(163,'demo-seed',1,6,'2026-09-19',11,6,4,3),
(164,'demo-seed',1,6,'2026-09-20',13,7,5,4),
(165,'demo-seed',1,6,'2026-09-21',7,4,2,2),
(166,'demo-seed',1,6,'2026-09-22',9,5,3,2),
(167,'demo-seed',1,6,'2026-09-23',9,4,4,3),
(168,'demo-seed',1,6,'2026-09-24',16,9,5,4),
(169,'demo-seed',1,6,'2026-09-25',11,7,3,2),
(170,'demo-seed',1,6,'2026-09-26',16,9,5,4),
(171,'demo-seed',1,6,'2026-09-27',15,8,5,4),
(172,'demo-seed',1,6,'2026-09-28',9,5,3,2),
(173,'demo-seed',1,6,'2026-09-29',12,7,4,3),
(174,'demo-seed',1,6,'2026-09-30',15,8,5,4),
(175,'demo-seed',1,6,'2026-10-01',9,5,3,2),
(176,'demo-seed',1,6,'2026-10-02',14,8,4,3),
(177,'demo-seed',1,6,'2026-10-03',7,4,2,2),
(178,'demo-seed',1,6,'2026-10-04',9,5,3,2),
(179,'demo-seed',1,6,'2026-10-05',16,9,5,4),
(180,'demo-seed',1,6,'2026-10-06',15,8,5,4),
(181,'demo-seed',1,7,'2026-09-07',14,7,5,4),
(182,'demo-seed',1,7,'2026-09-08',17,9,6,5),
(183,'demo-seed',1,7,'2026-09-09',13,6,6,5),
(184,'demo-seed',1,7,'2026-09-10',14,7,6,5),
(185,'demo-seed',1,7,'2026-09-11',10,6,3,2),
(186,'demo-seed',1,7,'2026-09-12',16,10,4,3),
(187,'demo-seed',1,7,'2026-09-13',12,6,5,4),
(188,'demo-seed',1,7,'2026-09-14',12,5,6,5),
(189,'demo-seed',1,7,'2026-09-15',11,7,3,2),
(190,'demo-seed',1,7,'2026-09-16',13,7,5,4),
(191,'demo-seed',1,7,'2026-09-17',14,7,6,5),
(192,'demo-seed',1,7,'2026-09-18',16,10,4,3),
(193,'demo-seed',1,7,'2026-09-19',10,5,4,3),
(194,'demo-seed',1,7,'2026-09-20',12,5,6,5),
(195,'demo-seed',1,7,'2026-09-21',16,9,5,4),
(196,'demo-seed',1,7,'2026-09-22',12,5,6,5),
(197,'demo-seed',1,7,'2026-09-23',12,7,3,2),
(198,'demo-seed',1,7,'2026-09-24',14,7,5,4),
(199,'demo-seed',1,7,'2026-09-25',15,10,3,2),
(200,'demo-seed',1,7,'2026-09-26',18,10,6,5),
(201,'demo-seed',1,7,'2026-09-27',12,5,6,5),
(202,'demo-seed',1,7,'2026-09-28',14,8,4,3),
(203,'demo-seed',1,7,'2026-09-29',9,5,3,2),
(204,'demo-seed',1,7,'2026-09-30',16,10,4,3),
(205,'demo-seed',1,7,'2026-10-01',15,7,6,5),
(206,'demo-seed',1,7,'2026-10-02',12,7,3,2),
(207,'demo-seed',1,7,'2026-10-03',13,8,3,2),
(208,'demo-seed',1,7,'2026-10-04',14,8,4,3),
(209,'demo-seed',1,7,'2026-10-05',15,7,6,5),
(210,'demo-seed',1,7,'2026-10-06',9,6,2,2),
(211,'demo-seed',1,8,'2026-09-07',9,6,2,2),
(212,'demo-seed',1,8,'2026-09-08',10,6,3,2),
(213,'demo-seed',1,8,'2026-09-09',9,6,2,2),
(214,'demo-seed',1,8,'2026-09-10',12,7,4,3),
(215,'demo-seed',1,8,'2026-09-11',7,4,2,2),
(216,'demo-seed',1,8,'2026-09-12',9,5,3,2),
(217,'demo-seed',1,8,'2026-09-13',8,5,2,2),
(218,'demo-seed',1,8,'2026-09-14',6,3,2,2),
(219,'demo-seed',1,8,'2026-09-15',9,6,2,2),
(220,'demo-seed',1,8,'2026-09-16',9,5,3,2),
(221,'demo-seed',1,8,'2026-09-17',7,3,3,2),
(222,'demo-seed',1,8,'2026-09-18',8,4,3,2),
(223,'demo-seed',1,8,'2026-09-19',6,4,1,1),
(224,'demo-seed',1,8,'2026-09-20',7,5,1,1),
(225,'demo-seed',1,8,'2026-09-21',9,5,3,2),
(226,'demo-seed',1,8,'2026-09-22',10,6,3,2),
(227,'demo-seed',1,8,'2026-09-23',9,5,3,2),
(228,'demo-seed',1,8,'2026-09-24',9,6,2,2),
(229,'demo-seed',1,8,'2026-09-25',7,5,1,1),
(230,'demo-seed',1,8,'2026-09-26',6,3,2,2),
(231,'demo-seed',1,8,'2026-09-27',10,7,2,2),
(232,'demo-seed',1,8,'2026-09-28',7,4,2,2),
(233,'demo-seed',1,8,'2026-09-29',10,5,4,3),
(234,'demo-seed',1,8,'2026-09-30',9,6,2,2),
(235,'demo-seed',1,8,'2026-10-01',7,4,2,2),
(236,'demo-seed',1,8,'2026-10-02',7,4,2,2),
(237,'demo-seed',1,8,'2026-10-03',7,4,2,2),
(238,'demo-seed',1,8,'2026-10-04',8,4,3,2),
(239,'demo-seed',1,8,'2026-10-05',7,3,3,2),
(240,'demo-seed',1,8,'2026-10-06',7,4,2,2);
/*!40000 ALTER TABLE `metrics_counter_submission_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_counter_submission_institution_daily`
--

DROP TABLE IF EXISTS `metrics_counter_submission_institution_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_counter_submission_institution_daily` (
  `metrics_counter_submission_institution_daily_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `institution_id` bigint(20) NOT NULL,
  `date` date NOT NULL,
  `metric_investigations` int(11) NOT NULL,
  `metric_investigations_unique` int(11) NOT NULL,
  `metric_requests` int(11) NOT NULL,
  `metric_requests_unique` int(11) NOT NULL,
  PRIMARY KEY (`metrics_counter_submission_institution_daily_id`),
  UNIQUE KEY `msid_uc_load_id_context_id_submission_id_institution_id_date` (`load_id`,`context_id`,`submission_id`,`institution_id`,`date`),
  KEY `msid_load_id` (`load_id`),
  KEY `metrics_counter_submission_institution_daily_context_id` (`context_id`),
  KEY `metrics_counter_submission_institution_daily_submission_id` (`submission_id`),
  KEY `metrics_counter_submission_institution_daily_institution_id` (`institution_id`),
  KEY `msid_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msid_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msid_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE,
  CONSTRAINT `msid_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Daily statistics matching the COUNTER R5 protocol for views and downloads from institutions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_counter_submission_institution_daily`
--

LOCK TABLES `metrics_counter_submission_institution_daily` WRITE;
/*!40000 ALTER TABLE `metrics_counter_submission_institution_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_counter_submission_institution_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_counter_submission_institution_monthly`
--

DROP TABLE IF EXISTS `metrics_counter_submission_institution_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_counter_submission_institution_monthly` (
  `metrics_counter_submission_institution_monthly_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `institution_id` bigint(20) NOT NULL,
  `month` int(11) NOT NULL,
  `metric_investigations` int(11) NOT NULL,
  `metric_investigations_unique` int(11) NOT NULL,
  `metric_requests` int(11) NOT NULL,
  `metric_requests_unique` int(11) NOT NULL,
  PRIMARY KEY (`metrics_counter_submission_institution_monthly_id`),
  UNIQUE KEY `msim_uc_context_id_submission_id_institution_id_month` (`context_id`,`submission_id`,`institution_id`,`month`),
  KEY `metrics_counter_submission_institution_monthly_context_id` (`context_id`),
  KEY `metrics_counter_submission_institution_monthly_submission_id` (`submission_id`),
  KEY `metrics_counter_submission_institution_monthly_institution_id` (`institution_id`),
  KEY `msim_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msim_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msim_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE,
  CONSTRAINT `msim_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Monthly statistics matching the COUNTER R5 protocol for views and downloads from institutions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_counter_submission_institution_monthly`
--

LOCK TABLES `metrics_counter_submission_institution_monthly` WRITE;
/*!40000 ALTER TABLE `metrics_counter_submission_institution_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_counter_submission_institution_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_counter_submission_monthly`
--

DROP TABLE IF EXISTS `metrics_counter_submission_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_counter_submission_monthly` (
  `metrics_counter_submission_monthly_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `month` int(11) NOT NULL,
  `metric_investigations` int(11) NOT NULL,
  `metric_investigations_unique` int(11) NOT NULL,
  `metric_requests` int(11) NOT NULL,
  `metric_requests_unique` int(11) NOT NULL,
  PRIMARY KEY (`metrics_counter_submission_monthly_id`),
  UNIQUE KEY `msm_uc_context_id_submission_id_month` (`context_id`,`submission_id`,`month`),
  KEY `metrics_counter_submission_monthly_context_id` (`context_id`),
  KEY `metrics_counter_submission_monthly_submission_id` (`submission_id`),
  KEY `msm_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msm_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msm_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Monthly statistics matching the COUNTER R5 protocol for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_counter_submission_monthly`
--

LOCK TABLES `metrics_counter_submission_monthly` WRITE;
/*!40000 ALTER TABLE `metrics_counter_submission_monthly` DISABLE KEYS */;
INSERT INTO `metrics_counter_submission_monthly` VALUES
(1,1,1,202509,183,103,57,46),
(2,1,1,202510,111,65,32,26),
(3,1,1,202511,157,96,40,32),
(4,1,1,202512,163,111,28,22),
(5,1,1,202601,201,98,82,66),
(6,1,1,202602,265,148,84,67),
(7,1,1,202603,180,84,78,62),
(8,1,1,202604,202,83,101,81),
(9,1,1,202605,278,191,45,36),
(10,1,1,202606,243,118,99,79),
(11,1,1,202607,239,137,72,58),
(12,1,1,202608,408,221,138,110),
(13,1,1,202609,278,152,93,74),
(14,1,1,202610,69,40,20,16),
(15,1,2,202509,83,46,27,22),
(16,1,2,202510,182,98,62,50),
(17,1,2,202511,165,115,25,20),
(18,1,2,202512,173,97,55,44),
(19,1,2,202601,210,125,58,46),
(20,1,2,202602,137,71,50,40),
(21,1,2,202603,255,153,69,55),
(22,1,2,202604,234,115,94,75),
(23,1,2,202605,224,124,73,58),
(24,1,2,202606,273,165,72,58),
(25,1,2,202607,245,167,41,33),
(26,1,2,202608,310,181,89,71),
(27,1,2,202609,241,136,75,60),
(28,1,2,202610,56,33,16,13),
(29,1,3,202509,257,138,89,71),
(30,1,3,202510,304,176,89,71),
(31,1,3,202511,212,121,64,51),
(32,1,3,202512,190,118,46,37),
(33,1,3,202601,257,116,116,93),
(34,1,3,202602,349,179,131,105),
(35,1,3,202603,410,207,158,126),
(36,1,3,202604,376,230,96,77),
(37,1,3,202605,447,253,138,110),
(38,1,3,202606,371,170,164,131),
(39,1,3,202607,446,272,114,91),
(40,1,3,202608,363,192,129,103),
(41,1,3,202609,425,246,125,100),
(42,1,3,202610,97,58,26,21),
(43,1,4,202509,68,34,27,22),
(44,1,4,202510,127,71,40,32),
(45,1,4,202511,82,43,29,23),
(46,1,4,202512,130,69,46,37),
(47,1,4,202601,146,78,51,41),
(48,1,4,202602,116,54,50,40),
(49,1,4,202603,145,84,43,34),
(50,1,4,202604,158,103,32,26),
(51,1,4,202605,191,108,59,47),
(52,1,4,202606,223,121,76,61),
(53,1,4,202607,224,134,60,48),
(54,1,4,202608,138,68,55,44),
(55,1,4,202609,165,93,52,42),
(56,1,4,202610,33,18,11,9),
(57,1,5,202509,209,121,62,50),
(58,1,5,202510,278,189,47,38),
(59,1,5,202511,247,130,89,71),
(60,1,5,202512,257,141,85,68),
(61,1,5,202601,217,128,61,49),
(62,1,5,202602,256,156,66,53),
(63,1,5,202603,437,259,121,97),
(64,1,5,202604,341,144,166,133),
(65,1,5,202605,380,250,75,60),
(66,1,5,202606,430,195,192,154),
(67,1,5,202607,453,218,187,150),
(68,1,5,202608,529,340,114,91),
(69,1,5,202609,437,241,143,114),
(70,1,5,202610,101,57,32,26),
(71,1,6,202509,191,105,63,50),
(72,1,6,202510,144,97,26,21),
(73,1,6,202511,151,68,68,54),
(74,1,6,202512,180,94,65,52),
(75,1,6,202601,159,89,51,41),
(76,1,6,202602,181,107,50,40),
(77,1,6,202603,198,100,76,61),
(78,1,6,202604,244,162,46,37),
(79,1,6,202605,306,161,110,88),
(80,1,6,202606,268,150,85,68),
(81,1,6,202607,302,198,61,49),
(82,1,6,202608,277,175,64,51),
(83,1,6,202609,281,159,87,70),
(84,1,6,202610,70,39,22,18),
(85,1,7,202509,160,109,27,22),
(86,1,7,202510,121,75,29,23),
(87,1,7,202511,262,152,77,62),
(88,1,7,202512,192,84,89,71),
(89,1,7,202601,177,93,63,50),
(90,1,7,202602,218,118,74,59),
(91,1,7,202603,239,144,64,51),
(92,1,7,202604,286,125,134,107),
(93,1,7,202605,303,173,92,74),
(94,1,7,202606,301,166,98,78),
(95,1,7,202607,369,203,122,98),
(96,1,7,202608,263,143,89,71),
(97,1,7,202609,322,171,114,91),
(98,1,7,202610,78,44,24,19),
(99,1,8,202509,113,54,47,38),
(100,1,8,202510,81,50,20,16),
(101,1,8,202511,132,74,42,34),
(102,1,8,202512,175,97,57,46),
(103,1,8,202601,121,67,39,31),
(104,1,8,202602,123,70,38,30),
(105,1,8,202603,150,67,68,54),
(106,1,8,202604,156,92,44,35),
(107,1,8,202605,191,120,45,36),
(108,1,8,202606,184,105,56,45),
(109,1,8,202607,153,80,56,45),
(110,1,8,202608,218,142,45,36),
(111,1,8,202609,202,119,57,46),
(112,1,8,202610,43,24,14,11);
/*!40000 ALTER TABLE `metrics_counter_submission_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_issue`
--

DROP TABLE IF EXISTS `metrics_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_issue` (
  `metrics_issue_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `issue_id` bigint(20) NOT NULL,
  `issue_galley_id` bigint(20) DEFAULT NULL,
  `date` date NOT NULL,
  `metric` int(11) NOT NULL,
  PRIMARY KEY (`metrics_issue_id`),
  KEY `metrics_issue_load_id` (`load_id`),
  KEY `metrics_issue_context_id` (`context_id`),
  KEY `metrics_issue_issue_id` (`issue_id`),
  KEY `metrics_issue_issue_galley_id` (`issue_galley_id`),
  KEY `metrics_issue_context_id_issue_id` (`context_id`,`issue_id`),
  CONSTRAINT `metrics_issue_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_issue_issue_galley_id_foreign` FOREIGN KEY (`issue_galley_id`) REFERENCES `issue_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_issue_issue_id_foreign` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Daily statistics for views and downloads of published issues.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_issue`
--

LOCK TABLES `metrics_issue` WRITE;
/*!40000 ALTER TABLE `metrics_issue` DISABLE KEYS */;
INSERT INTO `metrics_issue` VALUES
(1,'demo-seed',1,1,NULL,'2026-10-06',6),
(2,'demo-seed',1,2,NULL,'2026-10-06',5),
(3,'demo-seed',1,1,NULL,'2026-10-05',4),
(4,'demo-seed',1,2,NULL,'2026-10-05',3),
(5,'demo-seed',1,1,NULL,'2026-10-04',10),
(6,'demo-seed',1,2,NULL,'2026-10-04',9),
(7,'demo-seed',1,1,NULL,'2026-10-03',7),
(8,'demo-seed',1,2,NULL,'2026-10-03',8),
(9,'demo-seed',1,1,NULL,'2026-10-02',5),
(10,'demo-seed',1,2,NULL,'2026-10-02',6),
(11,'demo-seed',1,1,NULL,'2026-10-01',3),
(12,'demo-seed',1,2,NULL,'2026-10-01',4),
(13,'demo-seed',1,1,NULL,'2026-09-30',10),
(14,'demo-seed',1,2,NULL,'2026-09-30',9),
(15,'demo-seed',1,1,NULL,'2026-09-29',5),
(16,'demo-seed',1,2,NULL,'2026-09-29',6),
(17,'demo-seed',1,1,NULL,'2026-09-28',7),
(18,'demo-seed',1,2,NULL,'2026-09-28',8),
(19,'demo-seed',1,1,NULL,'2026-09-27',8),
(20,'demo-seed',1,2,NULL,'2026-09-27',7),
(21,'demo-seed',1,1,NULL,'2026-09-26',6),
(22,'demo-seed',1,2,NULL,'2026-09-26',5),
(23,'demo-seed',1,1,NULL,'2026-09-25',4),
(24,'demo-seed',1,2,NULL,'2026-09-25',3),
(25,'demo-seed',1,1,NULL,'2026-09-24',10),
(26,'demo-seed',1,2,NULL,'2026-09-24',9),
(27,'demo-seed',1,1,NULL,'2026-09-23',7),
(28,'demo-seed',1,2,NULL,'2026-09-23',8),
(29,'demo-seed',1,1,NULL,'2026-09-22',5),
(30,'demo-seed',1,2,NULL,'2026-09-22',6),
(31,'demo-seed',1,1,NULL,'2026-09-21',3),
(32,'demo-seed',1,2,NULL,'2026-09-21',4),
(33,'demo-seed',1,1,NULL,'2026-09-20',9),
(34,'demo-seed',1,2,NULL,'2026-09-20',10),
(35,'demo-seed',1,1,NULL,'2026-09-19',4),
(36,'demo-seed',1,2,NULL,'2026-09-19',3),
(37,'demo-seed',1,1,NULL,'2026-09-18',10),
(38,'demo-seed',1,2,NULL,'2026-09-18',9),
(39,'demo-seed',1,1,NULL,'2026-09-17',9),
(40,'demo-seed',1,2,NULL,'2026-09-17',10),
(41,'demo-seed',1,1,NULL,'2026-09-16',3),
(42,'demo-seed',1,2,NULL,'2026-09-16',4),
(43,'demo-seed',1,1,NULL,'2026-09-15',5),
(44,'demo-seed',1,2,NULL,'2026-09-15',6),
(45,'demo-seed',1,1,NULL,'2026-09-14',7),
(46,'demo-seed',1,2,NULL,'2026-09-14',8),
(47,'demo-seed',1,1,NULL,'2026-09-13',10),
(48,'demo-seed',1,2,NULL,'2026-09-13',9),
(49,'demo-seed',1,1,NULL,'2026-09-12',4),
(50,'demo-seed',1,2,NULL,'2026-09-12',3),
(51,'demo-seed',1,1,NULL,'2026-09-11',6),
(52,'demo-seed',1,2,NULL,'2026-09-11',5),
(53,'demo-seed',1,1,NULL,'2026-09-10',8),
(54,'demo-seed',1,2,NULL,'2026-09-10',7),
(55,'demo-seed',1,1,NULL,'2026-09-09',3),
(56,'demo-seed',1,2,NULL,'2026-09-09',4),
(57,'demo-seed',1,1,NULL,'2026-09-08',9),
(58,'demo-seed',1,2,NULL,'2026-09-08',10),
(59,'demo-seed',1,1,NULL,'2026-09-07',10),
(60,'demo-seed',1,2,NULL,'2026-09-07',9),
(61,'demo-seed',1,1,NULL,'2026-08-15',273),
(62,'demo-seed',1,2,NULL,'2026-08-15',246),
(63,'demo-seed',1,1,NULL,'2026-07-15',104),
(64,'demo-seed',1,2,NULL,'2026-07-15',78),
(65,'demo-seed',1,1,NULL,'2026-06-15',172),
(66,'demo-seed',1,2,NULL,'2026-06-15',197),
(67,'demo-seed',1,1,NULL,'2026-05-15',116),
(68,'demo-seed',1,2,NULL,'2026-05-15',140),
(69,'demo-seed',1,1,NULL,'2026-04-15',219),
(70,'demo-seed',1,2,NULL,'2026-04-15',197),
(71,'demo-seed',1,1,NULL,'2026-03-15',185),
(72,'demo-seed',1,2,NULL,'2026-03-15',206),
(73,'demo-seed',1,1,NULL,'2026-02-15',115),
(74,'demo-seed',1,2,NULL,'2026-02-15',96),
(75,'demo-seed',1,1,NULL,'2026-01-15',143),
(76,'demo-seed',1,2,NULL,'2026-01-15',125),
(77,'demo-seed',1,1,NULL,'2025-12-15',149),
(78,'demo-seed',1,2,NULL,'2025-12-15',165),
(79,'demo-seed',1,1,NULL,'2025-11-15',45),
(80,'demo-seed',1,2,NULL,'2025-11-15',61),
(81,'demo-seed',1,1,NULL,'2025-10-15',110),
(82,'demo-seed',1,2,NULL,'2025-10-15',97),
(83,'demo-seed',1,1,NULL,'2025-09-15',125),
(84,'demo-seed',1,2,NULL,'2025-09-15',112);
/*!40000 ALTER TABLE `metrics_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_submission`
--

DROP TABLE IF EXISTS `metrics_submission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_submission` (
  `metrics_submission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `representation_id` bigint(20) DEFAULT NULL,
  `submission_file_id` bigint(20) unsigned DEFAULT NULL,
  `file_type` bigint(20) DEFAULT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `date` date NOT NULL,
  `metric` int(11) NOT NULL,
  PRIMARY KEY (`metrics_submission_id`),
  KEY `ms_load_id` (`load_id`),
  KEY `metrics_submission_context_id` (`context_id`),
  KEY `metrics_submission_submission_id` (`submission_id`),
  KEY `metrics_submission_representation_id` (`representation_id`),
  KEY `metrics_submission_submission_file_id` (`submission_file_id`),
  KEY `ms_context_id_submission_id_assoc_type_file_type` (`context_id`,`submission_id`,`assoc_type`,`file_type`),
  CONSTRAINT `metrics_submission_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_submission_representation_id_foreign` FOREIGN KEY (`representation_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_submission_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_submission_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1023 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Daily statistics for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_submission`
--

LOCK TABLES `metrics_submission` WRITE;
/*!40000 ALTER TABLE `metrics_submission` DISABLE KEYS */;
INSERT INTO `metrics_submission` VALUES
(1,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-10-06',9),
(2,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-10-06',6),
(3,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-10-06',10),
(4,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-10-06',3),
(5,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-10-06',10),
(6,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-10-06',10),
(7,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-10-06',7),
(8,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-10-06',5),
(9,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-10-05',6),
(10,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-10-05',5),
(11,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-10-05',10),
(12,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-10-05',3),
(13,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-10-05',12),
(14,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-10-05',11),
(15,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-10-05',9),
(16,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-10-05',4),
(17,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-10-04',6),
(18,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-10-04',7),
(19,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-10-04',9),
(20,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-10-04',5),
(21,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-10-04',8),
(22,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-10-04',6),
(23,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-10-04',10),
(24,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-10-04',5),
(25,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-10-03',10),
(26,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-10-03',5),
(27,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-10-03',13),
(28,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-10-03',4),
(29,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-10-03',14),
(30,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-10-03',5),
(31,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-10-03',10),
(32,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-10-03',5),
(33,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-10-02',8),
(34,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-10-02',9),
(35,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-10-02',15),
(36,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-10-02',3),
(37,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-10-02',13),
(38,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-10-02',10),
(39,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-10-02',9),
(40,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-10-02',5),
(41,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-10-01',10),
(42,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-10-01',8),
(43,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-10-01',14),
(44,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-10-01',4),
(45,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-10-01',12),
(46,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-10-01',6),
(47,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-10-01',9),
(48,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-10-01',5),
(49,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-30',9),
(50,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-30',9),
(51,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-30',11),
(52,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-30',6),
(53,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-30',11),
(54,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-30',10),
(55,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-30',12),
(56,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-30',7),
(57,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-29',7),
(58,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-29',5),
(59,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-29',15),
(60,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-29',4),
(61,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-29',13),
(62,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-29',8),
(63,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-29',6),
(64,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-29',6),
(65,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-28',8),
(66,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-28',5),
(67,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-28',14),
(68,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-28',5),
(69,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-28',11),
(70,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-28',6),
(71,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-28',10),
(72,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-28',5),
(73,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-27',6),
(74,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-27',7),
(75,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-27',15),
(76,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-27',6),
(77,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-27',11),
(78,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-27',10),
(79,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-27',6),
(80,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-27',8),
(81,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-26',10),
(82,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-26',9),
(83,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-26',15),
(84,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-26',4),
(85,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-26',9),
(86,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-26',11),
(87,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-26',12),
(88,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-26',4),
(89,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-25',10),
(90,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-25',9),
(91,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-25',13),
(92,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-25',5),
(93,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-25',9),
(94,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-25',8),
(95,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-25',12),
(96,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-25',6),
(97,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-24',8),
(98,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-24',9),
(99,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-24',13),
(100,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-24',4),
(101,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-24',11),
(102,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-24',11),
(103,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-24',9),
(104,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-24',7),
(105,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-23',10),
(106,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-23',7),
(107,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-23',13),
(108,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-23',5),
(109,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-23',17),
(110,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-23',5),
(111,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-23',9),
(112,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-23',6),
(113,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-22',5),
(114,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-22',4),
(115,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-22',12),
(116,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-22',5),
(117,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-22',17),
(118,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-22',6),
(119,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-22',6),
(120,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-22',7),
(121,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-21',10),
(122,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-21',4),
(123,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-21',11),
(124,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-21',6),
(125,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-21',16),
(126,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-21',5),
(127,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-21',11),
(128,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-21',6),
(129,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-20',5),
(130,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-20',4),
(131,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-20',9),
(132,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-20',3),
(133,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-20',10),
(134,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-20',8),
(135,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-20',6),
(136,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-20',6),
(137,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-19',7),
(138,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-19',8),
(139,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-19',15),
(140,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-19',5),
(141,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-19',10),
(142,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-19',7),
(143,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-19',6),
(144,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-19',5),
(145,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-18',9),
(146,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-18',9),
(147,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-18',11),
(148,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-18',4),
(149,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-18',15),
(150,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-18',11),
(151,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-18',12),
(152,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-18',5),
(153,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-17',10),
(154,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-17',8),
(155,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-17',13),
(156,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-17',6),
(157,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-17',16),
(158,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-17',8),
(159,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-17',8),
(160,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-17',4),
(161,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-16',5),
(162,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-16',6),
(163,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-16',14),
(164,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-16',4),
(165,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-16',10),
(166,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-16',5),
(167,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-16',8),
(168,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-16',6),
(169,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-15',6),
(170,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-15',8),
(171,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-15',12),
(172,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-15',6),
(173,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-15',14),
(174,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-15',9),
(175,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-15',8),
(176,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-15',7),
(177,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-14',8),
(178,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-14',5),
(179,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-14',13),
(180,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-14',4),
(181,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-14',13),
(182,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-14',9),
(183,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-14',6),
(184,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-14',4),
(185,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-13',9),
(186,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-13',8),
(187,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-13',11),
(188,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-13',6),
(189,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-13',10),
(190,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-13',10),
(191,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-13',7),
(192,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-13',6),
(193,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-12',5),
(194,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-12',7),
(195,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-12',8),
(196,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-12',3),
(197,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-12',16),
(198,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-12',10),
(199,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-12',12),
(200,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-12',6),
(201,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-11',7),
(202,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-11',5),
(203,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-11',15),
(204,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-11',4),
(205,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-11',12),
(206,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-11',6),
(207,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-11',7),
(208,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-11',5),
(209,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-10',8),
(210,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-10',7),
(211,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-10',11),
(212,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-10',5),
(213,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-10',11),
(214,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-10',7),
(215,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-10',8),
(216,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-10',8),
(217,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-09',7),
(218,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-09',9),
(219,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-09',15),
(220,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-09',5),
(221,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-09',8),
(222,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-09',7),
(223,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-09',7),
(224,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-09',7),
(225,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-08',6),
(226,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-08',8),
(227,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-08',14),
(228,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-08',4),
(229,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-08',8),
(230,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-08',7),
(231,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-08',11),
(232,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-08',7),
(233,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-09-07',10),
(234,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-09-07',6),
(235,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-09-07',7),
(236,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-09-07',4),
(237,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-09-07',16),
(238,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-09-07',10),
(239,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-09-07',9),
(240,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-09-07',7),
(241,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-08-15',270),
(242,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-08-15',221),
(243,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-08-15',234),
(244,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-08-15',83),
(245,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-08-15',415),
(246,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-08-15',213),
(247,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-08-15',174),
(248,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-08-15',173),
(249,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-07-15',167),
(250,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-07-15',204),
(251,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-07-15',332),
(252,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-07-15',164),
(253,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-07-15',266),
(254,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-07-15',241),
(255,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-07-15',247),
(256,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-07-15',97),
(257,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-06-15',144),
(258,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-06-15',201),
(259,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-06-15',207),
(260,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-06-15',147),
(261,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-06-15',238),
(262,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-06-15',183),
(263,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-06-15',203),
(264,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-06-15',128),
(265,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-05-15',233),
(266,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-05-15',151),
(267,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-05-15',309),
(268,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-05-15',132),
(269,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-05-15',305),
(270,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-05-15',196),
(271,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-05-15',211),
(272,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-05-15',146),
(273,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-04-15',101),
(274,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-04-15',140),
(275,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-04-15',280),
(276,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-04-15',126),
(277,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-04-15',175),
(278,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-04-15',198),
(279,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-04-15',152),
(280,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-04-15',112),
(281,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-03-15',102),
(282,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-03-15',186),
(283,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-03-15',252),
(284,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-03-15',102),
(285,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-03-15',316),
(286,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-03-15',122),
(287,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-03-15',175),
(288,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-03-15',82),
(289,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-02-15',181),
(290,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-02-15',87),
(291,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-02-15',218),
(292,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-02-15',66),
(293,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-02-15',190),
(294,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-02-15',131),
(295,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-02-15',144),
(296,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-02-15',85),
(297,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2026-01-15',119),
(298,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2026-01-15',152),
(299,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2026-01-15',141),
(300,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2026-01-15',95),
(301,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2026-01-15',156),
(302,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2026-01-15',108),
(303,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2026-01-15',114),
(304,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2026-01-15',82),
(305,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2025-12-15',135),
(306,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2025-12-15',118),
(307,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2025-12-15',144),
(308,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2025-12-15',84),
(309,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2025-12-15',172),
(310,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2025-12-15',115),
(311,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2025-12-15',103),
(312,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2025-12-15',118),
(313,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2025-11-15',117),
(314,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2025-11-15',140),
(315,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2025-11-15',148),
(316,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2025-11-15',53),
(317,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2025-11-15',158),
(318,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2025-11-15',83),
(319,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2025-11-15',185),
(320,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2025-11-15',90),
(321,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2025-10-15',79),
(322,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2025-10-15',120),
(323,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2025-10-15',215),
(324,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2025-10-15',87),
(325,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2025-10-15',231),
(326,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2025-10-15',118),
(327,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2025-10-15',92),
(328,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2025-10-15',61),
(329,'demo-seed',1,1,NULL,NULL,NULL,1048585,'2025-09-15',126),
(330,'demo-seed',1,2,NULL,NULL,NULL,1048585,'2025-09-15',56),
(331,'demo-seed',1,3,NULL,NULL,NULL,1048585,'2025-09-15',168),
(332,'demo-seed',1,4,NULL,NULL,NULL,1048585,'2025-09-15',41),
(333,'demo-seed',1,5,NULL,NULL,NULL,1048585,'2025-09-15',147),
(334,'demo-seed',1,6,NULL,NULL,NULL,1048585,'2025-09-15',128),
(335,'demo-seed',1,7,NULL,NULL,NULL,1048585,'2025-09-15',133),
(336,'demo-seed',1,8,NULL,NULL,NULL,1048585,'2025-09-15',66),
(512,'demo-seed',1,1,1,1,2,515,'2026-10-06',3),
(513,'demo-seed',1,2,2,2,2,515,'2026-10-06',2),
(514,'demo-seed',1,3,3,3,2,515,'2026-10-06',6),
(515,'demo-seed',1,4,4,4,2,515,'2026-10-06',3),
(516,'demo-seed',1,5,5,5,2,515,'2026-10-06',8),
(517,'demo-seed',1,6,7,7,2,515,'2026-10-06',5),
(518,'demo-seed',1,7,8,8,2,515,'2026-10-06',2),
(519,'demo-seed',1,8,9,9,2,515,'2026-10-06',2),
(520,'demo-seed',1,1,1,1,2,515,'2026-10-05',2),
(521,'demo-seed',1,2,2,2,2,515,'2026-10-05',2),
(522,'demo-seed',1,3,3,3,2,515,'2026-10-05',3),
(523,'demo-seed',1,4,4,4,2,515,'2026-10-05',2),
(524,'demo-seed',1,5,5,5,2,515,'2026-10-05',4),
(525,'demo-seed',1,6,7,7,2,515,'2026-10-05',5),
(526,'demo-seed',1,7,8,8,2,515,'2026-10-05',6),
(527,'demo-seed',1,8,9,9,2,515,'2026-10-05',3),
(528,'demo-seed',1,1,1,1,2,515,'2026-10-04',3),
(529,'demo-seed',1,2,2,2,2,515,'2026-10-04',2),
(530,'demo-seed',1,3,3,3,2,515,'2026-10-04',3),
(531,'demo-seed',1,4,4,4,2,515,'2026-10-04',1),
(532,'demo-seed',1,5,5,5,2,515,'2026-10-04',8),
(533,'demo-seed',1,6,7,7,2,515,'2026-10-04',3),
(534,'demo-seed',1,7,8,8,2,515,'2026-10-04',4),
(535,'demo-seed',1,8,9,9,2,515,'2026-10-04',3),
(536,'demo-seed',1,1,1,1,2,515,'2026-10-03',2),
(537,'demo-seed',1,2,2,2,2,515,'2026-10-03',3),
(538,'demo-seed',1,3,3,3,2,515,'2026-10-03',6),
(539,'demo-seed',1,4,4,4,2,515,'2026-10-03',3),
(540,'demo-seed',1,5,5,5,2,515,'2026-10-03',5),
(541,'demo-seed',1,6,7,7,2,515,'2026-10-03',2),
(542,'demo-seed',1,7,8,8,2,515,'2026-10-03',3),
(543,'demo-seed',1,8,9,9,2,515,'2026-10-03',2),
(544,'demo-seed',1,1,1,1,2,515,'2026-10-02',5),
(545,'demo-seed',1,2,2,2,2,515,'2026-10-02',4),
(546,'demo-seed',1,3,3,3,2,515,'2026-10-02',3),
(547,'demo-seed',1,4,4,4,2,515,'2026-10-02',1),
(548,'demo-seed',1,5,5,5,2,515,'2026-10-02',3),
(549,'demo-seed',1,6,7,7,2,515,'2026-10-02',4),
(550,'demo-seed',1,7,8,8,2,515,'2026-10-02',3),
(551,'demo-seed',1,8,9,9,2,515,'2026-10-02',2),
(552,'demo-seed',1,1,1,1,2,515,'2026-10-01',5),
(553,'demo-seed',1,2,2,2,2,515,'2026-10-01',3),
(554,'demo-seed',1,3,3,3,2,515,'2026-10-01',5),
(555,'demo-seed',1,4,4,4,2,515,'2026-10-01',1),
(556,'demo-seed',1,5,5,5,2,515,'2026-10-01',4),
(557,'demo-seed',1,6,7,7,2,515,'2026-10-01',3),
(558,'demo-seed',1,7,8,8,2,515,'2026-10-01',6),
(559,'demo-seed',1,8,9,9,2,515,'2026-10-01',2),
(560,'demo-seed',1,1,1,1,2,515,'2026-09-30',4),
(561,'demo-seed',1,2,2,2,2,515,'2026-09-30',2),
(562,'demo-seed',1,3,3,3,2,515,'2026-09-30',4),
(563,'demo-seed',1,4,4,4,2,515,'2026-09-30',3),
(564,'demo-seed',1,5,5,5,2,515,'2026-09-30',5),
(565,'demo-seed',1,6,7,7,2,515,'2026-09-30',5),
(566,'demo-seed',1,7,8,8,2,515,'2026-09-30',4),
(567,'demo-seed',1,8,9,9,2,515,'2026-09-30',2),
(568,'demo-seed',1,1,1,1,2,515,'2026-09-29',2),
(569,'demo-seed',1,2,2,2,2,515,'2026-09-29',5),
(570,'demo-seed',1,3,3,3,2,515,'2026-09-29',7),
(571,'demo-seed',1,4,4,4,2,515,'2026-09-29',3),
(572,'demo-seed',1,5,5,5,2,515,'2026-09-29',4),
(573,'demo-seed',1,6,7,7,2,515,'2026-09-29',4),
(574,'demo-seed',1,7,8,8,2,515,'2026-09-29',3),
(575,'demo-seed',1,8,9,9,2,515,'2026-09-29',4),
(576,'demo-seed',1,1,1,1,2,515,'2026-09-28',3),
(577,'demo-seed',1,2,2,2,2,515,'2026-09-28',4),
(578,'demo-seed',1,3,3,3,2,515,'2026-09-28',5),
(579,'demo-seed',1,4,4,4,2,515,'2026-09-28',3),
(580,'demo-seed',1,5,5,5,2,515,'2026-09-28',8),
(581,'demo-seed',1,6,7,7,2,515,'2026-09-28',3),
(582,'demo-seed',1,7,8,8,2,515,'2026-09-28',4),
(583,'demo-seed',1,8,9,9,2,515,'2026-09-28',2),
(584,'demo-seed',1,1,1,1,2,515,'2026-09-27',2),
(585,'demo-seed',1,2,2,2,2,515,'2026-09-27',3),
(586,'demo-seed',1,3,3,3,2,515,'2026-09-27',7),
(587,'demo-seed',1,4,4,4,2,515,'2026-09-27',1),
(588,'demo-seed',1,5,5,5,2,515,'2026-09-27',8),
(589,'demo-seed',1,6,7,7,2,515,'2026-09-27',5),
(590,'demo-seed',1,7,8,8,2,515,'2026-09-27',6),
(591,'demo-seed',1,8,9,9,2,515,'2026-09-27',2),
(592,'demo-seed',1,1,1,1,2,515,'2026-09-26',4),
(593,'demo-seed',1,2,2,2,2,515,'2026-09-26',5),
(594,'demo-seed',1,3,3,3,2,515,'2026-09-26',5),
(595,'demo-seed',1,4,4,4,2,515,'2026-09-26',1),
(596,'demo-seed',1,5,5,5,2,515,'2026-09-26',3),
(597,'demo-seed',1,6,7,7,2,515,'2026-09-26',5),
(598,'demo-seed',1,7,8,8,2,515,'2026-09-26',6),
(599,'demo-seed',1,8,9,9,2,515,'2026-09-26',2),
(600,'demo-seed',1,1,1,1,2,515,'2026-09-25',5),
(601,'demo-seed',1,2,2,2,2,515,'2026-09-25',3),
(602,'demo-seed',1,3,3,3,2,515,'2026-09-25',3),
(603,'demo-seed',1,4,4,4,2,515,'2026-09-25',1),
(604,'demo-seed',1,5,5,5,2,515,'2026-09-25',8),
(605,'demo-seed',1,6,7,7,2,515,'2026-09-25',3),
(606,'demo-seed',1,7,8,8,2,515,'2026-09-25',3),
(607,'demo-seed',1,8,9,9,2,515,'2026-09-25',1),
(608,'demo-seed',1,1,1,1,2,515,'2026-09-24',4),
(609,'demo-seed',1,2,2,2,2,515,'2026-09-24',2),
(610,'demo-seed',1,3,3,3,2,515,'2026-09-24',6),
(611,'demo-seed',1,4,4,4,2,515,'2026-09-24',3),
(612,'demo-seed',1,5,5,5,2,515,'2026-09-24',4),
(613,'demo-seed',1,6,7,7,2,515,'2026-09-24',5),
(614,'demo-seed',1,7,8,8,2,515,'2026-09-24',5),
(615,'demo-seed',1,8,9,9,2,515,'2026-09-24',2),
(616,'demo-seed',1,1,1,1,2,515,'2026-09-23',5),
(617,'demo-seed',1,2,2,2,2,515,'2026-09-23',2),
(618,'demo-seed',1,3,3,3,2,515,'2026-09-23',7),
(619,'demo-seed',1,4,4,4,2,515,'2026-09-23',3),
(620,'demo-seed',1,5,5,5,2,515,'2026-09-23',7),
(621,'demo-seed',1,6,7,7,2,515,'2026-09-23',4),
(622,'demo-seed',1,7,8,8,2,515,'2026-09-23',3),
(623,'demo-seed',1,8,9,9,2,515,'2026-09-23',3),
(624,'demo-seed',1,1,1,1,2,515,'2026-09-22',4),
(625,'demo-seed',1,2,2,2,2,515,'2026-09-22',4),
(626,'demo-seed',1,3,3,3,2,515,'2026-09-22',7),
(627,'demo-seed',1,4,4,4,2,515,'2026-09-22',1),
(628,'demo-seed',1,5,5,5,2,515,'2026-09-22',7),
(629,'demo-seed',1,6,7,7,2,515,'2026-09-22',3),
(630,'demo-seed',1,7,8,8,2,515,'2026-09-22',6),
(631,'demo-seed',1,8,9,9,2,515,'2026-09-22',3),
(632,'demo-seed',1,1,1,1,2,515,'2026-09-21',4),
(633,'demo-seed',1,2,2,2,2,515,'2026-09-21',4),
(634,'demo-seed',1,3,3,3,2,515,'2026-09-21',6),
(635,'demo-seed',1,4,4,4,2,515,'2026-09-21',2),
(636,'demo-seed',1,5,5,5,2,515,'2026-09-21',4),
(637,'demo-seed',1,6,7,7,2,515,'2026-09-21',2),
(638,'demo-seed',1,7,8,8,2,515,'2026-09-21',5),
(639,'demo-seed',1,8,9,9,2,515,'2026-09-21',3),
(640,'demo-seed',1,1,1,1,2,515,'2026-09-20',5),
(641,'demo-seed',1,2,2,2,2,515,'2026-09-20',4),
(642,'demo-seed',1,3,3,3,2,515,'2026-09-20',3),
(643,'demo-seed',1,4,4,4,2,515,'2026-09-20',2),
(644,'demo-seed',1,5,5,5,2,515,'2026-09-20',7),
(645,'demo-seed',1,6,7,7,2,515,'2026-09-20',5),
(646,'demo-seed',1,7,8,8,2,515,'2026-09-20',6),
(647,'demo-seed',1,8,9,9,2,515,'2026-09-20',1),
(648,'demo-seed',1,1,1,1,2,515,'2026-09-19',4),
(649,'demo-seed',1,2,2,2,2,515,'2026-09-19',2),
(650,'demo-seed',1,3,3,3,2,515,'2026-09-19',6),
(651,'demo-seed',1,4,4,4,2,515,'2026-09-19',2),
(652,'demo-seed',1,5,5,5,2,515,'2026-09-19',5),
(653,'demo-seed',1,6,7,7,2,515,'2026-09-19',4),
(654,'demo-seed',1,7,8,8,2,515,'2026-09-19',4),
(655,'demo-seed',1,8,9,9,2,515,'2026-09-19',1),
(656,'demo-seed',1,1,1,1,2,515,'2026-09-18',3),
(657,'demo-seed',1,2,2,2,2,515,'2026-09-18',3),
(658,'demo-seed',1,3,3,3,2,515,'2026-09-18',4),
(659,'demo-seed',1,4,4,4,2,515,'2026-09-18',1),
(660,'demo-seed',1,5,5,5,2,515,'2026-09-18',5),
(661,'demo-seed',1,6,7,7,2,515,'2026-09-18',4),
(662,'demo-seed',1,7,8,8,2,515,'2026-09-18',4),
(663,'demo-seed',1,8,9,9,2,515,'2026-09-18',3),
(664,'demo-seed',1,1,1,1,2,515,'2026-09-17',2),
(665,'demo-seed',1,2,2,2,2,515,'2026-09-17',3),
(666,'demo-seed',1,3,3,3,2,515,'2026-09-17',5),
(667,'demo-seed',1,4,4,4,2,515,'2026-09-17',2),
(668,'demo-seed',1,5,5,5,2,515,'2026-09-17',4),
(669,'demo-seed',1,6,7,7,2,515,'2026-09-17',4),
(670,'demo-seed',1,7,8,8,2,515,'2026-09-17',6),
(671,'demo-seed',1,8,9,9,2,515,'2026-09-17',3),
(672,'demo-seed',1,1,1,1,2,515,'2026-09-16',5),
(673,'demo-seed',1,2,2,2,2,515,'2026-09-16',2),
(674,'demo-seed',1,3,3,3,2,515,'2026-09-16',7),
(675,'demo-seed',1,4,4,4,2,515,'2026-09-16',3),
(676,'demo-seed',1,5,5,5,2,515,'2026-09-16',6),
(677,'demo-seed',1,6,7,7,2,515,'2026-09-16',4),
(678,'demo-seed',1,7,8,8,2,515,'2026-09-16',5),
(679,'demo-seed',1,8,9,9,2,515,'2026-09-16',3),
(680,'demo-seed',1,1,1,1,2,515,'2026-09-15',4),
(681,'demo-seed',1,2,2,2,2,515,'2026-09-15',4),
(682,'demo-seed',1,3,3,3,2,515,'2026-09-15',3),
(683,'demo-seed',1,4,4,4,2,515,'2026-09-15',3),
(684,'demo-seed',1,5,5,5,2,515,'2026-09-15',7),
(685,'demo-seed',1,6,7,7,2,515,'2026-09-15',2),
(686,'demo-seed',1,7,8,8,2,515,'2026-09-15',3),
(687,'demo-seed',1,8,9,9,2,515,'2026-09-15',2),
(688,'demo-seed',1,1,1,1,2,515,'2026-09-14',4),
(689,'demo-seed',1,2,2,2,2,515,'2026-09-14',3),
(690,'demo-seed',1,3,3,3,2,515,'2026-09-14',5),
(691,'demo-seed',1,4,4,4,2,515,'2026-09-14',2),
(692,'demo-seed',1,5,5,5,2,515,'2026-09-14',7),
(693,'demo-seed',1,6,7,7,2,515,'2026-09-14',3),
(694,'demo-seed',1,7,8,8,2,515,'2026-09-14',6),
(695,'demo-seed',1,8,9,9,2,515,'2026-09-14',2),
(696,'demo-seed',1,1,1,1,2,515,'2026-09-13',4),
(697,'demo-seed',1,2,2,2,2,515,'2026-09-13',2),
(698,'demo-seed',1,3,3,3,2,515,'2026-09-13',4),
(699,'demo-seed',1,4,4,4,2,515,'2026-09-13',3),
(700,'demo-seed',1,5,5,5,2,515,'2026-09-13',4),
(701,'demo-seed',1,6,7,7,2,515,'2026-09-13',3),
(702,'demo-seed',1,7,8,8,2,515,'2026-09-13',5),
(703,'demo-seed',1,8,9,9,2,515,'2026-09-13',2),
(704,'demo-seed',1,1,1,1,2,515,'2026-09-12',5),
(705,'demo-seed',1,2,2,2,2,515,'2026-09-12',3),
(706,'demo-seed',1,3,3,3,2,515,'2026-09-12',6),
(707,'demo-seed',1,4,4,4,2,515,'2026-09-12',2),
(708,'demo-seed',1,5,5,5,2,515,'2026-09-12',4),
(709,'demo-seed',1,6,7,7,2,515,'2026-09-12',3),
(710,'demo-seed',1,7,8,8,2,515,'2026-09-12',4),
(711,'demo-seed',1,8,9,9,2,515,'2026-09-12',3),
(712,'demo-seed',1,1,1,1,2,515,'2026-09-11',3),
(713,'demo-seed',1,2,2,2,2,515,'2026-09-11',2),
(714,'demo-seed',1,3,3,3,2,515,'2026-09-11',6),
(715,'demo-seed',1,4,4,4,2,515,'2026-09-11',1),
(716,'demo-seed',1,5,5,5,2,515,'2026-09-11',6),
(717,'demo-seed',1,6,7,7,2,515,'2026-09-11',3),
(718,'demo-seed',1,7,8,8,2,515,'2026-09-11',3),
(719,'demo-seed',1,8,9,9,2,515,'2026-09-11',2),
(720,'demo-seed',1,1,1,1,2,515,'2026-09-10',4),
(721,'demo-seed',1,2,2,2,2,515,'2026-09-10',3),
(722,'demo-seed',1,3,3,3,2,515,'2026-09-10',7),
(723,'demo-seed',1,4,4,4,2,515,'2026-09-10',3),
(724,'demo-seed',1,5,5,5,2,515,'2026-09-10',8),
(725,'demo-seed',1,6,7,7,2,515,'2026-09-10',2),
(726,'demo-seed',1,7,8,8,2,515,'2026-09-10',6),
(727,'demo-seed',1,8,9,9,2,515,'2026-09-10',4),
(728,'demo-seed',1,1,1,1,2,515,'2026-09-09',5),
(729,'demo-seed',1,2,2,2,2,515,'2026-09-09',4),
(730,'demo-seed',1,3,3,3,2,515,'2026-09-09',6),
(731,'demo-seed',1,4,4,4,2,515,'2026-09-09',3),
(732,'demo-seed',1,5,5,5,2,515,'2026-09-09',8),
(733,'demo-seed',1,6,7,7,2,515,'2026-09-09',5),
(734,'demo-seed',1,7,8,8,2,515,'2026-09-09',6),
(735,'demo-seed',1,8,9,9,2,515,'2026-09-09',2),
(736,'demo-seed',1,1,1,1,2,515,'2026-09-08',3),
(737,'demo-seed',1,2,2,2,2,515,'2026-09-08',3),
(738,'demo-seed',1,3,3,3,2,515,'2026-09-08',3),
(739,'demo-seed',1,4,4,4,2,515,'2026-09-08',2),
(740,'demo-seed',1,5,5,5,2,515,'2026-09-08',8),
(741,'demo-seed',1,6,7,7,2,515,'2026-09-08',4),
(742,'demo-seed',1,7,8,8,2,515,'2026-09-08',6),
(743,'demo-seed',1,8,9,9,2,515,'2026-09-08',3),
(744,'demo-seed',1,1,1,1,2,515,'2026-09-07',5),
(745,'demo-seed',1,2,2,2,2,515,'2026-09-07',3),
(746,'demo-seed',1,3,3,3,2,515,'2026-09-07',3),
(747,'demo-seed',1,4,4,4,2,515,'2026-09-07',2),
(748,'demo-seed',1,5,5,5,2,515,'2026-09-07',6),
(749,'demo-seed',1,6,7,7,2,515,'2026-09-07',2),
(750,'demo-seed',1,7,8,8,2,515,'2026-09-07',5),
(751,'demo-seed',1,8,9,9,2,515,'2026-09-07',2),
(752,'demo-seed',1,1,1,1,2,515,'2026-08-15',138),
(753,'demo-seed',1,2,2,2,2,515,'2026-08-15',89),
(754,'demo-seed',1,3,3,3,2,515,'2026-08-15',129),
(755,'demo-seed',1,4,4,4,2,515,'2026-08-15',55),
(756,'demo-seed',1,5,5,5,2,515,'2026-08-15',114),
(757,'demo-seed',1,6,7,7,2,515,'2026-08-15',64),
(758,'demo-seed',1,7,8,8,2,515,'2026-08-15',89),
(759,'demo-seed',1,8,9,9,2,515,'2026-08-15',45),
(760,'demo-seed',1,1,1,1,2,515,'2026-07-15',72),
(761,'demo-seed',1,2,2,2,2,515,'2026-07-15',41),
(762,'demo-seed',1,3,3,3,2,515,'2026-07-15',114),
(763,'demo-seed',1,4,4,4,2,515,'2026-07-15',60),
(764,'demo-seed',1,5,5,5,2,515,'2026-07-15',187),
(765,'demo-seed',1,6,7,7,2,515,'2026-07-15',61),
(766,'demo-seed',1,7,8,8,2,515,'2026-07-15',122),
(767,'demo-seed',1,8,9,9,2,515,'2026-07-15',56),
(768,'demo-seed',1,1,1,1,2,515,'2026-06-15',99),
(769,'demo-seed',1,2,2,2,2,515,'2026-06-15',72),
(770,'demo-seed',1,3,3,3,2,515,'2026-06-15',164),
(771,'demo-seed',1,4,4,4,2,515,'2026-06-15',76),
(772,'demo-seed',1,5,5,5,2,515,'2026-06-15',192),
(773,'demo-seed',1,6,7,7,2,515,'2026-06-15',85),
(774,'demo-seed',1,7,8,8,2,515,'2026-06-15',98),
(775,'demo-seed',1,8,9,9,2,515,'2026-06-15',56),
(776,'demo-seed',1,1,1,1,2,515,'2026-05-15',45),
(777,'demo-seed',1,2,2,2,2,515,'2026-05-15',73),
(778,'demo-seed',1,3,3,3,2,515,'2026-05-15',138),
(779,'demo-seed',1,4,4,4,2,515,'2026-05-15',59),
(780,'demo-seed',1,5,5,5,2,515,'2026-05-15',75),
(781,'demo-seed',1,6,7,7,2,515,'2026-05-15',110),
(782,'demo-seed',1,7,8,8,2,515,'2026-05-15',92),
(783,'demo-seed',1,8,9,9,2,515,'2026-05-15',45),
(784,'demo-seed',1,1,1,1,2,515,'2026-04-15',101),
(785,'demo-seed',1,2,2,2,2,515,'2026-04-15',94),
(786,'demo-seed',1,3,3,3,2,515,'2026-04-15',96),
(787,'demo-seed',1,4,4,4,2,515,'2026-04-15',32),
(788,'demo-seed',1,5,5,5,2,515,'2026-04-15',166),
(789,'demo-seed',1,6,7,7,2,515,'2026-04-15',46),
(790,'demo-seed',1,7,8,8,2,515,'2026-04-15',134),
(791,'demo-seed',1,8,9,9,2,515,'2026-04-15',44),
(792,'demo-seed',1,1,1,1,2,515,'2026-03-15',78),
(793,'demo-seed',1,2,2,2,2,515,'2026-03-15',69),
(794,'demo-seed',1,3,3,3,2,515,'2026-03-15',158),
(795,'demo-seed',1,4,4,4,2,515,'2026-03-15',43),
(796,'demo-seed',1,5,5,5,2,515,'2026-03-15',121),
(797,'demo-seed',1,6,7,7,2,515,'2026-03-15',76),
(798,'demo-seed',1,7,8,8,2,515,'2026-03-15',64),
(799,'demo-seed',1,8,9,9,2,515,'2026-03-15',68),
(800,'demo-seed',1,1,1,1,2,515,'2026-02-15',84),
(801,'demo-seed',1,2,2,2,2,515,'2026-02-15',50),
(802,'demo-seed',1,3,3,3,2,515,'2026-02-15',131),
(803,'demo-seed',1,4,4,4,2,515,'2026-02-15',50),
(804,'demo-seed',1,5,5,5,2,515,'2026-02-15',66),
(805,'demo-seed',1,6,7,7,2,515,'2026-02-15',50),
(806,'demo-seed',1,7,8,8,2,515,'2026-02-15',74),
(807,'demo-seed',1,8,9,9,2,515,'2026-02-15',38),
(808,'demo-seed',1,1,1,1,2,515,'2026-01-15',82),
(809,'demo-seed',1,2,2,2,2,515,'2026-01-15',58),
(810,'demo-seed',1,3,3,3,2,515,'2026-01-15',116),
(811,'demo-seed',1,4,4,4,2,515,'2026-01-15',51),
(812,'demo-seed',1,5,5,5,2,515,'2026-01-15',61),
(813,'demo-seed',1,6,7,7,2,515,'2026-01-15',51),
(814,'demo-seed',1,7,8,8,2,515,'2026-01-15',63),
(815,'demo-seed',1,8,9,9,2,515,'2026-01-15',39),
(816,'demo-seed',1,1,1,1,2,515,'2025-12-15',28),
(817,'demo-seed',1,2,2,2,2,515,'2025-12-15',55),
(818,'demo-seed',1,3,3,3,2,515,'2025-12-15',46),
(819,'demo-seed',1,4,4,4,2,515,'2025-12-15',46),
(820,'demo-seed',1,5,5,5,2,515,'2025-12-15',85),
(821,'demo-seed',1,6,7,7,2,515,'2025-12-15',65),
(822,'demo-seed',1,7,8,8,2,515,'2025-12-15',89),
(823,'demo-seed',1,8,9,9,2,515,'2025-12-15',57),
(824,'demo-seed',1,1,1,1,2,515,'2025-11-15',40),
(825,'demo-seed',1,2,2,2,2,515,'2025-11-15',25),
(826,'demo-seed',1,3,3,3,2,515,'2025-11-15',64),
(827,'demo-seed',1,4,4,4,2,515,'2025-11-15',29),
(828,'demo-seed',1,5,5,5,2,515,'2025-11-15',89),
(829,'demo-seed',1,6,7,7,2,515,'2025-11-15',68),
(830,'demo-seed',1,7,8,8,2,515,'2025-11-15',77),
(831,'demo-seed',1,8,9,9,2,515,'2025-11-15',42),
(832,'demo-seed',1,1,1,1,2,515,'2025-10-15',32),
(833,'demo-seed',1,2,2,2,2,515,'2025-10-15',62),
(834,'demo-seed',1,3,3,3,2,515,'2025-10-15',89),
(835,'demo-seed',1,4,4,4,2,515,'2025-10-15',40),
(836,'demo-seed',1,5,5,5,2,515,'2025-10-15',47),
(837,'demo-seed',1,6,7,7,2,515,'2025-10-15',26),
(838,'demo-seed',1,7,8,8,2,515,'2025-10-15',29),
(839,'demo-seed',1,8,9,9,2,515,'2025-10-15',20),
(840,'demo-seed',1,1,1,1,2,515,'2025-09-15',57),
(841,'demo-seed',1,2,2,2,2,515,'2025-09-15',27),
(842,'demo-seed',1,3,3,3,2,515,'2025-09-15',89),
(843,'demo-seed',1,4,4,4,2,515,'2025-09-15',27),
(844,'demo-seed',1,5,5,5,2,515,'2025-09-15',62),
(845,'demo-seed',1,6,7,7,2,515,'2025-09-15',63),
(846,'demo-seed',1,7,8,8,2,515,'2025-09-15',27),
(847,'demo-seed',1,8,9,9,2,515,'2025-09-15',47);
/*!40000 ALTER TABLE `metrics_submission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_submission_geo_daily`
--

DROP TABLE IF EXISTS `metrics_submission_geo_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_submission_geo_daily` (
  `metrics_submission_geo_daily_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `date` date NOT NULL,
  `metric` int(11) NOT NULL,
  `metric_unique` int(11) NOT NULL,
  PRIMARY KEY (`metrics_submission_geo_daily_id`),
  UNIQUE KEY `msgd_uc_load_context_submission_c_r_c_date` (`load_id`,`context_id`,`submission_id`,`country`,`region`,`city`(80),`date`),
  KEY `msgd_load_id` (`load_id`),
  KEY `metrics_submission_geo_daily_context_id` (`context_id`),
  KEY `metrics_submission_geo_daily_submission_id` (`submission_id`),
  KEY `msgd_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msgd_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msgd_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1024 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Daily statistics by country, region and city for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_submission_geo_daily`
--

LOCK TABLES `metrics_submission_geo_daily` WRITE;
/*!40000 ALTER TABLE `metrics_submission_geo_daily` DISABLE KEYS */;
INSERT INTO `metrics_submission_geo_daily` VALUES
(1,'demo-seed',1,1,'US','','','2026-09-07',2,1),
(2,'demo-seed',1,1,'IN','','','2026-09-07',2,1),
(3,'demo-seed',1,1,'DE','','','2026-09-07',1,1),
(4,'demo-seed',1,1,'BR','','','2026-09-07',1,1),
(5,'demo-seed',1,1,'IR','','','2026-09-07',1,1),
(6,'demo-seed',1,1,'US','','','2026-09-09',2,1),
(7,'demo-seed',1,1,'IN','','','2026-09-09',2,1),
(8,'demo-seed',1,1,'US','','','2026-09-10',2,1),
(9,'demo-seed',1,1,'IN','','','2026-09-10',1,1),
(10,'demo-seed',1,1,'GB','','','2026-09-10',1,1),
(11,'demo-seed',1,1,'US','','','2026-09-11',1,1),
(12,'demo-seed',1,1,'IN','','','2026-09-11',1,1),
(13,'demo-seed',1,1,'GB','','','2026-09-11',1,1),
(14,'demo-seed',1,1,'US','','','2026-09-12',1,1),
(15,'demo-seed',1,1,'IN','','','2026-09-12',1,1),
(16,'demo-seed',1,1,'US','','','2026-09-13',2,1),
(17,'demo-seed',1,1,'IN','','','2026-09-13',2,1),
(18,'demo-seed',1,1,'US','','','2026-09-14',2,1),
(19,'demo-seed',1,1,'IN','','','2026-09-14',1,1),
(20,'demo-seed',1,1,'US','','','2026-09-16',2,1),
(21,'demo-seed',1,1,'US','','','2026-09-17',1,1),
(22,'demo-seed',1,1,'IN','','','2026-09-17',1,1),
(23,'demo-seed',1,1,'US','','','2026-09-18',2,1),
(24,'demo-seed',1,1,'IN','','','2026-09-18',1,1),
(25,'demo-seed',1,1,'IN','','','2026-09-19',1,1),
(26,'demo-seed',1,1,'US','','','2026-09-21',2,1),
(27,'demo-seed',1,1,'IN','','','2026-09-21',1,1),
(28,'demo-seed',1,1,'CN','','','2026-09-21',1,1),
(29,'demo-seed',1,1,'GB','','','2026-09-21',1,1),
(30,'demo-seed',1,1,'BR','','','2026-09-21',1,1),
(31,'demo-seed',1,1,'US','','','2026-09-22',2,1),
(32,'demo-seed',1,1,'US','','','2026-09-23',3,1),
(33,'demo-seed',1,1,'IN','','','2026-09-23',2,1),
(34,'demo-seed',1,1,'CN','','','2026-09-23',2,1),
(35,'demo-seed',1,1,'GB','','','2026-09-23',1,1),
(36,'demo-seed',1,1,'IR','','','2026-09-23',1,1),
(37,'demo-seed',1,1,'US','','','2026-09-24',1,1),
(38,'demo-seed',1,1,'IN','','','2026-09-24',2,1),
(39,'demo-seed',1,1,'CN','','','2026-09-24',1,1),
(40,'demo-seed',1,1,'GB','','','2026-09-24',1,1),
(41,'demo-seed',1,1,'US','','','2026-09-25',3,1),
(42,'demo-seed',1,1,'IN','','','2026-09-25',2,1),
(43,'demo-seed',1,1,'CN','','','2026-09-25',1,1),
(44,'demo-seed',1,1,'BR','','','2026-09-25',1,1),
(45,'demo-seed',1,1,'US','','','2026-09-26',1,1),
(46,'demo-seed',1,1,'IN','','','2026-09-26',2,1),
(47,'demo-seed',1,1,'CN','','','2026-09-26',1,1),
(48,'demo-seed',1,1,'US','','','2026-09-28',2,1),
(49,'demo-seed',1,1,'IN','','','2026-09-28',1,1),
(50,'demo-seed',1,1,'BR','','','2026-09-28',1,1),
(51,'demo-seed',1,1,'US','','','2026-09-29',1,1),
(52,'demo-seed',1,1,'IN','','','2026-09-29',1,1),
(53,'demo-seed',1,1,'US','','','2026-09-30',1,1),
(54,'demo-seed',1,1,'IN','','','2026-09-30',1,1),
(55,'demo-seed',1,1,'US','','','2026-10-01',2,1),
(56,'demo-seed',1,1,'IN','','','2026-10-01',1,1),
(57,'demo-seed',1,1,'CN','','','2026-10-01',1,1),
(58,'demo-seed',1,1,'US','','','2026-10-02',2,1),
(59,'demo-seed',1,1,'IN','','','2026-10-02',1,1),
(60,'demo-seed',1,1,'CN','','','2026-10-02',1,1),
(61,'demo-seed',1,1,'US','','','2026-10-03',1,1),
(62,'demo-seed',1,1,'IN','','','2026-10-03',2,1),
(63,'demo-seed',1,1,'GB','','','2026-10-03',1,1),
(64,'demo-seed',1,1,'DE','','','2026-10-03',1,1),
(65,'demo-seed',1,1,'BR','','','2026-10-03',1,1),
(66,'demo-seed',1,1,'US','','','2026-10-04',1,1),
(67,'demo-seed',1,1,'IN','','','2026-10-04',1,1),
(68,'demo-seed',1,1,'US','','','2026-10-05',1,1),
(69,'demo-seed',1,1,'IN','','','2026-10-05',1,1),
(70,'demo-seed',1,1,'US','','','2026-10-06',1,1),
(71,'demo-seed',1,1,'IN','','','2026-10-06',1,1),
(72,'demo-seed',1,2,'US','','','2026-09-07',1,1),
(73,'demo-seed',1,2,'IN','','','2026-09-07',1,1),
(74,'demo-seed',1,2,'US','','','2026-09-08',2,1),
(75,'demo-seed',1,2,'IN','','','2026-09-08',1,1),
(76,'demo-seed',1,2,'CN','','','2026-09-08',1,1),
(77,'demo-seed',1,2,'US','','','2026-09-09',2,1),
(78,'demo-seed',1,2,'CN','','','2026-09-09',1,1),
(79,'demo-seed',1,2,'GB','','','2026-09-09',1,1),
(80,'demo-seed',1,2,'US','','','2026-09-10',1,1),
(81,'demo-seed',1,2,'IN','','','2026-09-10',1,1),
(82,'demo-seed',1,2,'CN','','','2026-09-10',1,1),
(83,'demo-seed',1,2,'GB','','','2026-09-10',1,1),
(84,'demo-seed',1,2,'US','','','2026-09-11',1,1),
(85,'demo-seed',1,2,'IN','','','2026-09-12',1,1),
(86,'demo-seed',1,2,'US','','','2026-09-13',2,1),
(87,'demo-seed',1,2,'IN','','','2026-09-13',1,1),
(88,'demo-seed',1,2,'IN','','','2026-09-14',1,1),
(89,'demo-seed',1,2,'US','','','2026-09-15',2,1),
(90,'demo-seed',1,2,'IN','','','2026-09-15',1,1),
(91,'demo-seed',1,2,'CN','','','2026-09-15',1,1),
(92,'demo-seed',1,2,'US','','','2026-09-16',1,1),
(93,'demo-seed',1,2,'IN','','','2026-09-16',1,1),
(94,'demo-seed',1,2,'US','','','2026-09-17',1,1),
(95,'demo-seed',1,2,'IN','','','2026-09-17',2,1),
(96,'demo-seed',1,2,'CN','','','2026-09-17',1,1),
(97,'demo-seed',1,2,'US','','','2026-09-18',2,1),
(98,'demo-seed',1,2,'IN','','','2026-09-18',1,1),
(99,'demo-seed',1,2,'DE','','','2026-09-18',1,1),
(100,'demo-seed',1,2,'US','','','2026-09-19',1,1),
(101,'demo-seed',1,2,'IN','','','2026-09-19',1,1),
(102,'demo-seed',1,2,'DE','','','2026-09-19',1,1),
(103,'demo-seed',1,2,'BR','','','2026-09-19',1,1),
(104,'demo-seed',1,2,'US','','','2026-09-23',2,1),
(105,'demo-seed',1,2,'IN','','','2026-09-23',1,1),
(106,'demo-seed',1,2,'GB','','','2026-09-23',1,1),
(107,'demo-seed',1,2,'US','','','2026-09-24',1,1),
(108,'demo-seed',1,2,'IN','','','2026-09-24',1,1),
(109,'demo-seed',1,2,'CN','','','2026-09-24',1,1),
(110,'demo-seed',1,2,'US','','','2026-09-25',1,1),
(111,'demo-seed',1,2,'IN','','','2026-09-25',2,1),
(112,'demo-seed',1,2,'BR','','','2026-09-25',1,1),
(113,'demo-seed',1,2,'US','','','2026-09-26',1,1),
(114,'demo-seed',1,2,'IN','','','2026-09-26',2,1),
(115,'demo-seed',1,2,'US','','','2026-09-27',2,1),
(116,'demo-seed',1,2,'IN','','','2026-09-27',1,1),
(117,'demo-seed',1,2,'IN','','','2026-09-30',2,1),
(118,'demo-seed',1,2,'GB','','','2026-09-30',1,1),
(119,'demo-seed',1,2,'US','','','2026-10-01',1,1),
(120,'demo-seed',1,2,'IN','','','2026-10-01',1,1),
(121,'demo-seed',1,2,'GB','','','2026-10-01',1,1),
(122,'demo-seed',1,2,'US','','','2026-10-02',2,1),
(123,'demo-seed',1,2,'US','','','2026-10-05',1,1),
(124,'demo-seed',1,3,'US','','','2026-09-07',1,1),
(125,'demo-seed',1,3,'IN','','','2026-09-07',1,1),
(126,'demo-seed',1,3,'GB','','','2026-09-07',1,1),
(127,'demo-seed',1,3,'US','','','2026-09-08',1,1),
(128,'demo-seed',1,3,'IN','','','2026-09-08',2,1),
(129,'demo-seed',1,3,'CN','','','2026-09-08',1,1),
(130,'demo-seed',1,3,'GB','','','2026-09-08',1,1),
(131,'demo-seed',1,3,'DE','','','2026-09-08',1,1),
(132,'demo-seed',1,3,'BR','','','2026-09-08',1,1),
(133,'demo-seed',1,3,'NG','','','2026-09-08',1,1),
(134,'demo-seed',1,3,'US','','','2026-09-09',3,2),
(135,'demo-seed',1,3,'IN','','','2026-09-09',2,1),
(136,'demo-seed',1,3,'CN','','','2026-09-09',1,1),
(137,'demo-seed',1,3,'GB','','','2026-09-09',1,1),
(138,'demo-seed',1,3,'DE','','','2026-09-09',1,1),
(139,'demo-seed',1,3,'NG','','','2026-09-09',1,1),
(140,'demo-seed',1,3,'EG','','','2026-09-09',1,1),
(141,'demo-seed',1,3,'US','','','2026-09-10',1,1),
(142,'demo-seed',1,3,'IN','','','2026-09-10',2,1),
(143,'demo-seed',1,3,'CN','','','2026-09-10',2,1),
(144,'demo-seed',1,3,'BR','','','2026-09-10',1,1),
(145,'demo-seed',1,3,'US','','','2026-09-11',3,2),
(146,'demo-seed',1,3,'IN','','','2026-09-11',2,1),
(147,'demo-seed',1,3,'CN','','','2026-09-11',1,1),
(148,'demo-seed',1,3,'GB','','','2026-09-11',2,1),
(149,'demo-seed',1,3,'DE','','','2026-09-11',1,1),
(150,'demo-seed',1,3,'BR','','','2026-09-11',1,1),
(151,'demo-seed',1,3,'EG','','','2026-09-11',1,1),
(152,'demo-seed',1,3,'US','','','2026-09-12',2,1),
(153,'demo-seed',1,3,'IN','','','2026-09-12',1,1),
(154,'demo-seed',1,3,'CN','','','2026-09-12',1,1),
(155,'demo-seed',1,3,'US','','','2026-09-13',2,1),
(156,'demo-seed',1,3,'IN','','','2026-09-13',2,1),
(157,'demo-seed',1,3,'CN','','','2026-09-13',1,1),
(158,'demo-seed',1,3,'GB','','','2026-09-13',1,1),
(159,'demo-seed',1,3,'DE','','','2026-09-13',1,1),
(160,'demo-seed',1,3,'US','','','2026-09-14',3,2),
(161,'demo-seed',1,3,'IN','','','2026-09-14',2,1),
(162,'demo-seed',1,3,'CN','','','2026-09-14',1,1),
(163,'demo-seed',1,3,'GB','','','2026-09-14',1,1),
(164,'demo-seed',1,3,'DE','','','2026-09-14',1,1),
(165,'demo-seed',1,3,'BR','','','2026-09-14',1,1),
(166,'demo-seed',1,3,'IR','','','2026-09-14',1,1),
(167,'demo-seed',1,3,'US','','','2026-09-15',2,1),
(168,'demo-seed',1,3,'IN','','','2026-09-15',2,1),
(169,'demo-seed',1,3,'CN','','','2026-09-15',1,1),
(170,'demo-seed',1,3,'GB','','','2026-09-15',1,1),
(171,'demo-seed',1,3,'DE','','','2026-09-15',1,1),
(172,'demo-seed',1,3,'BR','','','2026-09-15',1,1),
(173,'demo-seed',1,3,'IR','','','2026-09-15',1,1),
(174,'demo-seed',1,3,'US','','','2026-09-16',2,1),
(175,'demo-seed',1,3,'IN','','','2026-09-16',2,1),
(176,'demo-seed',1,3,'CN','','','2026-09-16',2,1),
(177,'demo-seed',1,3,'DE','','','2026-09-16',2,1),
(178,'demo-seed',1,3,'BR','','','2026-09-16',1,1),
(179,'demo-seed',1,3,'IR','','','2026-09-16',1,1),
(180,'demo-seed',1,3,'US','','','2026-09-17',1,1),
(181,'demo-seed',1,3,'IN','','','2026-09-17',1,1),
(182,'demo-seed',1,3,'CN','','','2026-09-17',1,1),
(183,'demo-seed',1,3,'GB','','','2026-09-17',1,1),
(184,'demo-seed',1,3,'BR','','','2026-09-17',1,1),
(185,'demo-seed',1,3,'NG','','','2026-09-17',1,1),
(186,'demo-seed',1,3,'PK','','','2026-09-17',1,1),
(187,'demo-seed',1,3,'US','','','2026-09-18',2,1),
(188,'demo-seed',1,3,'IN','','','2026-09-18',2,1),
(189,'demo-seed',1,3,'CN','','','2026-09-18',1,1),
(190,'demo-seed',1,3,'GB','','','2026-09-18',1,1),
(191,'demo-seed',1,3,'BR','','','2026-09-18',1,1),
(192,'demo-seed',1,3,'IR','','','2026-09-18',1,1),
(193,'demo-seed',1,3,'US','','','2026-09-19',3,2),
(194,'demo-seed',1,3,'IN','','','2026-09-19',2,1),
(195,'demo-seed',1,3,'CN','','','2026-09-19',1,1),
(196,'demo-seed',1,3,'GB','','','2026-09-19',1,1),
(197,'demo-seed',1,3,'BR','','','2026-09-19',1,1),
(198,'demo-seed',1,3,'NG','','','2026-09-19',1,1),
(199,'demo-seed',1,3,'IR','','','2026-09-19',1,1),
(200,'demo-seed',1,3,'EG','','','2026-09-19',1,1),
(201,'demo-seed',1,3,'US','','','2026-09-20',1,1),
(202,'demo-seed',1,3,'IN','','','2026-09-20',1,1),
(203,'demo-seed',1,3,'US','','','2026-09-21',2,1),
(204,'demo-seed',1,3,'IN','','','2026-09-21',2,1),
(205,'demo-seed',1,3,'DE','','','2026-09-21',1,1),
(206,'demo-seed',1,3,'US','','','2026-09-22',2,1),
(207,'demo-seed',1,3,'IN','','','2026-09-22',2,1),
(208,'demo-seed',1,3,'CN','','','2026-09-22',2,1),
(209,'demo-seed',1,3,'GB','','','2026-09-22',1,1),
(210,'demo-seed',1,3,'DE','','','2026-09-22',1,1),
(211,'demo-seed',1,3,'NG','','','2026-09-22',1,1),
(212,'demo-seed',1,3,'IR','','','2026-09-22',1,1),
(213,'demo-seed',1,3,'US','','','2026-09-23',2,1),
(214,'demo-seed',1,3,'IN','','','2026-09-23',1,1),
(215,'demo-seed',1,3,'CN','','','2026-09-23',2,1),
(216,'demo-seed',1,3,'GB','','','2026-09-23',1,1),
(217,'demo-seed',1,3,'DE','','','2026-09-23',1,1),
(218,'demo-seed',1,3,'BR','','','2026-09-23',1,1),
(219,'demo-seed',1,3,'NG','','','2026-09-23',1,1),
(220,'demo-seed',1,3,'IR','','','2026-09-23',1,1),
(221,'demo-seed',1,3,'US','','','2026-09-24',2,1),
(222,'demo-seed',1,3,'IN','','','2026-09-24',3,2),
(223,'demo-seed',1,3,'CN','','','2026-09-24',2,1),
(224,'demo-seed',1,3,'GB','','','2026-09-24',1,1),
(225,'demo-seed',1,3,'DE','','','2026-09-24',1,1),
(226,'demo-seed',1,3,'BR','','','2026-09-24',1,1),
(227,'demo-seed',1,3,'US','','','2026-09-25',3,2),
(228,'demo-seed',1,3,'IN','','','2026-09-25',2,1),
(229,'demo-seed',1,3,'CN','','','2026-09-25',1,1),
(230,'demo-seed',1,3,'GB','','','2026-09-25',1,1),
(231,'demo-seed',1,3,'DE','','','2026-09-25',1,1),
(232,'demo-seed',1,3,'BR','','','2026-09-25',1,1),
(233,'demo-seed',1,3,'NG','','','2026-09-25',1,1),
(234,'demo-seed',1,3,'PK','','','2026-09-25',1,1),
(235,'demo-seed',1,3,'US','','','2026-09-26',3,2),
(236,'demo-seed',1,3,'IN','','','2026-09-26',2,1),
(237,'demo-seed',1,3,'CN','','','2026-09-26',2,1),
(238,'demo-seed',1,3,'GB','','','2026-09-26',2,1),
(239,'demo-seed',1,3,'DE','','','2026-09-26',1,1),
(240,'demo-seed',1,3,'BR','','','2026-09-26',1,1),
(241,'demo-seed',1,3,'NG','','','2026-09-26',1,1),
(242,'demo-seed',1,3,'EG','','','2026-09-26',1,1),
(243,'demo-seed',1,3,'US','','','2026-09-27',2,1),
(244,'demo-seed',1,3,'IN','','','2026-09-27',3,2),
(245,'demo-seed',1,3,'CN','','','2026-09-27',2,1),
(246,'demo-seed',1,3,'GB','','','2026-09-27',1,1),
(247,'demo-seed',1,3,'DE','','','2026-09-27',1,1),
(248,'demo-seed',1,3,'BR','','','2026-09-27',1,1),
(249,'demo-seed',1,3,'NG','','','2026-09-27',1,1),
(250,'demo-seed',1,3,'IR','','','2026-09-27',1,1),
(251,'demo-seed',1,3,'US','','','2026-09-28',3,2),
(252,'demo-seed',1,3,'IN','','','2026-09-28',2,1),
(253,'demo-seed',1,3,'CN','','','2026-09-28',1,1),
(254,'demo-seed',1,3,'GB','','','2026-09-28',1,1),
(255,'demo-seed',1,3,'DE','','','2026-09-28',1,1),
(256,'demo-seed',1,3,'BR','','','2026-09-28',1,1),
(257,'demo-seed',1,3,'PK','','','2026-09-28',1,1),
(258,'demo-seed',1,3,'US','','','2026-09-29',2,1),
(259,'demo-seed',1,3,'IN','','','2026-09-29',2,1),
(260,'demo-seed',1,3,'CN','','','2026-09-29',1,1),
(261,'demo-seed',1,3,'GB','','','2026-09-29',2,1),
(262,'demo-seed',1,3,'NG','','','2026-09-29',1,1),
(263,'demo-seed',1,3,'IR','','','2026-09-29',1,1),
(264,'demo-seed',1,3,'EG','','','2026-09-29',1,1),
(265,'demo-seed',1,3,'US','','','2026-09-30',2,1),
(266,'demo-seed',1,3,'IN','','','2026-09-30',2,1),
(267,'demo-seed',1,3,'GB','','','2026-09-30',1,1),
(268,'demo-seed',1,3,'BR','','','2026-09-30',1,1),
(269,'demo-seed',1,3,'US','','','2026-10-01',2,1),
(270,'demo-seed',1,3,'IN','','','2026-10-01',1,1),
(271,'demo-seed',1,3,'CN','','','2026-10-01',2,1),
(272,'demo-seed',1,3,'GB','','','2026-10-01',1,1),
(273,'demo-seed',1,3,'US','','','2026-10-02',3,2),
(274,'demo-seed',1,3,'IN','','','2026-10-02',3,2),
(275,'demo-seed',1,3,'CN','','','2026-10-02',1,1),
(276,'demo-seed',1,3,'GB','','','2026-10-02',1,1),
(277,'demo-seed',1,3,'DE','','','2026-10-02',1,1),
(278,'demo-seed',1,3,'BR','','','2026-10-02',1,1),
(279,'demo-seed',1,3,'NG','','','2026-10-02',1,1),
(280,'demo-seed',1,3,'US','','','2026-10-03',3,2),
(281,'demo-seed',1,3,'IN','','','2026-10-03',2,1),
(282,'demo-seed',1,3,'CN','','','2026-10-03',1,1),
(283,'demo-seed',1,3,'GB','','','2026-10-03',1,1),
(284,'demo-seed',1,3,'DE','','','2026-10-03',1,1),
(285,'demo-seed',1,3,'IR','','','2026-10-03',1,1),
(286,'demo-seed',1,3,'US','','','2026-10-04',2,1),
(287,'demo-seed',1,3,'IN','','','2026-10-04',1,1),
(288,'demo-seed',1,3,'CN','','','2026-10-04',1,1),
(289,'demo-seed',1,3,'US','','','2026-10-05',1,1),
(290,'demo-seed',1,3,'IN','','','2026-10-05',2,1),
(291,'demo-seed',1,3,'CN','','','2026-10-05',1,1),
(292,'demo-seed',1,3,'GB','','','2026-10-05',1,1),
(293,'demo-seed',1,3,'US','','','2026-10-06',3,1),
(294,'demo-seed',1,3,'IN','','','2026-10-06',2,1),
(295,'demo-seed',1,3,'CN','','','2026-10-06',1,1),
(296,'demo-seed',1,3,'BR','','','2026-10-06',1,1),
(297,'demo-seed',1,4,'US','','','2026-09-09',1,1),
(298,'demo-seed',1,4,'IN','','','2026-09-09',1,1),
(299,'demo-seed',1,4,'US','','','2026-09-10',1,1),
(300,'demo-seed',1,4,'US','','','2026-09-13',1,1),
(301,'demo-seed',1,4,'US','','','2026-09-15',1,1),
(302,'demo-seed',1,4,'US','','','2026-09-17',1,1),
(303,'demo-seed',1,4,'IN','','','2026-09-17',1,1),
(304,'demo-seed',1,4,'US','','','2026-09-19',1,1),
(305,'demo-seed',1,4,'US','','','2026-09-21',1,1),
(306,'demo-seed',1,4,'IN','','','2026-09-22',1,1),
(307,'demo-seed',1,4,'IN','','','2026-09-23',1,1),
(308,'demo-seed',1,4,'US','','','2026-09-25',1,1),
(309,'demo-seed',1,4,'IN','','','2026-09-25',1,1),
(310,'demo-seed',1,4,'US','','','2026-09-26',1,1),
(311,'demo-seed',1,4,'US','','','2026-09-27',1,1),
(312,'demo-seed',1,4,'US','','','2026-09-28',1,1),
(313,'demo-seed',1,4,'IN','','','2026-09-28',1,1),
(314,'demo-seed',1,4,'US','','','2026-09-30',1,1),
(315,'demo-seed',1,4,'US','','','2026-10-04',1,1),
(316,'demo-seed',1,5,'US','','','2026-09-07',4,2),
(317,'demo-seed',1,5,'IN','','','2026-09-07',2,1),
(318,'demo-seed',1,5,'CN','','','2026-09-07',2,1),
(319,'demo-seed',1,5,'GB','','','2026-09-07',1,1),
(320,'demo-seed',1,5,'DE','','','2026-09-07',1,1),
(321,'demo-seed',1,5,'BR','','','2026-09-07',1,1),
(322,'demo-seed',1,5,'IR','','','2026-09-07',1,1),
(323,'demo-seed',1,5,'PK','','','2026-09-07',1,1),
(324,'demo-seed',1,5,'US','','','2026-09-08',3,1),
(325,'demo-seed',1,5,'IN','','','2026-09-08',2,1),
(326,'demo-seed',1,5,'CN','','','2026-09-08',2,1),
(327,'demo-seed',1,5,'GB','','','2026-09-08',1,1),
(328,'demo-seed',1,5,'US','','','2026-09-09',2,1),
(329,'demo-seed',1,5,'IN','','','2026-09-09',1,1),
(330,'demo-seed',1,5,'DE','','','2026-09-09',1,1),
(331,'demo-seed',1,5,'US','','','2026-09-10',2,1),
(332,'demo-seed',1,5,'IN','','','2026-09-10',3,1),
(333,'demo-seed',1,5,'GB','','','2026-09-10',1,1),
(334,'demo-seed',1,5,'DE','','','2026-09-10',1,1),
(335,'demo-seed',1,5,'US','','','2026-09-11',2,1),
(336,'demo-seed',1,5,'IN','','','2026-09-11',2,1),
(337,'demo-seed',1,5,'CN','','','2026-09-11',1,1),
(338,'demo-seed',1,5,'GB','','','2026-09-11',2,1),
(339,'demo-seed',1,5,'DE','','','2026-09-11',1,1),
(340,'demo-seed',1,5,'BR','','','2026-09-11',1,1),
(341,'demo-seed',1,5,'NG','','','2026-09-11',1,1),
(342,'demo-seed',1,5,'US','','','2026-09-12',2,1),
(343,'demo-seed',1,5,'IN','','','2026-09-12',2,1),
(344,'demo-seed',1,5,'CN','','','2026-09-12',2,1),
(345,'demo-seed',1,5,'GB','','','2026-09-12',1,1),
(346,'demo-seed',1,5,'BR','','','2026-09-12',1,1),
(347,'demo-seed',1,5,'NG','','','2026-09-12',1,1),
(348,'demo-seed',1,5,'IR','','','2026-09-12',1,1),
(349,'demo-seed',1,5,'PK','','','2026-09-12',1,1),
(350,'demo-seed',1,5,'US','','','2026-09-13',2,1),
(351,'demo-seed',1,5,'IN','','','2026-09-13',1,1),
(352,'demo-seed',1,5,'CN','','','2026-09-13',1,1),
(353,'demo-seed',1,5,'GB','','','2026-09-13',1,1),
(354,'demo-seed',1,5,'US','','','2026-09-14',3,2),
(355,'demo-seed',1,5,'IN','','','2026-09-14',1,1),
(356,'demo-seed',1,5,'CN','','','2026-09-14',1,1),
(357,'demo-seed',1,5,'GB','','','2026-09-14',1,1),
(358,'demo-seed',1,5,'DE','','','2026-09-14',1,1),
(359,'demo-seed',1,5,'BR','','','2026-09-14',1,1),
(360,'demo-seed',1,5,'IR','','','2026-09-14',1,1),
(361,'demo-seed',1,5,'EG','','','2026-09-14',1,1),
(362,'demo-seed',1,5,'US','','','2026-09-15',2,1),
(363,'demo-seed',1,5,'IN','','','2026-09-15',2,1),
(364,'demo-seed',1,5,'GB','','','2026-09-15',1,1),
(365,'demo-seed',1,5,'BR','','','2026-09-15',1,1),
(366,'demo-seed',1,5,'IR','','','2026-09-15',1,1),
(367,'demo-seed',1,5,'US','','','2026-09-16',2,1),
(368,'demo-seed',1,5,'IN','','','2026-09-16',1,1),
(369,'demo-seed',1,5,'CN','','','2026-09-16',1,1),
(370,'demo-seed',1,5,'GB','','','2026-09-16',1,1),
(371,'demo-seed',1,5,'US','','','2026-09-17',2,1),
(372,'demo-seed',1,5,'IN','','','2026-09-17',1,1),
(373,'demo-seed',1,5,'CN','','','2026-09-17',2,1),
(374,'demo-seed',1,5,'GB','','','2026-09-17',1,1),
(375,'demo-seed',1,5,'BR','','','2026-09-17',1,1),
(376,'demo-seed',1,5,'NG','','','2026-09-17',1,1),
(377,'demo-seed',1,5,'IR','','','2026-09-17',1,1),
(378,'demo-seed',1,5,'US','','','2026-09-18',2,1),
(379,'demo-seed',1,5,'IN','','','2026-09-18',1,1),
(380,'demo-seed',1,5,'CN','','','2026-09-18',1,1),
(381,'demo-seed',1,5,'GB','','','2026-09-18',1,1),
(382,'demo-seed',1,5,'DE','','','2026-09-18',1,1),
(383,'demo-seed',1,5,'BR','','','2026-09-18',1,1),
(384,'demo-seed',1,5,'US','','','2026-09-19',2,1),
(385,'demo-seed',1,5,'IN','','','2026-09-19',1,1),
(386,'demo-seed',1,5,'CN','','','2026-09-19',1,1),
(387,'demo-seed',1,5,'BR','','','2026-09-19',1,1),
(388,'demo-seed',1,5,'US','','','2026-09-20',2,1),
(389,'demo-seed',1,5,'IN','','','2026-09-20',2,1),
(390,'demo-seed',1,5,'CN','','','2026-09-20',1,1),
(391,'demo-seed',1,5,'GB','','','2026-09-20',1,1),
(392,'demo-seed',1,5,'BR','','','2026-09-20',1,1),
(393,'demo-seed',1,5,'US','','','2026-09-21',2,1),
(394,'demo-seed',1,5,'IN','','','2026-09-21',3,2),
(395,'demo-seed',1,5,'CN','','','2026-09-21',1,1),
(396,'demo-seed',1,5,'GB','','','2026-09-21',1,1),
(397,'demo-seed',1,5,'BR','','','2026-09-21',1,1),
(398,'demo-seed',1,5,'US','','','2026-09-22',2,1),
(399,'demo-seed',1,5,'IN','','','2026-09-22',2,1),
(400,'demo-seed',1,5,'CN','','','2026-09-22',2,1),
(401,'demo-seed',1,5,'GB','','','2026-09-22',2,1),
(402,'demo-seed',1,5,'DE','','','2026-09-22',1,1),
(403,'demo-seed',1,5,'BR','','','2026-09-22',2,1),
(404,'demo-seed',1,5,'IR','','','2026-09-22',1,1),
(405,'demo-seed',1,5,'EG','','','2026-09-22',1,1),
(406,'demo-seed',1,5,'US','','','2026-09-23',2,1),
(407,'demo-seed',1,5,'IN','','','2026-09-23',1,1),
(408,'demo-seed',1,5,'CN','','','2026-09-23',1,1),
(409,'demo-seed',1,5,'DE','','','2026-09-23',1,1),
(410,'demo-seed',1,5,'BR','','','2026-09-23',2,1),
(411,'demo-seed',1,5,'NG','','','2026-09-23',2,1),
(412,'demo-seed',1,5,'US','','','2026-09-24',1,1),
(413,'demo-seed',1,5,'IN','','','2026-09-24',2,1),
(414,'demo-seed',1,5,'CN','','','2026-09-24',1,1),
(415,'demo-seed',1,5,'GB','','','2026-09-24',1,1),
(416,'demo-seed',1,5,'US','','','2026-09-25',2,1),
(417,'demo-seed',1,5,'BR','','','2026-09-25',1,1),
(418,'demo-seed',1,5,'US','','','2026-09-26',2,1),
(419,'demo-seed',1,5,'IN','','','2026-09-26',2,1),
(420,'demo-seed',1,5,'CN','','','2026-09-26',1,1),
(421,'demo-seed',1,5,'US','','','2026-09-27',1,1),
(422,'demo-seed',1,5,'IN','','','2026-09-27',2,1),
(423,'demo-seed',1,5,'CN','','','2026-09-27',1,1),
(424,'demo-seed',1,5,'GB','','','2026-09-27',1,1),
(425,'demo-seed',1,5,'US','','','2026-09-28',2,1),
(426,'demo-seed',1,5,'IN','','','2026-09-28',2,1),
(427,'demo-seed',1,5,'CN','','','2026-09-28',2,1),
(428,'demo-seed',1,5,'GB','','','2026-09-28',1,1),
(429,'demo-seed',1,5,'DE','','','2026-09-28',1,1),
(430,'demo-seed',1,5,'US','','','2026-09-29',3,2),
(431,'demo-seed',1,5,'IN','','','2026-09-29',2,1),
(432,'demo-seed',1,5,'GB','','','2026-09-29',1,1),
(433,'demo-seed',1,5,'NG','','','2026-09-29',1,1),
(434,'demo-seed',1,5,'EG','','','2026-09-29',1,1),
(435,'demo-seed',1,5,'US','','','2026-09-30',3,2),
(436,'demo-seed',1,5,'IN','','','2026-09-30',2,1),
(437,'demo-seed',1,5,'CN','','','2026-09-30',1,1),
(438,'demo-seed',1,5,'US','','','2026-10-01',3,2),
(439,'demo-seed',1,5,'IN','','','2026-10-01',2,1),
(440,'demo-seed',1,5,'GB','','','2026-10-01',1,1),
(441,'demo-seed',1,5,'BR','','','2026-10-01',1,1),
(442,'demo-seed',1,5,'IR','','','2026-10-01',1,1),
(443,'demo-seed',1,5,'US','','','2026-10-02',1,1),
(444,'demo-seed',1,5,'IN','','','2026-10-02',2,1),
(445,'demo-seed',1,5,'CN','','','2026-10-02',1,1),
(446,'demo-seed',1,5,'GB','','','2026-10-02',1,1),
(447,'demo-seed',1,5,'BR','','','2026-10-02',1,1),
(448,'demo-seed',1,5,'IR','','','2026-10-02',1,1),
(449,'demo-seed',1,5,'US','','','2026-10-03',2,1),
(450,'demo-seed',1,5,'IN','','','2026-10-03',2,1),
(451,'demo-seed',1,5,'CN','','','2026-10-03',1,1),
(452,'demo-seed',1,5,'GB','','','2026-10-03',1,1),
(453,'demo-seed',1,5,'DE','','','2026-10-03',1,1),
(454,'demo-seed',1,5,'IR','','','2026-10-03',1,1),
(455,'demo-seed',1,5,'PK','','','2026-10-03',1,1),
(456,'demo-seed',1,5,'US','','','2026-10-04',2,1),
(457,'demo-seed',1,5,'IN','','','2026-10-04',2,1),
(458,'demo-seed',1,5,'CN','','','2026-10-04',2,1),
(459,'demo-seed',1,5,'US','','','2026-10-05',1,1),
(460,'demo-seed',1,5,'IN','','','2026-10-05',1,1),
(461,'demo-seed',1,5,'CN','','','2026-10-05',1,1),
(462,'demo-seed',1,5,'US','','','2026-10-06',2,1),
(463,'demo-seed',1,5,'IN','','','2026-10-06',2,1),
(464,'demo-seed',1,5,'GB','','','2026-10-06',2,1),
(465,'demo-seed',1,6,'US','','','2026-09-07',2,1),
(466,'demo-seed',1,6,'IN','','','2026-09-07',1,1),
(467,'demo-seed',1,6,'CN','','','2026-09-07',1,1),
(468,'demo-seed',1,6,'US','','','2026-09-08',2,1),
(469,'demo-seed',1,6,'IN','','','2026-09-08',1,1),
(470,'demo-seed',1,6,'US','','','2026-09-09',1,1),
(471,'demo-seed',1,6,'IN','','','2026-09-09',1,1),
(472,'demo-seed',1,6,'US','','','2026-09-10',2,1),
(473,'demo-seed',1,6,'IN','','','2026-09-10',1,1),
(474,'demo-seed',1,6,'CN','','','2026-09-10',1,1),
(475,'demo-seed',1,6,'US','','','2026-09-11',1,1),
(476,'demo-seed',1,6,'IN','','','2026-09-11',1,1),
(477,'demo-seed',1,6,'US','','','2026-09-12',2,1),
(478,'demo-seed',1,6,'IN','','','2026-09-12',2,1),
(479,'demo-seed',1,6,'CN','','','2026-09-12',1,1),
(480,'demo-seed',1,6,'DE','','','2026-09-12',1,1),
(481,'demo-seed',1,6,'US','','','2026-09-13',2,1),
(482,'demo-seed',1,6,'IN','','','2026-09-13',1,1),
(483,'demo-seed',1,6,'US','','','2026-09-14',2,1),
(484,'demo-seed',1,6,'CN','','','2026-09-14',1,1),
(485,'demo-seed',1,6,'GB','','','2026-09-14',1,1),
(486,'demo-seed',1,6,'US','','','2026-09-15',2,1),
(487,'demo-seed',1,6,'GB','','','2026-09-15',1,1),
(488,'demo-seed',1,6,'US','','','2026-09-17',1,1),
(489,'demo-seed',1,6,'IN','','','2026-09-17',2,1),
(490,'demo-seed',1,6,'GB','','','2026-09-17',1,1),
(491,'demo-seed',1,6,'BR','','','2026-09-17',1,1),
(492,'demo-seed',1,6,'US','','','2026-09-18',1,1),
(493,'demo-seed',1,6,'IN','','','2026-09-18',2,1),
(494,'demo-seed',1,6,'GB','','','2026-09-18',1,1),
(495,'demo-seed',1,6,'DE','','','2026-09-18',1,1),
(496,'demo-seed',1,6,'US','','','2026-09-19',1,1),
(497,'demo-seed',1,6,'IN','','','2026-09-19',1,1),
(498,'demo-seed',1,6,'US','','','2026-09-20',1,1),
(499,'demo-seed',1,6,'IN','','','2026-09-20',1,1),
(500,'demo-seed',1,6,'CN','','','2026-09-20',1,1),
(501,'demo-seed',1,6,'US','','','2026-09-21',1,1),
(502,'demo-seed',1,6,'US','','','2026-09-22',1,1),
(503,'demo-seed',1,6,'US','','','2026-09-23',1,1),
(504,'demo-seed',1,6,'US','','','2026-09-24',3,1),
(505,'demo-seed',1,6,'IN','','','2026-09-24',2,1),
(506,'demo-seed',1,6,'CN','','','2026-09-24',1,1),
(507,'demo-seed',1,6,'GB','','','2026-09-24',1,1),
(508,'demo-seed',1,6,'BR','','','2026-09-24',1,1),
(509,'demo-seed',1,6,'IR','','','2026-09-24',1,1),
(510,'demo-seed',1,6,'GB','','','2026-09-25',1,1),
(511,'demo-seed',1,6,'US','','','2026-09-26',3,2),
(512,'demo-seed',1,6,'IN','','','2026-09-26',2,1),
(513,'demo-seed',1,6,'CN','','','2026-09-26',1,1),
(514,'demo-seed',1,6,'US','','','2026-09-27',2,1),
(515,'demo-seed',1,6,'DE','','','2026-09-27',1,1),
(516,'demo-seed',1,6,'BR','','','2026-09-27',1,1),
(517,'demo-seed',1,6,'US','','','2026-09-28',1,1),
(518,'demo-seed',1,6,'IN','','','2026-09-28',1,1),
(519,'demo-seed',1,6,'IN','','','2026-09-29',1,1),
(520,'demo-seed',1,6,'US','','','2026-09-30',1,1),
(521,'demo-seed',1,6,'IN','','','2026-09-30',2,1),
(522,'demo-seed',1,6,'CN','','','2026-09-30',1,1),
(523,'demo-seed',1,6,'GB','','','2026-09-30',1,1),
(524,'demo-seed',1,6,'BR','','','2026-09-30',1,1),
(525,'demo-seed',1,6,'US','','','2026-10-01',1,1),
(526,'demo-seed',1,6,'US','','','2026-10-02',2,1),
(527,'demo-seed',1,6,'IN','','','2026-10-02',1,1),
(528,'demo-seed',1,6,'GB','','','2026-10-02',1,1),
(529,'demo-seed',1,6,'DE','','','2026-10-02',1,1),
(530,'demo-seed',1,6,'US','','','2026-10-03',1,1),
(531,'demo-seed',1,6,'IN','','','2026-10-03',1,1),
(532,'demo-seed',1,6,'US','','','2026-10-04',1,1),
(533,'demo-seed',1,6,'IN','','','2026-10-04',1,1),
(534,'demo-seed',1,6,'US','','','2026-10-05',2,1),
(535,'demo-seed',1,6,'IN','','','2026-10-05',2,1),
(536,'demo-seed',1,6,'CN','','','2026-10-05',1,1),
(537,'demo-seed',1,6,'DE','','','2026-10-05',1,1),
(538,'demo-seed',1,6,'BR','','','2026-10-05',1,1),
(539,'demo-seed',1,6,'US','','','2026-10-06',2,1),
(540,'demo-seed',1,6,'IN','','','2026-10-06',2,1),
(541,'demo-seed',1,6,'CN','','','2026-10-06',1,1),
(542,'demo-seed',1,6,'BR','','','2026-10-06',1,1),
(543,'demo-seed',1,7,'US','','','2026-09-07',2,1),
(544,'demo-seed',1,7,'IN','','','2026-09-07',2,1),
(545,'demo-seed',1,7,'BR','','','2026-09-07',1,1),
(546,'demo-seed',1,7,'US','','','2026-09-08',3,1),
(547,'demo-seed',1,7,'IN','','','2026-09-08',1,1),
(548,'demo-seed',1,7,'GB','','','2026-09-08',1,1),
(549,'demo-seed',1,7,'IN','','','2026-09-09',2,1),
(550,'demo-seed',1,7,'US','','','2026-09-10',2,1),
(551,'demo-seed',1,7,'IN','','','2026-09-10',2,1),
(552,'demo-seed',1,7,'GB','','','2026-09-10',1,1),
(553,'demo-seed',1,7,'US','','','2026-09-11',2,1),
(554,'demo-seed',1,7,'IN','','','2026-09-11',1,1),
(555,'demo-seed',1,7,'CN','','','2026-09-11',1,1),
(556,'demo-seed',1,7,'US','','','2026-09-12',1,1),
(557,'demo-seed',1,7,'IN','','','2026-09-12',2,1),
(558,'demo-seed',1,7,'CN','','','2026-09-12',1,1),
(559,'demo-seed',1,7,'GB','','','2026-09-12',1,1),
(560,'demo-seed',1,7,'DE','','','2026-09-12',1,1),
(561,'demo-seed',1,7,'US','','','2026-09-13',2,1),
(562,'demo-seed',1,7,'IN','','','2026-09-13',1,1),
(563,'demo-seed',1,7,'US','','','2026-09-14',2,1),
(564,'demo-seed',1,7,'IN','','','2026-09-14',1,1),
(565,'demo-seed',1,7,'US','','','2026-09-15',1,1),
(566,'demo-seed',1,7,'IN','','','2026-09-15',2,1),
(567,'demo-seed',1,7,'CN','','','2026-09-15',1,1),
(568,'demo-seed',1,7,'GB','','','2026-09-15',1,1),
(569,'demo-seed',1,7,'US','','','2026-09-16',2,1),
(570,'demo-seed',1,7,'IN','','','2026-09-16',2,1),
(571,'demo-seed',1,7,'US','','','2026-09-17',2,1),
(572,'demo-seed',1,7,'US','','','2026-09-18',1,1),
(573,'demo-seed',1,7,'IN','','','2026-09-18',2,1),
(574,'demo-seed',1,7,'CN','','','2026-09-18',2,1),
(575,'demo-seed',1,7,'BR','','','2026-09-18',1,1),
(576,'demo-seed',1,7,'IR','','','2026-09-18',1,1),
(577,'demo-seed',1,7,'US','','','2026-09-20',1,1),
(578,'demo-seed',1,7,'IN','','','2026-09-20',2,1),
(579,'demo-seed',1,7,'US','','','2026-09-21',3,2),
(580,'demo-seed',1,7,'IN','','','2026-09-21',1,1),
(581,'demo-seed',1,7,'DE','','','2026-09-21',1,1),
(582,'demo-seed',1,7,'US','','','2026-09-22',2,1),
(583,'demo-seed',1,7,'US','','','2026-09-23',1,1),
(584,'demo-seed',1,7,'IN','','','2026-09-23',1,1),
(585,'demo-seed',1,7,'US','','','2026-09-24',2,1),
(586,'demo-seed',1,7,'IN','','','2026-09-24',2,1),
(587,'demo-seed',1,7,'CN','','','2026-09-24',1,1),
(588,'demo-seed',1,7,'GB','','','2026-09-24',1,1),
(589,'demo-seed',1,7,'DE','','','2026-09-24',1,1),
(590,'demo-seed',1,7,'US','','','2026-09-25',2,1),
(591,'demo-seed',1,7,'IN','','','2026-09-25',2,1),
(592,'demo-seed',1,7,'CN','','','2026-09-25',1,1),
(593,'demo-seed',1,7,'BR','','','2026-09-25',1,1),
(594,'demo-seed',1,7,'NG','','','2026-09-25',1,1),
(595,'demo-seed',1,7,'IR','','','2026-09-25',1,1),
(596,'demo-seed',1,7,'PK','','','2026-09-25',1,1),
(597,'demo-seed',1,7,'US','','','2026-09-26',2,1),
(598,'demo-seed',1,7,'IN','','','2026-09-26',2,1),
(599,'demo-seed',1,7,'CN','','','2026-09-26',1,1),
(600,'demo-seed',1,7,'GB','','','2026-09-26',1,1),
(601,'demo-seed',1,7,'IR','','','2026-09-26',1,1),
(602,'demo-seed',1,7,'US','','','2026-09-28',1,1),
(603,'demo-seed',1,7,'IN','','','2026-09-28',2,1),
(604,'demo-seed',1,7,'GB','','','2026-09-28',1,1),
(605,'demo-seed',1,7,'US','','','2026-09-29',1,1),
(606,'demo-seed',1,7,'US','','','2026-09-30',1,1),
(607,'demo-seed',1,7,'IN','','','2026-09-30',2,1),
(608,'demo-seed',1,7,'CN','','','2026-09-30',1,1),
(609,'demo-seed',1,7,'DE','','','2026-09-30',1,1),
(610,'demo-seed',1,7,'BR','','','2026-09-30',1,1),
(611,'demo-seed',1,7,'NG','','','2026-09-30',1,1),
(612,'demo-seed',1,7,'CN','','','2026-10-02',1,1),
(613,'demo-seed',1,7,'US','','','2026-10-03',1,1),
(614,'demo-seed',1,7,'IN','','','2026-10-03',2,1),
(615,'demo-seed',1,7,'CN','','','2026-10-03',1,1),
(616,'demo-seed',1,7,'BR','','','2026-10-03',1,1),
(617,'demo-seed',1,7,'US','','','2026-10-04',2,1),
(618,'demo-seed',1,7,'IN','','','2026-10-04',1,1),
(619,'demo-seed',1,7,'CN','','','2026-10-04',1,1),
(620,'demo-seed',1,7,'GB','','','2026-10-04',1,1),
(621,'demo-seed',1,7,'DE','','','2026-10-04',1,1),
(622,'demo-seed',1,7,'US','','','2026-10-05',3,1),
(623,'demo-seed',1,7,'IN','','','2026-10-05',2,1),
(624,'demo-seed',1,7,'GB','','','2026-10-05',1,1),
(625,'demo-seed',1,8,'US','','','2026-09-07',1,1),
(626,'demo-seed',1,8,'IN','','','2026-09-09',1,1),
(627,'demo-seed',1,8,'CN','','','2026-09-09',1,1),
(628,'demo-seed',1,8,'US','','','2026-09-10',2,1),
(629,'demo-seed',1,8,'IN','','','2026-09-10',2,1),
(630,'demo-seed',1,8,'US','','','2026-09-11',1,1),
(631,'demo-seed',1,8,'IN','','','2026-09-11',1,1),
(632,'demo-seed',1,8,'IN','','','2026-09-13',1,1),
(633,'demo-seed',1,8,'US','','','2026-09-15',1,1),
(634,'demo-seed',1,8,'IN','','','2026-09-15',1,1),
(635,'demo-seed',1,8,'CN','','','2026-09-15',1,1),
(636,'demo-seed',1,8,'US','','','2026-09-16',2,1),
(637,'demo-seed',1,8,'US','','','2026-09-18',1,1),
(638,'demo-seed',1,8,'IN','','','2026-09-18',1,1),
(639,'demo-seed',1,8,'US','','','2026-09-19',1,1),
(640,'demo-seed',1,8,'IN','','','2026-09-19',1,1),
(641,'demo-seed',1,8,'US','','','2026-09-20',1,1),
(642,'demo-seed',1,8,'IN','','','2026-09-20',1,1),
(643,'demo-seed',1,8,'IN','','','2026-09-21',1,1),
(644,'demo-seed',1,8,'CN','','','2026-09-21',1,1),
(645,'demo-seed',1,8,'US','','','2026-09-23',1,1),
(646,'demo-seed',1,8,'IN','','','2026-09-23',1,1),
(647,'demo-seed',1,8,'US','','','2026-09-24',1,1),
(648,'demo-seed',1,8,'IN','','','2026-09-24',1,1),
(649,'demo-seed',1,8,'IN','','','2026-09-25',1,1),
(650,'demo-seed',1,8,'IN','','','2026-09-27',1,1),
(651,'demo-seed',1,8,'CN','','','2026-09-27',1,1),
(652,'demo-seed',1,8,'GB','','','2026-09-27',1,1),
(653,'demo-seed',1,8,'IN','','','2026-09-28',1,1),
(654,'demo-seed',1,8,'US','','','2026-09-29',1,1),
(655,'demo-seed',1,8,'IN','','','2026-09-29',1,1),
(656,'demo-seed',1,8,'US','','','2026-09-30',1,1),
(657,'demo-seed',1,8,'IN','','','2026-09-30',1,1),
(658,'demo-seed',1,8,'US','','','2026-10-01',1,1),
(659,'demo-seed',1,8,'IN','','','2026-10-03',1,1),
(660,'demo-seed',1,8,'US','','','2026-10-04',1,1),
(661,'demo-seed',1,8,'US','','','2026-10-06',1,1);
/*!40000 ALTER TABLE `metrics_submission_geo_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_submission_geo_monthly`
--

DROP TABLE IF EXISTS `metrics_submission_geo_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_submission_geo_monthly` (
  `metrics_submission_geo_monthly_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `month` int(11) NOT NULL,
  `metric` int(11) NOT NULL,
  `metric_unique` int(11) NOT NULL,
  PRIMARY KEY (`metrics_submission_geo_monthly_id`),
  UNIQUE KEY `msgm_uc_context_submission_c_r_c_month` (`context_id`,`submission_id`,`country`,`region`,`city`(80),`month`),
  KEY `metrics_submission_geo_monthly_context_id` (`context_id`),
  KEY `metrics_submission_geo_monthly_submission_id` (`submission_id`),
  KEY `msgm_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msgm_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msgm_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4096 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Monthly statistics by country, region and city for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_submission_geo_monthly`
--

LOCK TABLES `metrics_submission_geo_monthly` WRITE;
/*!40000 ALTER TABLE `metrics_submission_geo_monthly` DISABLE KEYS */;
INSERT INTO `metrics_submission_geo_monthly` VALUES
(1,1,1,'US','','',202509,18,10),
(2,1,1,'IN','','',202509,15,9),
(3,1,1,'CN','','',202509,13,7),
(4,1,1,'GB','','',202509,14,8),
(5,1,1,'DE','','',202509,5,3),
(6,1,1,'BR','','',202509,10,6),
(7,1,1,'NG','','',202509,5,3),
(8,1,1,'IR','','',202509,5,3),
(9,1,1,'PK','','',202509,5,3),
(10,1,1,'EG','','',202509,4,2),
(11,1,1,'ET','','',202509,5,3),
(12,1,1,'KE','','',202509,5,3),
(13,1,1,'TR','','',202509,3,2),
(14,1,1,'FR','','',202509,4,2),
(15,1,1,'IT','','',202509,7,4),
(16,1,1,'AU','','',202509,3,2),
(17,1,1,'CA','','',202509,3,2),
(18,1,1,'ID','','',202509,4,2),
(19,1,1,'ES','','',202509,4,2),
(20,1,1,'BD','','',202509,3,2),
(21,1,1,'MX','','',202509,4,2),
(22,1,1,'ZA','','',202509,3,1),
(23,1,1,'NL','','',202509,2,1),
(24,1,1,'JP','','',202509,4,2),
(25,1,1,'SA','','',202509,3,2),
(26,1,1,'MY','','',202509,2,1),
(27,1,1,'PL','','',202509,1,1),
(28,1,1,'GH','','',202509,2,1),
(29,1,1,'VN','','',202509,2,1),
(30,1,1,'AR','','',202509,1,1),
(31,1,1,'NZ','','',202509,1,1),
(32,1,1,'SE','','',202509,2,1),
(33,1,1,'US','','',202510,11,7),
(34,1,1,'IN','','',202510,12,7),
(35,1,1,'CN','','',202510,10,6),
(36,1,1,'GB','','',202510,6,3),
(37,1,1,'DE','','',202510,8,5),
(38,1,1,'BR','','',202510,3,2),
(39,1,1,'NG','','',202510,7,4),
(40,1,1,'IR','','',202510,4,2),
(41,1,1,'PK','','',202510,4,3),
(42,1,1,'EG','','',202510,3,2),
(43,1,1,'ET','','',202510,3,2),
(44,1,1,'KE','','',202510,2,1),
(45,1,1,'TR','','',202510,3,2),
(46,1,1,'FR','','',202510,2,1),
(47,1,1,'IT','','',202510,4,2),
(48,1,1,'AU','','',202510,2,1),
(49,1,1,'CA','','',202510,4,2),
(50,1,1,'ID','','',202510,2,1),
(51,1,1,'ES','','',202510,2,1),
(52,1,1,'BD','','',202510,2,1),
(53,1,1,'MX','','',202510,1,1),
(54,1,1,'ZA','','',202510,3,2),
(55,1,1,'NL','','',202510,2,1),
(56,1,1,'JP','','',202510,2,1),
(57,1,1,'SA','','',202510,3,2),
(58,1,1,'MY','','',202510,1,1),
(59,1,1,'PL','','',202510,1,1),
(60,1,1,'AR','','',202510,1,1),
(61,1,1,'NZ','','',202510,1,1),
(62,1,1,'SE','','',202510,1,1),
(63,1,1,'US','','',202511,25,15),
(64,1,1,'IN','','',202511,11,6),
(65,1,1,'CN','','',202511,8,5),
(66,1,1,'GB','','',202511,6,4),
(67,1,1,'DE','','',202511,7,4),
(68,1,1,'BR','','',202511,10,6),
(69,1,1,'NG','','',202511,5,3),
(70,1,1,'IR','','',202511,4,2),
(71,1,1,'PK','','',202511,7,4),
(72,1,1,'EG','','',202511,6,4),
(73,1,1,'ET','','',202511,3,2),
(74,1,1,'KE','','',202511,4,2),
(75,1,1,'TR','','',202511,5,3),
(76,1,1,'FR','','',202511,6,4),
(77,1,1,'IT','','',202511,6,3),
(78,1,1,'AU','','',202511,6,3),
(79,1,1,'CA','','',202511,4,2),
(80,1,1,'ID','','',202511,5,3),
(81,1,1,'ES','','',202511,3,2),
(82,1,1,'BD','','',202511,3,2),
(83,1,1,'MX','','',202511,3,2),
(84,1,1,'ZA','','',202511,4,2),
(85,1,1,'NL','','',202511,3,2),
(86,1,1,'JP','','',202511,1,1),
(87,1,1,'SA','','',202511,4,2),
(88,1,1,'MY','','',202511,3,2),
(89,1,1,'PL','','',202511,1,1),
(90,1,1,'GH','','',202511,2,1),
(91,1,1,'VN','','',202511,1,1),
(92,1,1,'AR','','',202511,2,1),
(93,1,1,'NZ','','',202511,2,1),
(94,1,1,'SE','','',202511,2,1),
(95,1,1,'US','','',202512,24,16),
(96,1,1,'IN','','',202512,9,6),
(97,1,1,'CN','','',202512,6,4),
(98,1,1,'GB','','',202512,10,7),
(99,1,1,'DE','','',202512,8,5),
(100,1,1,'BR','','',202512,6,4),
(101,1,1,'NG','','',202512,4,3),
(102,1,1,'IR','','',202512,3,2),
(103,1,1,'PK','','',202512,8,5),
(104,1,1,'EG','','',202512,5,4),
(105,1,1,'ET','','',202512,4,3),
(106,1,1,'KE','','',202512,2,2),
(107,1,1,'TR','','',202512,5,3),
(108,1,1,'FR','','',202512,4,3),
(109,1,1,'IT','','',202512,5,3),
(110,1,1,'AU','','',202512,6,4),
(111,1,1,'CA','','',202512,3,2),
(112,1,1,'ID','','',202512,6,4),
(113,1,1,'ES','','',202512,3,2),
(114,1,1,'BD','','',202512,2,1),
(115,1,1,'MX','','',202512,3,2),
(116,1,1,'ZA','','',202512,4,3),
(117,1,1,'NL','','',202512,2,1),
(118,1,1,'JP','','',202512,2,1),
(119,1,1,'SA','','',202512,2,1),
(120,1,1,'MY','','',202512,4,2),
(121,1,1,'PL','','',202512,2,1),
(122,1,1,'VN','','',202512,1,1),
(123,1,1,'AR','','',202512,2,1),
(124,1,1,'NZ','','',202512,1,1),
(125,1,1,'SE','','',202512,2,1),
(126,1,1,'US','','',202601,26,13),
(127,1,1,'IN','','',202601,26,13),
(128,1,1,'CN','','',202601,18,9),
(129,1,1,'GB','','',202601,14,7),
(130,1,1,'DE','','',202601,8,4),
(131,1,1,'BR','','',202601,9,4),
(132,1,1,'NG','','',202601,9,4),
(133,1,1,'IR','','',202601,10,5),
(134,1,1,'PK','','',202601,10,5),
(135,1,1,'EG','','',202601,7,4),
(136,1,1,'ET','','',202601,5,3),
(137,1,1,'KE','','',202601,7,3),
(138,1,1,'TR','','',202601,3,1),
(139,1,1,'FR','','',202601,4,2),
(140,1,1,'IT','','',202601,5,2),
(141,1,1,'AU','','',202601,5,2),
(142,1,1,'CA','','',202601,3,1),
(143,1,1,'ID','','',202601,3,2),
(144,1,1,'ES','','',202601,3,2),
(145,1,1,'BD','','',202601,4,2),
(146,1,1,'MX','','',202601,2,1),
(147,1,1,'ZA','','',202601,3,1),
(148,1,1,'NL','','',202601,4,2),
(149,1,1,'JP','','',202601,3,1),
(150,1,1,'SA','','',202601,3,1),
(151,1,1,'MY','','',202601,4,2),
(152,1,1,'PL','','',202601,2,1),
(153,1,1,'VN','','',202601,2,1),
(154,1,1,'AR','','',202601,2,1),
(155,1,1,'NZ','','',202601,2,1),
(156,1,1,'SE','','',202601,1,1),
(157,1,1,'US','','',202602,20,11),
(158,1,1,'IN','','',202602,30,17),
(159,1,1,'CN','','',202602,16,9),
(160,1,1,'GB','','',202602,14,8),
(161,1,1,'DE','','',202602,16,9),
(162,1,1,'BR','','',202602,12,7),
(163,1,1,'NG','','',202602,16,9),
(164,1,1,'IR','','',202602,6,3),
(165,1,1,'PK','','',202602,10,6),
(166,1,1,'EG','','',202602,12,7),
(167,1,1,'ET','','',202602,5,3),
(168,1,1,'KE','','',202602,5,3),
(169,1,1,'TR','','',202602,7,4),
(170,1,1,'FR','','',202602,4,3),
(171,1,1,'IT','','',202602,4,2),
(172,1,1,'AU','','',202602,6,4),
(173,1,1,'CA','','',202602,10,6),
(174,1,1,'ID','','',202602,4,3),
(175,1,1,'ES','','',202602,6,3),
(176,1,1,'BD','','',202602,5,3),
(177,1,1,'MX','','',202602,6,3),
(178,1,1,'ZA','','',202602,6,4),
(179,1,1,'NL','','',202602,6,3),
(180,1,1,'JP','','',202602,6,3),
(181,1,1,'SA','','',202602,4,2),
(182,1,1,'MY','','',202602,4,2),
(183,1,1,'PL','','',202602,1,1),
(184,1,1,'GH','','',202602,3,1),
(185,1,1,'VN','','',202602,2,1),
(186,1,1,'AR','','',202602,3,2),
(187,1,1,'NZ','','',202602,2,1),
(188,1,1,'SE','','',202602,2,1),
(189,1,1,'US','','',202603,32,15),
(190,1,1,'IN','','',202603,25,12),
(191,1,1,'CN','','',202603,7,3),
(192,1,1,'GB','','',202603,9,4),
(193,1,1,'DE','','',202603,7,3),
(194,1,1,'BR','','',202603,12,6),
(195,1,1,'NG','','',202603,7,3),
(196,1,1,'IR','','',202603,9,4),
(197,1,1,'PK','','',202603,8,4),
(198,1,1,'EG','','',202603,7,3),
(199,1,1,'ET','','',202603,6,3),
(200,1,1,'KE','','',202603,3,1),
(201,1,1,'TR','','',202603,3,1),
(202,1,1,'FR','','',202603,4,2),
(203,1,1,'IT','','',202603,7,3),
(204,1,1,'AU','','',202603,6,3),
(205,1,1,'CA','','',202603,6,3),
(206,1,1,'ID','','',202603,5,2),
(207,1,1,'ES','','',202603,2,1),
(208,1,1,'BD','','',202603,3,2),
(209,1,1,'MX','','',202603,3,1),
(210,1,1,'ZA','','',202603,2,1),
(211,1,1,'NL','','',202603,4,2),
(212,1,1,'JP','','',202603,3,2),
(213,1,1,'SA','','',202603,5,2),
(214,1,1,'MY','','',202603,3,1),
(215,1,1,'PL','','',202603,1,1),
(216,1,1,'GH','','',202603,1,1),
(217,1,1,'VN','','',202603,1,1),
(218,1,1,'AR','','',202603,2,1),
(219,1,1,'NZ','','',202603,2,1),
(220,1,1,'US','','',202604,22,9),
(221,1,1,'IN','','',202604,28,12),
(222,1,1,'CN','','',202604,19,8),
(223,1,1,'GB','','',202604,16,7),
(224,1,1,'DE','','',202604,6,3),
(225,1,1,'BR','','',202604,11,5),
(226,1,1,'NG','','',202604,10,4),
(227,1,1,'IR','','',202604,6,2),
(228,1,1,'PK','','',202604,10,4),
(229,1,1,'EG','','',202604,7,3),
(230,1,1,'ET','','',202604,4,1),
(231,1,1,'KE','','',202604,6,2),
(232,1,1,'TR','','',202604,4,2),
(233,1,1,'FR','','',202604,6,2),
(234,1,1,'IT','','',202604,5,2),
(235,1,1,'AU','','',202604,5,2),
(236,1,1,'CA','','',202604,6,2),
(237,1,1,'ID','','',202604,5,2),
(238,1,1,'ES','','',202604,2,1),
(239,1,1,'BD','','',202604,2,1),
(240,1,1,'MX','','',202604,3,1),
(241,1,1,'ZA','','',202604,2,1),
(242,1,1,'NL','','',202604,5,2),
(243,1,1,'JP','','',202604,4,2),
(244,1,1,'SA','','',202604,4,2),
(245,1,1,'MY','','',202604,2,1),
(246,1,1,'GH','','',202604,2,1),
(247,1,1,'AR','','',202604,2,1),
(248,1,1,'NZ','','',202604,2,1),
(249,1,1,'SE','','',202604,2,1),
(250,1,1,'US','','',202605,32,22),
(251,1,1,'IN','','',202605,32,22),
(252,1,1,'CN','','',202605,23,16),
(253,1,1,'GB','','',202605,9,6),
(254,1,1,'DE','','',202605,20,14),
(255,1,1,'BR','','',202605,10,7),
(256,1,1,'NG','','',202605,17,12),
(257,1,1,'IR','','',202605,8,6),
(258,1,1,'PK','','',202605,10,7),
(259,1,1,'EG','','',202605,5,3),
(260,1,1,'ET','','',202605,8,6),
(261,1,1,'KE','','',202605,4,3),
(262,1,1,'TR','','',202605,4,3),
(263,1,1,'FR','','',202605,10,7),
(264,1,1,'IT','','',202605,8,5),
(265,1,1,'AU','','',202605,10,7),
(266,1,1,'CA','','',202605,10,7),
(267,1,1,'ID','','',202605,9,6),
(268,1,1,'ES','','',202605,4,3),
(269,1,1,'BD','','',202605,5,3),
(270,1,1,'MX','','',202605,3,2),
(271,1,1,'ZA','','',202605,6,4),
(272,1,1,'NL','','',202605,6,4),
(273,1,1,'JP','','',202605,5,3),
(274,1,1,'SA','','',202605,3,2),
(275,1,1,'MY','','',202605,4,3),
(276,1,1,'PL','','',202605,3,2),
(277,1,1,'GH','','',202605,2,2),
(278,1,1,'VN','','',202605,3,2),
(279,1,1,'AR','','',202605,2,1),
(280,1,1,'NZ','','',202605,3,2),
(281,1,1,'SE','','',202605,2,1),
(282,1,1,'US','','',202606,29,14),
(283,1,1,'IN','','',202606,28,14),
(284,1,1,'CN','','',202606,16,8),
(285,1,1,'GB','','',202606,17,8),
(286,1,1,'DE','','',202606,17,8),
(287,1,1,'BR','','',202606,16,8),
(288,1,1,'NG','','',202606,14,7),
(289,1,1,'IR','','',202606,11,5),
(290,1,1,'PK','','',202606,6,3),
(291,1,1,'EG','','',202606,6,3),
(292,1,1,'ET','','',202606,4,2),
(293,1,1,'KE','','',202606,9,4),
(294,1,1,'TR','','',202606,6,3),
(295,1,1,'FR','','',202606,6,3),
(296,1,1,'IT','','',202606,6,3),
(297,1,1,'AU','','',202606,9,4),
(298,1,1,'CA','','',202606,4,2),
(299,1,1,'ID','','',202606,3,2),
(300,1,1,'ES','','',202606,5,2),
(301,1,1,'BD','','',202606,6,3),
(302,1,1,'MX','','',202606,5,2),
(303,1,1,'ZA','','',202606,3,2),
(304,1,1,'NL','','',202606,3,2),
(305,1,1,'JP','','',202606,5,3),
(306,1,1,'SA','','',202606,2,1),
(307,1,1,'MY','','',202606,4,2),
(308,1,1,'PL','','',202606,3,1),
(309,1,1,'GH','','',202606,2,1),
(310,1,1,'VN','','',202606,2,1),
(311,1,1,'AR','','',202606,2,1),
(312,1,1,'NZ','','',202606,3,1),
(313,1,1,'SE','','',202606,3,1),
(314,1,1,'US','','',202607,19,11),
(315,1,1,'IN','','',202607,16,9),
(316,1,1,'CN','','',202607,10,6),
(317,1,1,'GB','','',202607,11,6),
(318,1,1,'DE','','',202607,10,6),
(319,1,1,'BR','','',202607,12,7),
(320,1,1,'NG','','',202607,10,6),
(321,1,1,'IR','','',202607,14,8),
(322,1,1,'PK','','',202607,4,2),
(323,1,1,'EG','','',202607,9,5),
(324,1,1,'ET','','',202607,3,2),
(325,1,1,'KE','','',202607,4,2),
(326,1,1,'TR','','',202607,8,4),
(327,1,1,'FR','','',202607,4,2),
(328,1,1,'IT','','',202607,5,3),
(329,1,1,'AU','','',202607,5,3),
(330,1,1,'CA','','',202607,8,5),
(331,1,1,'ID','','',202607,5,3),
(332,1,1,'ES','','',202607,4,3),
(333,1,1,'BD','','',202607,3,2),
(334,1,1,'MX','','',202607,4,2),
(335,1,1,'ZA','','',202607,6,3),
(336,1,1,'NL','','',202607,4,2),
(337,1,1,'JP','','',202607,5,3),
(338,1,1,'SA','','',202607,4,2),
(339,1,1,'MY','','',202607,2,1),
(340,1,1,'PL','','',202607,2,1),
(341,1,1,'GH','','',202607,2,1),
(342,1,1,'VN','','',202607,2,1),
(343,1,1,'AR','','',202607,2,1),
(344,1,1,'NZ','','',202607,2,1),
(345,1,1,'SE','','',202607,2,1),
(346,1,1,'US','','',202608,37,20),
(347,1,1,'IN','','',202608,26,14),
(348,1,1,'CN','','',202608,34,18),
(349,1,1,'GB','','',202608,21,12),
(350,1,1,'DE','','',202608,30,16),
(351,1,1,'BR','','',202608,19,10),
(352,1,1,'NG','','',202608,16,9),
(353,1,1,'IR','','',202608,13,7),
(354,1,1,'PK','','',202608,16,9),
(355,1,1,'EG','','',202608,13,7),
(356,1,1,'ET','','',202608,11,6),
(357,1,1,'KE','','',202608,7,4),
(358,1,1,'TR','','',202608,10,5),
(359,1,1,'FR','','',202608,6,3),
(360,1,1,'IT','','',202608,7,4),
(361,1,1,'AU','','',202608,15,8),
(362,1,1,'CA','','',202608,15,8),
(363,1,1,'ID','','',202608,8,5),
(364,1,1,'ES','','',202608,10,6),
(365,1,1,'BD','','',202608,9,5),
(366,1,1,'MX','','',202608,5,3),
(367,1,1,'ZA','','',202608,9,5),
(368,1,1,'NL','','',202608,8,4),
(369,1,1,'JP','','',202608,9,5),
(370,1,1,'SA','','',202608,8,5),
(371,1,1,'MY','','',202608,6,3),
(372,1,1,'PL','','',202608,3,2),
(373,1,1,'GH','','',202608,4,2),
(374,1,1,'VN','','',202608,4,2),
(375,1,1,'AR','','',202608,4,2),
(376,1,1,'NZ','','',202608,3,2),
(377,1,1,'SE','','',202608,4,2),
(378,1,1,'US','','',202609,30,16),
(379,1,1,'IN','','',202609,40,22),
(380,1,1,'CN','','',202609,27,15),
(381,1,1,'GB','','',202609,15,8),
(382,1,1,'DE','','',202609,20,11),
(383,1,1,'BR','','',202609,10,5),
(384,1,1,'NG','','',202609,15,8),
(385,1,1,'IR','','',202609,16,9),
(386,1,1,'PK','','',202609,8,4),
(387,1,1,'EG','','',202609,10,6),
(388,1,1,'ET','','',202609,10,6),
(389,1,1,'KE','','',202609,6,4),
(390,1,1,'TR','','',202609,8,4),
(391,1,1,'FR','','',202609,6,3),
(392,1,1,'IT','','',202609,6,3),
(393,1,1,'AU','','',202609,5,3),
(394,1,1,'CA','','',202609,8,4),
(395,1,1,'ID','','',202609,7,4),
(396,1,1,'ES','','',202609,3,2),
(397,1,1,'BD','','',202609,4,2),
(398,1,1,'MX','','',202609,5,3),
(399,1,1,'ZA','','',202609,3,2),
(400,1,1,'NL','','',202609,6,3),
(401,1,1,'JP','','',202609,5,3),
(402,1,1,'SA','','',202609,4,2),
(403,1,1,'MY','','',202609,4,2),
(404,1,1,'PL','','',202609,3,2),
(405,1,1,'GH','','',202609,1,1),
(406,1,1,'VN','','',202609,2,1),
(407,1,1,'AR','','',202609,2,1),
(408,1,1,'NZ','','',202609,2,1),
(409,1,1,'SE','','',202609,3,2),
(410,1,1,'US','','',202610,8,4),
(411,1,1,'IN','','',202610,5,3),
(412,1,1,'CN','','',202610,5,3),
(413,1,1,'GB','','',202610,4,3),
(414,1,1,'DE','','',202610,2,1),
(415,1,1,'BR','','',202610,4,2),
(416,1,1,'NG','','',202610,2,1),
(417,1,1,'IR','','',202610,3,2),
(418,1,1,'PK','','',202610,3,2),
(419,1,1,'EG','','',202610,2,1),
(420,1,1,'ET','','',202610,3,1),
(421,1,1,'KE','','',202610,1,1),
(422,1,1,'TR','','',202610,2,1),
(423,1,1,'FR','','',202610,2,1),
(424,1,1,'IT','','',202610,1,1),
(425,1,1,'AU','','',202610,2,1),
(426,1,1,'CA','','',202610,1,1),
(427,1,1,'ID','','',202610,2,1),
(428,1,1,'BD','','',202610,2,1),
(429,1,1,'MX','','',202610,1,1),
(430,1,1,'ZA','','',202610,2,1),
(431,1,1,'NL','','',202610,2,1),
(432,1,1,'JP','','',202610,1,1),
(433,1,1,'SA','','',202610,2,1),
(434,1,1,'MY','','',202610,1,1),
(435,1,2,'US','','',202509,5,3),
(436,1,2,'IN','','',202509,10,5),
(437,1,2,'CN','','',202509,6,3),
(438,1,2,'GB','','',202509,5,3),
(439,1,2,'DE','','',202509,3,1),
(440,1,2,'BR','','',202509,4,2),
(441,1,2,'NG','','',202509,3,2),
(442,1,2,'IR','','',202509,4,2),
(443,1,2,'PK','','',202509,2,1),
(444,1,2,'EG','','',202509,3,2),
(445,1,2,'ET','','',202509,3,2),
(446,1,2,'KE','','',202509,2,1),
(447,1,2,'TR','','',202509,2,1),
(448,1,2,'FR','','',202509,1,1),
(449,1,2,'IT','','',202509,2,1),
(450,1,2,'AU','','',202509,2,1),
(451,1,2,'CA','','',202509,3,2),
(452,1,2,'ID','','',202509,3,2),
(453,1,2,'ES','','',202509,1,1),
(454,1,2,'MX','','',202509,1,1),
(455,1,2,'ZA','','',202509,1,1),
(456,1,2,'NL','','',202509,2,1),
(457,1,2,'JP','','',202509,1,1),
(458,1,2,'MY','','',202509,1,1),
(459,1,2,'NZ','','',202509,1,1),
(460,1,2,'US','','',202510,24,13),
(461,1,2,'IN','','',202510,24,13),
(462,1,2,'CN','','',202510,17,9),
(463,1,2,'GB','','',202510,8,4),
(464,1,2,'DE','','',202510,13,7),
(465,1,2,'BR','','',202510,13,7),
(466,1,2,'NG','','',202510,6,3),
(467,1,2,'IR','','',202510,8,4),
(468,1,2,'PK','','',202510,3,2),
(469,1,2,'EG','','',202510,7,4),
(470,1,2,'ET','','',202510,6,3),
(471,1,2,'KE','','',202510,6,3),
(472,1,2,'TR','','',202510,6,3),
(473,1,2,'FR','','',202510,4,2),
(474,1,2,'IT','','',202510,3,2),
(475,1,2,'AU','','',202510,3,2),
(476,1,2,'CA','','',202510,4,2),
(477,1,2,'ID','','',202510,4,2),
(478,1,2,'ES','','',202510,3,2),
(479,1,2,'BD','','',202510,4,2),
(480,1,2,'MX','','',202510,4,2),
(481,1,2,'ZA','','',202510,5,2),
(482,1,2,'NL','','',202510,4,2),
(483,1,2,'JP','','',202510,3,1),
(484,1,2,'SA','','',202510,4,2),
(485,1,2,'MY','','',202510,2,1),
(486,1,2,'PL','','',202510,2,1),
(487,1,2,'GH','','',202510,2,1),
(488,1,2,'AR','','',202510,2,1),
(489,1,2,'NZ','','',202510,2,1),
(490,1,2,'SE','','',202510,2,1),
(491,1,2,'US','','',202511,24,17),
(492,1,2,'IN','','',202511,11,7),
(493,1,2,'CN','','',202511,10,7),
(494,1,2,'GB','','',202511,8,6),
(495,1,2,'DE','','',202511,10,7),
(496,1,2,'BR','','',202511,9,7),
(497,1,2,'NG','','',202511,4,3),
(498,1,2,'IR','','',202511,7,5),
(499,1,2,'PK','','',202511,7,5),
(500,1,2,'EG','','',202511,7,5),
(501,1,2,'ET','','',202511,5,4),
(502,1,2,'KE','','',202511,5,4),
(503,1,2,'TR','','',202511,6,4),
(504,1,2,'FR','','',202511,4,3),
(505,1,2,'IT','','',202511,6,4),
(506,1,2,'AU','','',202511,5,3),
(507,1,2,'CA','','',202511,2,2),
(508,1,2,'ID','','',202511,3,2),
(509,1,2,'ES','','',202511,4,3),
(510,1,2,'BD','','',202511,3,2),
(511,1,2,'MX','','',202511,2,2),
(512,1,2,'ZA','','',202511,3,2),
(513,1,2,'NL','','',202511,4,3),
(514,1,2,'JP','','',202511,3,2),
(515,1,2,'SA','','',202511,3,2),
(516,1,2,'MY','','',202511,3,2),
(517,1,2,'PL','','',202511,2,1),
(518,1,2,'GH','','',202511,1,1),
(519,1,2,'VN','','',202511,2,1),
(520,1,2,'AR','','',202511,1,1),
(521,1,2,'NZ','','',202511,1,1),
(522,1,2,'SE','','',202511,1,1),
(523,1,2,'US','','',202512,11,6),
(524,1,2,'IN','','',202512,21,12),
(525,1,2,'CN','','',202512,13,7),
(526,1,2,'GB','','',202512,14,8),
(527,1,2,'DE','','',202512,11,6),
(528,1,2,'BR','','',202512,6,3),
(529,1,2,'NG','','',202512,4,2),
(530,1,2,'IR','','',202512,10,6),
(531,1,2,'PK','','',202512,7,4),
(532,1,2,'EG','','',202512,9,5),
(533,1,2,'ET','','',202512,3,2),
(534,1,2,'KE','','',202512,4,2),
(535,1,2,'TR','','',202512,3,2),
(536,1,2,'FR','','',202512,4,2),
(537,1,2,'IT','','',202512,5,3),
(538,1,2,'AU','','',202512,6,4),
(539,1,2,'CA','','',202512,5,3),
(540,1,2,'ID','','',202512,3,2),
(541,1,2,'ES','','',202512,4,2),
(542,1,2,'BD','','',202512,3,1),
(543,1,2,'MX','','',202512,4,2),
(544,1,2,'ZA','','',202512,4,2),
(545,1,2,'NL','','',202512,2,1),
(546,1,2,'JP','','',202512,2,1),
(547,1,2,'SA','','',202512,2,1),
(548,1,2,'MY','','',202512,2,1),
(549,1,2,'PL','','',202512,2,1),
(550,1,2,'GH','','',202512,1,1),
(551,1,2,'VN','','',202512,1,1),
(552,1,2,'AR','','',202512,1,1),
(553,1,2,'NZ','','',202512,1,1),
(554,1,2,'SE','','',202512,1,1),
(555,1,2,'US','','',202601,14,9),
(556,1,2,'IN','','',202601,20,12),
(557,1,2,'CN','','',202601,9,5),
(558,1,2,'GB','','',202601,18,11),
(559,1,2,'DE','','',202601,11,7),
(560,1,2,'BR','','',202601,10,6),
(561,1,2,'NG','','',202601,10,6),
(562,1,2,'IR','','',202601,9,5),
(563,1,2,'PK','','',202601,9,5),
(564,1,2,'EG','','',202601,4,2),
(565,1,2,'ET','','',202601,8,5),
(566,1,2,'KE','','',202601,8,5),
(567,1,2,'TR','','',202601,6,3),
(568,1,2,'FR','','',202601,5,3),
(569,1,2,'IT','','',202601,6,4),
(570,1,2,'AU','','',202601,5,3),
(571,1,2,'CA','','',202601,6,3),
(572,1,2,'ID','','',202601,4,2),
(573,1,2,'ES','','',202601,2,1),
(574,1,2,'BD','','',202601,2,1),
(575,1,2,'MX','','',202601,4,2),
(576,1,2,'ZA','','',202601,3,2),
(577,1,2,'NL','','',202601,5,3),
(578,1,2,'JP','','',202601,4,2),
(579,1,2,'SA','','',202601,3,2),
(580,1,2,'MY','','',202601,5,3),
(581,1,2,'PL','','',202601,2,1),
(582,1,2,'GH','','',202601,1,1),
(583,1,2,'VN','','',202601,2,1),
(584,1,2,'AR','','',202601,1,1),
(585,1,2,'NZ','','',202601,2,1),
(586,1,2,'SE','','',202601,1,1),
(587,1,2,'US','','',202602,12,6),
(588,1,2,'IN','','',202602,11,6),
(589,1,2,'CN','','',202602,10,5),
(590,1,2,'GB','','',202602,8,4),
(591,1,2,'DE','','',202602,9,4),
(592,1,2,'BR','','',202602,6,3),
(593,1,2,'NG','','',202602,8,4),
(594,1,2,'IR','','',202602,6,3),
(595,1,2,'PK','','',202602,6,3),
(596,1,2,'EG','','',202602,3,1),
(597,1,2,'ET','','',202602,4,2),
(598,1,2,'KE','','',202602,4,2),
(599,1,2,'TR','','',202602,4,2),
(600,1,2,'FR','','',202602,4,2),
(601,1,2,'IT','','',202602,2,1),
(602,1,2,'AU','','',202602,3,2),
(603,1,2,'CA','','',202602,3,2),
(604,1,2,'ID','','',202602,3,2),
(605,1,2,'ES','','',202602,1,1),
(606,1,2,'BD','','',202602,2,1),
(607,1,2,'MX','','',202602,2,1),
(608,1,2,'ZA','','',202602,2,1),
(609,1,2,'NL','','',202602,2,1),
(610,1,2,'JP','','',202602,2,1),
(611,1,2,'SA','','',202602,3,1),
(612,1,2,'MY','','',202602,2,1),
(613,1,2,'PL','','',202602,1,1),
(614,1,2,'GH','','',202602,1,1),
(615,1,2,'VN','','',202602,1,1),
(616,1,2,'US','','',202603,20,12),
(617,1,2,'IN','','',202603,22,13),
(618,1,2,'CN','','',202603,12,7),
(619,1,2,'GB','','',202603,14,8),
(620,1,2,'DE','','',202603,12,7),
(621,1,2,'BR','','',202603,15,9),
(622,1,2,'NG','','',202603,14,8),
(623,1,2,'IR','','',202603,12,7),
(624,1,2,'PK','','',202603,13,8),
(625,1,2,'EG','','',202603,9,5),
(626,1,2,'ET','','',202603,9,6),
(627,1,2,'KE','','',202603,9,5),
(628,1,2,'TR','','',202603,5,3),
(629,1,2,'FR','','',202603,8,5),
(630,1,2,'IT','','',202603,4,2),
(631,1,2,'AU','','',202603,6,4),
(632,1,2,'CA','','',202603,9,5),
(633,1,2,'ID','','',202603,9,5),
(634,1,2,'ES','','',202603,2,1),
(635,1,2,'BD','','',202603,6,3),
(636,1,2,'MX','','',202603,2,1),
(637,1,2,'ZA','','',202603,2,1),
(638,1,2,'NL','','',202603,3,2),
(639,1,2,'JP','','',202603,3,2),
(640,1,2,'SA','','',202603,6,4),
(641,1,2,'MY','','',202603,6,3),
(642,1,2,'PL','','',202603,3,2),
(643,1,2,'GH','','',202603,1,1),
(644,1,2,'VN','','',202603,2,1),
(645,1,2,'AR','','',202603,2,1),
(646,1,2,'NZ','','',202603,2,1),
(647,1,2,'SE','','',202603,1,1),
(648,1,2,'US','','',202604,14,7),
(649,1,2,'IN','','',202604,23,11),
(650,1,2,'CN','','',202604,19,9),
(651,1,2,'GB','','',202604,13,6),
(652,1,2,'DE','','',202604,13,7),
(653,1,2,'BR','','',202604,6,3),
(654,1,2,'NG','','',202604,11,6),
(655,1,2,'IR','','',202604,14,7),
(656,1,2,'PK','','',202604,11,6),
(657,1,2,'EG','','',202604,5,2),
(658,1,2,'ET','','',202604,3,2),
(659,1,2,'KE','','',202604,8,4),
(660,1,2,'TR','','',202604,8,4),
(661,1,2,'FR','','',202604,6,3),
(662,1,2,'IT','','',202604,4,2),
(663,1,2,'AU','','',202604,9,4),
(664,1,2,'CA','','',202604,8,4),
(665,1,2,'ID','','',202604,4,2),
(666,1,2,'ES','','',202604,5,3),
(667,1,2,'BD','','',202604,5,2),
(668,1,2,'MX','','',202604,4,2),
(669,1,2,'ZA','','',202604,4,2),
(670,1,2,'NL','','',202604,5,3),
(671,1,2,'JP','','',202604,6,3),
(672,1,2,'SA','','',202604,6,3),
(673,1,2,'MY','','',202604,5,2),
(674,1,2,'PL','','',202604,1,1),
(675,1,2,'GH','','',202604,3,1),
(676,1,2,'VN','','',202604,2,1),
(677,1,2,'AR','','',202604,2,1),
(678,1,2,'NZ','','',202604,2,1),
(679,1,2,'SE','','',202604,1,1),
(680,1,2,'US','','',202605,39,21),
(681,1,2,'IN','','',202605,16,9),
(682,1,2,'CN','','',202605,13,7),
(683,1,2,'GB','','',202605,16,9),
(684,1,2,'DE','','',202605,12,6),
(685,1,2,'BR','','',202605,10,5),
(686,1,2,'NG','','',202605,6,3),
(687,1,2,'IR','','',202605,7,4),
(688,1,2,'PK','','',202605,11,6),
(689,1,2,'EG','','',202605,9,5),
(690,1,2,'ET','','',202605,6,3),
(691,1,2,'KE','','',202605,4,2),
(692,1,2,'TR','','',202605,8,4),
(693,1,2,'FR','','',202605,6,4),
(694,1,2,'IT','','',202605,4,2),
(695,1,2,'AU','','',202605,4,2),
(696,1,2,'CA','','',202605,4,2),
(697,1,2,'ID','','',202605,8,4),
(698,1,2,'ES','','',202605,3,2),
(699,1,2,'BD','','',202605,4,2),
(700,1,2,'MX','','',202605,3,2),
(701,1,2,'ZA','','',202605,5,3),
(702,1,2,'NL','','',202605,4,2),
(703,1,2,'JP','','',202605,3,2),
(704,1,2,'SA','','',202605,5,3),
(705,1,2,'MY','','',202605,6,3),
(706,1,2,'PL','','',202605,2,1),
(707,1,2,'GH','','',202605,1,1),
(708,1,2,'VN','','',202605,2,1),
(709,1,2,'AR','','',202605,2,1),
(710,1,2,'NZ','','',202605,2,1),
(711,1,2,'SE','','',202605,2,1),
(712,1,2,'US','','',202606,25,15),
(713,1,2,'IN','','',202606,29,18),
(714,1,2,'CN','','',202606,20,12),
(715,1,2,'GB','','',202606,17,10),
(716,1,2,'DE','','',202606,18,11),
(717,1,2,'BR','','',202606,12,7),
(718,1,2,'NG','','',202606,11,7),
(719,1,2,'IR','','',202606,14,8),
(720,1,2,'PK','','',202606,9,6),
(721,1,2,'EG','','',202606,5,3),
(722,1,2,'ET','','',202606,6,4),
(723,1,2,'KE','','',202606,8,5),
(724,1,2,'TR','','',202606,5,3),
(725,1,2,'FR','','',202606,4,2),
(726,1,2,'IT','','',202606,9,5),
(727,1,2,'AU','','',202606,7,4),
(728,1,2,'CA','','',202606,10,6),
(729,1,2,'ID','','',202606,8,5),
(730,1,2,'ES','','',202606,5,3),
(731,1,2,'BD','','',202606,6,3),
(732,1,2,'MX','','',202606,4,2),
(733,1,2,'ZA','','',202606,4,2),
(734,1,2,'NL','','',202606,3,2),
(735,1,2,'JP','','',202606,4,3),
(736,1,2,'SA','','',202606,7,4),
(737,1,2,'MY','','',202606,4,2),
(738,1,2,'PL','','',202606,2,1),
(739,1,2,'GH','','',202606,1,1),
(740,1,2,'VN','','',202606,3,2),
(741,1,2,'AR','','',202606,2,2),
(742,1,2,'NZ','','',202606,2,1),
(743,1,2,'SE','','',202606,3,2),
(744,1,2,'US','','',202607,16,11),
(745,1,2,'IN','','',202607,33,22),
(746,1,2,'CN','','',202607,21,14),
(747,1,2,'GB','','',202607,22,15),
(748,1,2,'DE','','',202607,8,5),
(749,1,2,'BR','','',202607,7,5),
(750,1,2,'NG','','',202607,11,7),
(751,1,2,'IR','','',202607,14,9),
(752,1,2,'PK','','',202607,9,6),
(753,1,2,'EG','','',202607,7,5),
(754,1,2,'ET','','',202607,8,6),
(755,1,2,'KE','','',202607,4,3),
(756,1,2,'TR','','',202607,6,4),
(757,1,2,'FR','','',202607,8,5),
(758,1,2,'IT','','',202607,8,6),
(759,1,2,'AU','','',202607,8,6),
(760,1,2,'CA','','',202607,9,6),
(761,1,2,'ID','','',202607,8,5),
(762,1,2,'ES','','',202607,4,2),
(763,1,2,'BD','','',202607,4,3),
(764,1,2,'MX','','',202607,4,3),
(765,1,2,'ZA','','',202607,2,1),
(766,1,2,'NL','','',202607,6,4),
(767,1,2,'JP','','',202607,5,3),
(768,1,2,'SA','','',202607,4,3),
(769,1,2,'MY','','',202607,2,1),
(770,1,2,'PL','','',202607,3,2),
(771,1,2,'GH','','',202607,2,2),
(772,1,2,'VN','','',202607,2,1),
(773,1,2,'AR','','',202607,2,1),
(774,1,2,'NZ','','',202607,2,1),
(775,1,2,'SE','','',202607,1,1),
(776,1,2,'US','','',202608,30,18),
(777,1,2,'IN','','',202608,16,9),
(778,1,2,'CN','','',202608,18,11),
(779,1,2,'GB','','',202608,12,7),
(780,1,2,'DE','','',202608,10,6),
(781,1,2,'BR','','',202608,13,7),
(782,1,2,'NG','','',202608,17,10),
(783,1,2,'IR','','',202608,20,12),
(784,1,2,'PK','','',202608,9,5),
(785,1,2,'EG','','',202608,6,3),
(786,1,2,'ET','','',202608,9,5),
(787,1,2,'KE','','',202608,9,5),
(788,1,2,'TR','','',202608,12,7),
(789,1,2,'FR','','',202608,7,4),
(790,1,2,'IT','','',202608,9,5),
(791,1,2,'AU','','',202608,8,5),
(792,1,2,'CA','','',202608,11,7),
(793,1,2,'ID','','',202608,5,3),
(794,1,2,'ES','','',202608,4,2),
(795,1,2,'BD','','',202608,3,2),
(796,1,2,'MX','','',202608,4,2),
(797,1,2,'ZA','','',202608,4,2),
(798,1,2,'NL','','',202608,4,2),
(799,1,2,'JP','','',202608,5,3),
(800,1,2,'SA','','',202608,7,4),
(801,1,2,'MY','','',202608,4,2),
(802,1,2,'PL','','',202608,3,2),
(803,1,2,'GH','','',202608,4,2),
(804,1,2,'VN','','',202608,4,2),
(805,1,2,'AR','','',202608,3,2),
(806,1,2,'NZ','','',202608,3,2),
(807,1,2,'SE','','',202608,3,2),
(808,1,2,'US','','',202609,20,12),
(809,1,2,'IN','','',202609,35,20),
(810,1,2,'CN','','',202609,22,12),
(811,1,2,'GB','','',202609,13,7),
(812,1,2,'DE','','',202609,14,8),
(813,1,2,'BR','','',202609,14,8),
(814,1,2,'NG','','',202609,7,4),
(815,1,2,'IR','','',202609,10,6),
(816,1,2,'PK','','',202609,6,4),
(817,1,2,'EG','','',202609,11,6),
(818,1,2,'ET','','',202609,4,2),
(819,1,2,'KE','','',202609,8,5),
(820,1,2,'TR','','',202609,7,4),
(821,1,2,'FR','','',202609,5,3),
(822,1,2,'IT','','',202609,7,4),
(823,1,2,'AU','','',202609,3,2),
(824,1,2,'CA','','',202609,4,2),
(825,1,2,'ID','','',202609,9,5),
(826,1,2,'ES','','',202609,4,2),
(827,1,2,'BD','','',202609,5,3),
(828,1,2,'MX','','',202609,4,2),
(829,1,2,'ZA','','',202609,6,3),
(830,1,2,'NL','','',202609,5,3),
(831,1,2,'JP','','',202609,5,3),
(832,1,2,'SA','','',202609,3,2),
(833,1,2,'MY','','',202609,4,2),
(834,1,2,'PL','','',202609,1,1),
(835,1,2,'GH','','',202609,1,1),
(836,1,2,'VN','','',202609,3,2),
(837,1,2,'AR','','',202609,2,1),
(838,1,2,'NZ','','',202609,2,1),
(839,1,2,'SE','','',202609,1,1),
(840,1,2,'US','','',202610,4,2),
(841,1,2,'IN','','',202610,7,4),
(842,1,2,'CN','','',202610,3,2),
(843,1,2,'GB','','',202610,3,2),
(844,1,2,'DE','','',202610,2,1),
(845,1,2,'BR','','',202610,3,1),
(846,1,2,'NG','','',202610,3,2),
(847,1,2,'IR','','',202610,3,2),
(848,1,2,'PK','','',202610,1,1),
(849,1,2,'EG','','',202610,2,1),
(850,1,2,'ET','','',202610,2,1),
(851,1,2,'TR','','',202610,2,1),
(852,1,2,'FR','','',202610,1,1),
(853,1,2,'IT','','',202610,1,1),
(854,1,2,'AU','','',202610,2,1),
(855,1,2,'CA','','',202610,1,1),
(856,1,2,'ID','','',202610,1,1),
(857,1,2,'MX','','',202610,1,1),
(858,1,2,'ZA','','',202610,1,1),
(859,1,2,'JP','','',202610,1,1),
(860,1,2,'SA','','',202610,1,1),
(861,1,2,'MY','','',202610,1,1),
(862,1,3,'US','','',202509,27,15),
(863,1,3,'IN','','',202509,35,19),
(864,1,3,'CN','','',202509,22,12),
(865,1,3,'GB','','',202509,9,5),
(866,1,3,'DE','','',202509,14,7),
(867,1,3,'BR','','',202509,19,10),
(868,1,3,'NG','','',202509,15,8),
(869,1,3,'IR','','',202509,8,4),
(870,1,3,'PK','','',202509,10,5),
(871,1,3,'EG','','',202509,7,4),
(872,1,3,'ET','','',202509,9,5),
(873,1,3,'KE','','',202509,4,2),
(874,1,3,'TR','','',202509,6,3),
(875,1,3,'FR','','',202509,6,3),
(876,1,3,'IT','','',202509,9,5),
(877,1,3,'AU','','',202509,6,3),
(878,1,3,'CA','','',202509,8,4),
(879,1,3,'ID','','',202509,4,2),
(880,1,3,'ES','','',202509,5,3),
(881,1,3,'BD','','',202509,5,3),
(882,1,3,'MX','','',202509,3,1),
(883,1,3,'ZA','','',202509,5,3),
(884,1,3,'NL','','',202509,5,3),
(885,1,3,'JP','','',202509,4,2),
(886,1,3,'SA','','',202509,2,1),
(887,1,3,'MY','','',202509,6,3),
(888,1,3,'PL','','',202509,3,1),
(889,1,3,'GH','','',202509,3,2),
(890,1,3,'VN','','',202509,2,1),
(891,1,3,'AR','','',202509,2,1),
(892,1,3,'NZ','','',202509,1,1),
(893,1,3,'SE','','',202509,1,1),
(894,1,3,'US','','',202510,35,20),
(895,1,3,'IN','','',202510,29,17),
(896,1,3,'CN','','',202510,30,17),
(897,1,3,'GB','','',202510,26,15),
(898,1,3,'DE','','',202510,23,13),
(899,1,3,'BR','','',202510,14,8),
(900,1,3,'NG','','',202510,7,4),
(901,1,3,'IR','','',202510,12,7),
(902,1,3,'PK','','',202510,12,7),
(903,1,3,'EG','','',202510,9,5),
(904,1,3,'ET','','',202510,7,4),
(905,1,3,'KE','','',202510,5,3),
(906,1,3,'TR','','',202510,11,7),
(907,1,3,'FR','','',202510,5,3),
(908,1,3,'IT','','',202510,6,3),
(909,1,3,'AU','','',202510,10,6),
(910,1,3,'CA','','',202510,9,5),
(911,1,3,'ID','','',202510,8,5),
(912,1,3,'ES','','',202510,7,4),
(913,1,3,'BD','','',202510,3,2),
(914,1,3,'MX','','',202510,7,4),
(915,1,3,'ZA','','',202510,6,3),
(916,1,3,'NL','','',202510,3,2),
(917,1,3,'JP','','',202510,4,2),
(918,1,3,'SA','','',202510,7,4),
(919,1,3,'MY','','',202510,7,4),
(920,1,3,'PL','','',202510,4,2),
(921,1,3,'GH','','',202510,2,1),
(922,1,3,'VN','','',202510,2,1),
(923,1,3,'AR','','',202510,3,2),
(924,1,3,'NZ','','',202510,3,2),
(925,1,3,'SE','','',202510,3,2),
(926,1,3,'US','','',202511,37,21),
(927,1,3,'IN','','',202511,21,12),
(928,1,3,'CN','','',202511,17,10),
(929,1,3,'GB','','',202511,15,9),
(930,1,3,'DE','','',202511,12,7),
(931,1,3,'BR','','',202511,13,7),
(932,1,3,'NG','','',202511,6,4),
(933,1,3,'IR','','',202511,5,3),
(934,1,3,'PK','','',202511,7,4),
(935,1,3,'EG','','',202511,4,2),
(936,1,3,'ET','','',202511,7,4),
(937,1,3,'KE','','',202511,6,4),
(938,1,3,'TR','','',202511,4,2),
(939,1,3,'FR','','',202511,3,2),
(940,1,3,'IT','','',202511,5,3),
(941,1,3,'AU','','',202511,6,4),
(942,1,3,'CA','','',202511,4,3),
(943,1,3,'ID','','',202511,6,3),
(944,1,3,'ES','','',202511,2,1),
(945,1,3,'BD','','',202511,4,3),
(946,1,3,'MX','','',202511,2,1),
(947,1,3,'ZA','','',202511,3,2),
(948,1,3,'NL','','',202511,5,3),
(949,1,3,'JP','','',202511,4,2),
(950,1,3,'SA','','',202511,3,2),
(951,1,3,'MY','','',202511,2,1),
(952,1,3,'PL','','',202511,1,1),
(953,1,3,'GH','','',202511,2,1),
(954,1,3,'VN','','',202511,3,1),
(955,1,3,'AR','','',202511,1,1),
(956,1,3,'NZ','','',202511,2,1),
(957,1,3,'SE','','',202511,2,1),
(958,1,3,'US','','',202512,29,18),
(959,1,3,'IN','','',202512,16,10),
(960,1,3,'CN','','',202512,14,9),
(961,1,3,'GB','','',202512,8,5),
(962,1,3,'DE','','',202512,11,7),
(963,1,3,'BR','','',202512,6,4),
(964,1,3,'NG','','',202512,12,7),
(965,1,3,'IR','','',202512,5,3),
(966,1,3,'PK','','',202512,8,5),
(967,1,3,'EG','','',202512,9,6),
(968,1,3,'ET','','',202512,3,2),
(969,1,3,'KE','','',202512,5,3),
(970,1,3,'TR','','',202512,3,2),
(971,1,3,'FR','','',202512,4,3),
(972,1,3,'IT','','',202512,4,2),
(973,1,3,'AU','','',202512,6,4),
(974,1,3,'CA','','',202512,3,2),
(975,1,3,'ID','','',202512,6,4),
(976,1,3,'ES','','',202512,2,1),
(977,1,3,'BD','','',202512,2,1),
(978,1,3,'MX','','',202512,4,3),
(979,1,3,'ZA','','',202512,3,2),
(980,1,3,'NL','','',202512,3,2),
(981,1,3,'JP','','',202512,3,2),
(982,1,3,'SA','','',202512,3,2),
(983,1,3,'MY','','',202512,3,2),
(984,1,3,'PL','','',202512,2,1),
(985,1,3,'GH','','',202512,2,1),
(986,1,3,'VN','','',202512,1,1),
(987,1,3,'AR','','',202512,2,2),
(988,1,3,'NZ','','',202512,1,1),
(989,1,3,'SE','','',202512,2,1),
(990,1,3,'US','','',202601,26,12),
(991,1,3,'IN','','',202601,27,12),
(992,1,3,'CN','','',202601,9,4),
(993,1,3,'GB','','',202601,16,7),
(994,1,3,'DE','','',202601,18,8),
(995,1,3,'BR','','',202601,18,8),
(996,1,3,'NG','','',202601,16,7),
(997,1,3,'IR','','',202601,10,5),
(998,1,3,'PK','','',202601,8,4),
(999,1,3,'EG','','',202601,7,3),
(1000,1,3,'ET','','',202601,7,3),
(1001,1,3,'KE','','',202601,7,3),
(1002,1,3,'TR','','',202601,9,4),
(1003,1,3,'FR','','',202601,4,2),
(1004,1,3,'IT','','',202601,7,3),
(1005,1,3,'AU','','',202601,7,3),
(1006,1,3,'CA','','',202601,5,2),
(1007,1,3,'ID','','',202601,7,3),
(1008,1,3,'ES','','',202601,6,3),
(1009,1,3,'BD','','',202601,3,1),
(1010,1,3,'MX','','',202601,3,1),
(1011,1,3,'ZA','','',202601,5,2),
(1012,1,3,'NL','','',202601,5,2),
(1013,1,3,'JP','','',202601,5,2),
(1014,1,3,'SA','','',202601,6,3),
(1015,1,3,'MY','','',202601,4,2),
(1016,1,3,'PL','','',202601,2,1),
(1017,1,3,'GH','','',202601,2,1),
(1018,1,3,'VN','','',202601,1,1),
(1019,1,3,'AR','','',202601,3,1),
(1020,1,3,'NZ','','',202601,2,1),
(1021,1,3,'SE','','',202601,3,1),
(1022,1,3,'US','','',202602,60,31),
(1023,1,3,'IN','','',202602,26,14),
(1024,1,3,'CN','','',202602,24,12),
(1025,1,3,'GB','','',202602,13,7),
(1026,1,3,'DE','','',202602,15,8),
(1027,1,3,'BR','','',202602,26,13),
(1028,1,3,'NG','','',202602,14,7),
(1029,1,3,'IR','','',202602,20,10),
(1030,1,3,'PK','','',202602,9,4),
(1031,1,3,'EG','','',202602,12,6),
(1032,1,3,'ET','','',202602,7,4),
(1033,1,3,'KE','','',202602,5,2),
(1034,1,3,'TR','','',202602,6,3),
(1035,1,3,'FR','','',202602,13,7),
(1036,1,3,'IT','','',202602,4,2),
(1037,1,3,'AU','','',202602,10,5),
(1038,1,3,'CA','','',202602,13,7),
(1039,1,3,'ID','','',202602,9,5),
(1040,1,3,'ES','','',202602,3,2),
(1041,1,3,'BD','','',202602,3,2),
(1042,1,3,'MX','','',202602,9,4),
(1043,1,3,'ZA','','',202602,9,4),
(1044,1,3,'NL','','',202602,8,4),
(1045,1,3,'JP','','',202602,4,2),
(1046,1,3,'SA','','',202602,8,4),
(1047,1,3,'MY','','',202602,3,2),
(1048,1,3,'PL','','',202602,3,2),
(1049,1,3,'GH','','',202602,4,2),
(1050,1,3,'VN','','',202602,3,2),
(1051,1,3,'AR','','',202602,2,1),
(1052,1,3,'NZ','','',202602,2,1),
(1053,1,3,'SE','','',202602,4,2),
(1054,1,3,'US','','',202603,38,19),
(1055,1,3,'IN','','',202603,30,15),
(1056,1,3,'CN','','',202603,37,19),
(1057,1,3,'GB','','',202603,30,15),
(1058,1,3,'DE','','',202603,24,12),
(1059,1,3,'BR','','',202603,18,9),
(1060,1,3,'NG','','',202603,12,6),
(1061,1,3,'IR','','',202603,9,4),
(1062,1,3,'PK','','',202603,21,10),
(1063,1,3,'EG','','',202603,20,10),
(1064,1,3,'ET','','',202603,14,7),
(1065,1,3,'KE','','',202603,10,5),
(1066,1,3,'TR','','',202603,8,4),
(1067,1,3,'FR','','',202603,14,7),
(1068,1,3,'IT','','',202603,12,6),
(1069,1,3,'AU','','',202603,13,7),
(1070,1,3,'CA','','',202603,12,6),
(1071,1,3,'ID','','',202603,10,5),
(1072,1,3,'ES','','',202603,8,4),
(1073,1,3,'BD','','',202603,6,3),
(1074,1,3,'MX','','',202603,7,4),
(1075,1,3,'ZA','','',202603,4,2),
(1076,1,3,'NL','','',202603,5,2),
(1077,1,3,'JP','','',202603,8,4),
(1078,1,3,'SA','','',202603,8,4),
(1079,1,3,'MY','','',202603,10,5),
(1080,1,3,'PL','','',202603,3,1),
(1081,1,3,'GH','','',202603,3,2),
(1082,1,3,'VN','','',202603,4,2),
(1083,1,3,'AR','','',202603,5,2),
(1084,1,3,'NZ','','',202603,2,1),
(1085,1,3,'SE','','',202603,2,1),
(1086,1,3,'US','','',202604,33,20),
(1087,1,3,'IN','','',202604,23,14),
(1088,1,3,'CN','','',202604,25,16),
(1089,1,3,'GB','','',202604,29,18),
(1090,1,3,'DE','','',202604,17,10),
(1091,1,3,'BR','','',202604,23,14),
(1092,1,3,'NG','','',202604,18,11),
(1093,1,3,'IR','','',202604,18,11),
(1094,1,3,'PK','','',202604,10,6),
(1095,1,3,'EG','','',202604,16,10),
(1096,1,3,'ET','','',202604,11,7),
(1097,1,3,'KE','','',202604,13,8),
(1098,1,3,'TR','','',202604,9,5),
(1099,1,3,'FR','','',202604,14,9),
(1100,1,3,'IT','','',202604,5,3),
(1101,1,3,'AU','','',202604,11,7),
(1102,1,3,'CA','','',202604,9,5),
(1103,1,3,'ID','','',202604,10,6),
(1104,1,3,'ES','','',202604,8,5),
(1105,1,3,'BD','','',202604,7,5),
(1106,1,3,'MX','','',202604,6,4),
(1107,1,3,'ZA','','',202604,7,4),
(1108,1,3,'NL','','',202604,5,3),
(1109,1,3,'JP','','',202604,7,4),
(1110,1,3,'SA','','',202604,8,5),
(1111,1,3,'MY','','',202604,7,4),
(1112,1,3,'PL','','',202604,2,1),
(1113,1,3,'GH','','',202604,4,2),
(1114,1,3,'VN','','',202604,5,3),
(1115,1,3,'AR','','',202604,5,3),
(1116,1,3,'NZ','','',202604,3,2),
(1117,1,3,'SE','','',202604,3,2),
(1118,1,3,'US','','',202605,74,42),
(1119,1,3,'IN','','',202605,55,31),
(1120,1,3,'CN','','',202605,17,10),
(1121,1,3,'GB','','',202605,24,14),
(1122,1,3,'DE','','',202605,31,17),
(1123,1,3,'BR','','',202605,19,11),
(1124,1,3,'NG','','',202605,12,7),
(1125,1,3,'IR','','',202605,24,14),
(1126,1,3,'PK','','',202605,22,13),
(1127,1,3,'EG','','',202605,8,5),
(1128,1,3,'ET','','',202605,12,7),
(1129,1,3,'KE','','',202605,6,4),
(1130,1,3,'TR','','',202605,16,9),
(1131,1,3,'FR','','',202605,13,7),
(1132,1,3,'IT','','',202605,16,9),
(1133,1,3,'AU','','',202605,17,9),
(1134,1,3,'CA','','',202605,8,4),
(1135,1,3,'ID','','',202605,15,8),
(1136,1,3,'ES','','',202605,10,6),
(1137,1,3,'BD','','',202605,6,3),
(1138,1,3,'MX','','',202605,5,3),
(1139,1,3,'ZA','','',202605,6,3),
(1140,1,3,'NL','','',202605,8,4),
(1141,1,3,'JP','','',202605,9,5),
(1142,1,3,'SA','','',202605,5,3),
(1143,1,3,'MY','','',202605,4,2),
(1144,1,3,'PL','','',202605,5,3),
(1145,1,3,'GH','','',202605,5,3),
(1146,1,3,'VN','','',202605,5,3),
(1147,1,3,'AR','','',202605,3,2),
(1148,1,3,'NZ','','',202605,2,1),
(1149,1,3,'SE','','',202605,4,2),
(1150,1,3,'US','','',202606,64,29),
(1151,1,3,'IN','','',202606,41,19),
(1152,1,3,'CN','','',202606,32,15),
(1153,1,3,'GB','','',202606,33,15),
(1154,1,3,'DE','','',202606,26,12),
(1155,1,3,'BR','','',202606,10,4),
(1156,1,3,'NG','','',202606,10,5),
(1157,1,3,'IR','','',202606,11,5),
(1158,1,3,'PK','','',202606,16,7),
(1159,1,3,'EG','','',202606,10,4),
(1160,1,3,'ET','','',202606,14,6),
(1161,1,3,'KE','','',202606,14,6),
(1162,1,3,'TR','','',202606,5,2),
(1163,1,3,'FR','','',202606,7,3),
(1164,1,3,'IT','','',202606,12,6),
(1165,1,3,'AU','','',202606,14,6),
(1166,1,3,'CA','','',202606,7,3),
(1167,1,3,'ID','','',202606,14,6),
(1168,1,3,'ES','','',202606,9,4),
(1169,1,3,'BD','','',202606,6,3),
(1170,1,3,'MX','','',202606,8,4),
(1171,1,3,'ZA','','',202606,8,4),
(1172,1,3,'NL','','',202606,9,4),
(1173,1,3,'JP','','',202606,9,4),
(1174,1,3,'SA','','',202606,4,2),
(1175,1,3,'MY','','',202606,5,2),
(1176,1,3,'PL','','',202606,4,2),
(1177,1,3,'GH','','',202606,3,1),
(1178,1,3,'VN','','',202606,4,2),
(1179,1,3,'AR','','',202606,2,1),
(1180,1,3,'NZ','','',202606,3,1),
(1181,1,3,'SE','','',202606,4,2),
(1182,1,3,'US','','',202607,29,18),
(1183,1,3,'IN','','',202607,43,26),
(1184,1,3,'CN','','',202607,33,20),
(1185,1,3,'GB','','',202607,18,11),
(1186,1,3,'DE','','',202607,27,16),
(1187,1,3,'BR','','',202607,25,15),
(1188,1,3,'NG','','',202607,16,10),
(1189,1,3,'IR','','',202607,12,7),
(1190,1,3,'PK','','',202607,11,7),
(1191,1,3,'EG','','',202607,18,11),
(1192,1,3,'ET','','',202607,10,6),
(1193,1,3,'KE','','',202607,9,5),
(1194,1,3,'TR','','',202607,15,9),
(1195,1,3,'FR','','',202607,11,7),
(1196,1,3,'IT','','',202607,16,10),
(1197,1,3,'AU','','',202607,10,6),
(1198,1,3,'CA','','',202607,13,8),
(1199,1,3,'ID','','',202607,9,6),
(1200,1,3,'ES','','',202607,5,3),
(1201,1,3,'BD','','',202607,11,7),
(1202,1,3,'MX','','',202607,7,4),
(1203,1,3,'ZA','','',202607,7,4),
(1204,1,3,'NL','','',202607,11,7),
(1205,1,3,'JP','','',202607,10,6),
(1206,1,3,'SA','','',202607,9,6),
(1207,1,3,'MY','','',202607,7,4),
(1208,1,3,'PL','','',202607,4,2),
(1209,1,3,'GH','','',202607,2,2),
(1210,1,3,'VN','','',202607,3,2),
(1211,1,3,'AR','','',202607,4,3),
(1212,1,3,'NZ','','',202607,2,1),
(1213,1,3,'SE','','',202607,5,3),
(1214,1,3,'US','','',202608,36,19),
(1215,1,3,'IN','','',202608,49,26),
(1216,1,3,'CN','','',202608,13,7),
(1217,1,3,'GB','','',202608,24,13),
(1218,1,3,'DE','','',202608,20,11),
(1219,1,3,'BR','','',202608,25,13),
(1220,1,3,'NG','','',202608,16,9),
(1221,1,3,'IR','','',202608,21,11),
(1222,1,3,'PK','','',202608,13,7),
(1223,1,3,'EG','','',202608,17,9),
(1224,1,3,'ET','','',202608,8,4),
(1225,1,3,'KE','','',202608,12,6),
(1226,1,3,'TR','','',202608,7,4),
(1227,1,3,'FR','','',202608,10,5),
(1228,1,3,'IT','','',202608,7,4),
(1229,1,3,'AU','','',202608,9,5),
(1230,1,3,'CA','','',202608,9,5),
(1231,1,3,'ID','','',202608,12,6),
(1232,1,3,'ES','','',202608,9,5),
(1233,1,3,'BD','','',202608,8,4),
(1234,1,3,'MX','','',202608,6,3),
(1235,1,3,'ZA','','',202608,7,3),
(1236,1,3,'NL','','',202608,6,3),
(1237,1,3,'JP','','',202608,8,4),
(1238,1,3,'SA','','',202608,5,2),
(1239,1,3,'MY','','',202608,5,3),
(1240,1,3,'PL','','',202608,4,2),
(1241,1,3,'GH','','',202608,4,2),
(1242,1,3,'VN','','',202608,2,1),
(1243,1,3,'AR','','',202608,2,1),
(1244,1,3,'NZ','','',202608,3,1),
(1245,1,3,'SE','','',202608,2,1),
(1246,1,3,'US','','',202609,39,22),
(1247,1,3,'IN','','',202609,24,14),
(1248,1,3,'CN','','',202609,31,18),
(1249,1,3,'GB','','',202609,13,8),
(1250,1,3,'DE','','',202609,15,9),
(1251,1,3,'BR','','',202609,26,15),
(1252,1,3,'NG','','',202609,16,9),
(1253,1,3,'IR','','',202609,10,6),
(1254,1,3,'PK','','',202609,14,8),
(1255,1,3,'EG','','',202609,9,5),
(1256,1,3,'ET','','',202609,16,9),
(1257,1,3,'KE','','',202609,13,8),
(1258,1,3,'TR','','',202609,13,8),
(1259,1,3,'FR','','',202609,12,7),
(1260,1,3,'IT','','',202609,11,6),
(1261,1,3,'AU','','',202609,13,7),
(1262,1,3,'CA','','',202609,7,4),
(1263,1,3,'ID','','',202609,14,8),
(1264,1,3,'ES','','',202609,6,4),
(1265,1,3,'BD','','',202609,7,4),
(1266,1,3,'MX','','',202609,4,2),
(1267,1,3,'ZA','','',202609,5,3),
(1268,1,3,'NL','','',202609,9,5),
(1269,1,3,'JP','','',202609,6,3),
(1270,1,3,'SA','','',202609,10,6),
(1271,1,3,'MY','','',202609,7,4),
(1272,1,3,'PL','','',202609,3,1),
(1273,1,3,'GH','','',202609,4,2),
(1274,1,3,'VN','','',202609,2,1),
(1275,1,3,'AR','','',202609,4,2),
(1276,1,3,'NZ','','',202609,3,2),
(1277,1,3,'SE','','',202609,3,2),
(1278,1,3,'US','','',202610,7,4),
(1279,1,3,'IN','','',202610,14,8),
(1280,1,3,'CN','','',202610,8,5),
(1281,1,3,'GB','','',202610,6,3),
(1282,1,3,'DE','','',202610,6,4),
(1283,1,3,'BR','','',202610,7,4),
(1284,1,3,'NG','','',202610,3,2),
(1285,1,3,'IR','','',202610,5,3),
(1286,1,3,'PK','','',202610,4,2),
(1287,1,3,'EG','','',202610,5,3),
(1288,1,3,'ET','','',202610,2,1),
(1289,1,3,'KE','','',202610,3,2),
(1290,1,3,'TR','','',202610,2,1),
(1291,1,3,'FR','','',202610,3,2),
(1292,1,3,'IT','','',202610,1,1),
(1293,1,3,'AU','','',202610,2,1),
(1294,1,3,'CA','','',202610,2,1),
(1295,1,3,'ID','','',202610,4,2),
(1296,1,3,'ES','','',202610,1,1),
(1297,1,3,'BD','','',202610,2,1),
(1298,1,3,'MX','','',202610,1,1),
(1299,1,3,'ZA','','',202610,1,1),
(1300,1,3,'NL','','',202610,2,1),
(1301,1,3,'JP','','',202610,1,1),
(1302,1,3,'SA','','',202610,2,1),
(1303,1,3,'MY','','',202610,2,1),
(1304,1,3,'PL','','',202610,1,1),
(1305,1,3,'NZ','','',202610,1,1),
(1306,1,4,'US','','',202509,11,5),
(1307,1,4,'IN','','',202509,9,4),
(1308,1,4,'CN','','',202509,6,3),
(1309,1,4,'GB','','',202509,3,1),
(1310,1,4,'DE','','',202509,4,2),
(1311,1,4,'BR','','',202509,2,1),
(1312,1,4,'NG','','',202509,3,2),
(1313,1,4,'IR','','',202509,2,1),
(1314,1,4,'PK','','',202509,2,1),
(1315,1,4,'EG','','',202509,2,1),
(1316,1,4,'ET','','',202509,2,1),
(1317,1,4,'KE','','',202509,1,1),
(1318,1,4,'TR','','',202509,1,1),
(1319,1,4,'FR','','',202509,2,1),
(1320,1,4,'IT','','',202509,3,1),
(1321,1,4,'AU','','',202509,2,1),
(1322,1,4,'CA','','',202509,2,1),
(1323,1,4,'ID','','',202509,1,1),
(1324,1,4,'ES','','',202509,2,1),
(1325,1,4,'BD','','',202509,2,1),
(1326,1,4,'MX','','',202509,1,1),
(1327,1,4,'JP','','',202509,1,1),
(1328,1,4,'US','','',202510,12,7),
(1329,1,4,'IN','','',202510,19,11),
(1330,1,4,'CN','','',202510,5,3),
(1331,1,4,'GB','','',202510,5,3),
(1332,1,4,'DE','','',202510,8,5),
(1333,1,4,'BR','','',202510,9,5),
(1334,1,4,'NG','','',202510,6,3),
(1335,1,4,'IR','','',202510,6,3),
(1336,1,4,'PK','','',202510,5,3),
(1337,1,4,'EG','','',202510,3,2),
(1338,1,4,'ET','','',202510,4,2),
(1339,1,4,'KE','','',202510,5,3),
(1340,1,4,'TR','','',202510,4,2),
(1341,1,4,'FR','','',202510,3,2),
(1342,1,4,'IT','','',202510,2,1),
(1343,1,4,'AU','','',202510,2,1),
(1344,1,4,'CA','','',202510,4,2),
(1345,1,4,'ID','','',202510,4,2),
(1346,1,4,'ES','','',202510,1,1),
(1347,1,4,'BD','','',202510,2,1),
(1348,1,4,'MX','','',202510,1,1),
(1349,1,4,'ZA','','',202510,3,2),
(1350,1,4,'NL','','',202510,2,1),
(1351,1,4,'JP','','',202510,2,1),
(1352,1,4,'SA','','',202510,2,1),
(1353,1,4,'MY','','',202510,2,1),
(1354,1,4,'PL','','',202510,1,1),
(1355,1,4,'GH','','',202510,1,1),
(1356,1,4,'VN','','',202510,1,1),
(1357,1,4,'NZ','','',202510,1,1),
(1358,1,4,'US','','',202511,11,6),
(1359,1,4,'IN','','',202511,7,4),
(1360,1,4,'CN','','',202511,5,2),
(1361,1,4,'GB','','',202511,7,4),
(1362,1,4,'DE','','',202511,5,3),
(1363,1,4,'BR','','',202511,4,2),
(1364,1,4,'NG','','',202511,2,1),
(1365,1,4,'IR','','',202511,4,2),
(1366,1,4,'PK','','',202511,3,1),
(1367,1,4,'EG','','',202511,4,2),
(1368,1,4,'ET','','',202511,2,1),
(1369,1,4,'KE','','',202511,3,2),
(1370,1,4,'TR','','',202511,1,1),
(1371,1,4,'FR','','',202511,3,2),
(1372,1,4,'IT','','',202511,3,1),
(1373,1,4,'AU','','',202511,2,1),
(1374,1,4,'CA','','',202511,2,1),
(1375,1,4,'ID','','',202511,1,1),
(1376,1,4,'ES','','',202511,1,1),
(1377,1,4,'MX','','',202511,1,1),
(1378,1,4,'ZA','','',202511,1,1),
(1379,1,4,'NL','','',202511,1,1),
(1380,1,4,'SA','','',202511,2,1),
(1381,1,4,'MY','','',202511,1,1),
(1382,1,4,'NZ','','',202511,1,1),
(1383,1,4,'US','','',202512,8,4),
(1384,1,4,'IN','','',202512,17,9),
(1385,1,4,'CN','','',202512,5,2),
(1386,1,4,'GB','','',202512,7,4),
(1387,1,4,'DE','','',202512,9,5),
(1388,1,4,'BR','','',202512,10,5),
(1389,1,4,'NG','','',202512,6,3),
(1390,1,4,'IR','','',202512,8,4),
(1391,1,4,'PK','','',202512,6,3),
(1392,1,4,'EG','','',202512,4,2),
(1393,1,4,'ET','','',202512,4,2),
(1394,1,4,'KE','','',202512,3,1),
(1395,1,4,'TR','','',202512,4,2),
(1396,1,4,'FR','','',202512,2,1),
(1397,1,4,'IT','','',202512,2,1),
(1398,1,4,'AU','','',202512,2,1),
(1399,1,4,'CA','','',202512,2,1),
(1400,1,4,'ID','','',202512,2,1),
(1401,1,4,'ES','','',202512,2,1),
(1402,1,4,'BD','','',202512,2,1),
(1403,1,4,'MX','','',202512,3,2),
(1404,1,4,'ZA','','',202512,2,1),
(1405,1,4,'NL','','',202512,2,1),
(1406,1,4,'JP','','',202512,1,1),
(1407,1,4,'SA','','',202512,2,1),
(1408,1,4,'MY','','',202512,1,1),
(1409,1,4,'PL','','',202512,2,1),
(1410,1,4,'GH','','',202512,1,1),
(1411,1,4,'NZ','','',202512,1,1),
(1412,1,4,'US','','',202601,25,13),
(1413,1,4,'IN','','',202601,19,10),
(1414,1,4,'CN','','',202601,5,3),
(1415,1,4,'GB','','',202601,5,3),
(1416,1,4,'DE','','',202601,7,4),
(1417,1,4,'BR','','',202601,5,3),
(1418,1,4,'NG','','',202601,8,4),
(1419,1,4,'IR','','',202601,7,4),
(1420,1,4,'PK','','',202601,4,2),
(1421,1,4,'EG','','',202601,4,2),
(1422,1,4,'ET','','',202601,4,2),
(1423,1,4,'KE','','',202601,2,1),
(1424,1,4,'TR','','',202601,5,3),
(1425,1,4,'FR','','',202601,2,1),
(1426,1,4,'IT','','',202601,5,3),
(1427,1,4,'AU','','',202601,4,2),
(1428,1,4,'CA','','',202601,4,2),
(1429,1,4,'ID','','',202601,3,1),
(1430,1,4,'ES','','',202601,2,1),
(1431,1,4,'BD','','',202601,4,2),
(1432,1,4,'MX','','',202601,3,2),
(1433,1,4,'ZA','','',202601,3,2),
(1434,1,4,'NL','','',202601,2,1),
(1435,1,4,'JP','','',202601,2,1),
(1436,1,4,'SA','','',202601,1,1),
(1437,1,4,'MY','','',202601,3,2),
(1438,1,4,'GH','','',202601,1,1),
(1439,1,4,'VN','','',202601,2,1),
(1440,1,4,'NZ','','',202601,1,1),
(1441,1,4,'SE','','',202601,1,1),
(1442,1,4,'US','','',202602,13,6),
(1443,1,4,'IN','','',202602,14,6),
(1444,1,4,'CN','','',202602,6,3),
(1445,1,4,'GB','','',202602,5,2),
(1446,1,4,'DE','','',202602,5,2),
(1447,1,4,'BR','','',202602,5,2),
(1448,1,4,'NG','','',202602,7,3),
(1449,1,4,'IR','','',202602,3,1),
(1450,1,4,'PK','','',202602,3,2),
(1451,1,4,'EG','','',202602,2,1),
(1452,1,4,'ET','','',202602,4,2),
(1453,1,4,'KE','','',202602,2,1),
(1454,1,4,'TR','','',202602,3,2),
(1455,1,4,'FR','','',202602,3,1),
(1456,1,4,'IT','','',202602,2,1),
(1457,1,4,'AU','','',202602,2,1),
(1458,1,4,'CA','','',202602,4,2),
(1459,1,4,'ID','','',202602,3,2),
(1460,1,4,'ES','','',202602,1,1),
(1461,1,4,'BD','','',202602,2,1),
(1462,1,4,'MX','','',202602,2,1),
(1463,1,4,'ZA','','',202602,2,1),
(1464,1,4,'NL','','',202602,2,1),
(1465,1,4,'JP','','',202602,2,1),
(1466,1,4,'MY','','',202602,2,1),
(1467,1,4,'PL','','',202602,1,1),
(1468,1,4,'GH','','',202602,1,1),
(1469,1,4,'NZ','','',202602,1,1),
(1470,1,4,'SE','','',202602,1,1),
(1471,1,4,'US','','',202603,22,13),
(1472,1,4,'IN','','',202603,10,6),
(1473,1,4,'CN','','',202603,7,4),
(1474,1,4,'GB','','',202603,10,6),
(1475,1,4,'DE','','',202603,5,3),
(1476,1,4,'BR','','',202603,9,5),
(1477,1,4,'NG','','',202603,5,3),
(1478,1,4,'IR','','',202603,8,5),
(1479,1,4,'PK','','',202603,3,2),
(1480,1,4,'EG','','',202603,6,3),
(1481,1,4,'ET','','',202603,2,1),
(1482,1,4,'KE','','',202603,3,2),
(1483,1,4,'TR','','',202603,5,3),
(1484,1,4,'FR','','',202603,5,3),
(1485,1,4,'IT','','',202603,3,2),
(1486,1,4,'AU','','',202603,5,3),
(1487,1,4,'CA','','',202603,3,2),
(1488,1,4,'ID','','',202603,2,1),
(1489,1,4,'ES','','',202603,2,1),
(1490,1,4,'BD','','',202603,3,2),
(1491,1,4,'MX','','',202603,4,2),
(1492,1,4,'ZA','','',202603,3,2),
(1493,1,4,'NL','','',202603,3,2),
(1494,1,4,'JP','','',202603,2,1),
(1495,1,4,'SA','','',202603,3,2),
(1496,1,4,'MY','','',202603,1,1),
(1497,1,4,'PL','','',202603,2,1),
(1498,1,4,'GH','','',202603,1,1),
(1499,1,4,'VN','','',202603,1,1),
(1500,1,4,'NZ','','',202603,1,1),
(1501,1,4,'US','','',202604,24,16),
(1502,1,4,'IN','','',202604,20,13),
(1503,1,4,'CN','','',202604,13,9),
(1504,1,4,'GB','','',202604,10,6),
(1505,1,4,'DE','','',202604,8,5),
(1506,1,4,'BR','','',202604,6,4),
(1507,1,4,'NG','','',202604,4,2),
(1508,1,4,'IR','','',202604,5,4),
(1509,1,4,'PK','','',202604,4,2),
(1510,1,4,'EG','','',202604,4,2),
(1511,1,4,'ET','','',202604,2,2),
(1512,1,4,'KE','','',202604,3,2),
(1513,1,4,'TR','','',202604,3,2),
(1514,1,4,'FR','','',202604,5,3),
(1515,1,4,'IT','','',202604,3,2),
(1516,1,4,'AU','','',202604,6,4),
(1517,1,4,'CA','','',202604,4,3),
(1518,1,4,'ID','','',202604,4,3),
(1519,1,4,'ES','','',202604,3,2),
(1520,1,4,'BD','','',202604,3,2),
(1521,1,4,'MX','','',202604,3,2),
(1522,1,4,'ZA','','',202604,4,2),
(1523,1,4,'NL','','',202604,2,1),
(1524,1,4,'JP','','',202604,2,1),
(1525,1,4,'SA','','',202604,3,2),
(1526,1,4,'MY','','',202604,2,1),
(1527,1,4,'GH','','',202604,2,1),
(1528,1,4,'VN','','',202604,2,1),
(1529,1,4,'AR','','',202604,2,1),
(1530,1,4,'NZ','','',202604,1,1),
(1531,1,4,'SE','','',202604,2,1),
(1532,1,4,'US','','',202605,29,16),
(1533,1,4,'IN','','',202605,16,9),
(1534,1,4,'CN','','',202605,11,6),
(1535,1,4,'GB','','',202605,14,8),
(1536,1,4,'DE','','',202605,13,7),
(1537,1,4,'BR','','',202605,10,6),
(1538,1,4,'NG','','',202605,8,5),
(1539,1,4,'IR','','',202605,10,5),
(1540,1,4,'PK','','',202605,6,3),
(1541,1,4,'EG','','',202605,9,5),
(1542,1,4,'ET','','',202605,7,4),
(1543,1,4,'KE','','',202605,4,2),
(1544,1,4,'TR','','',202605,3,2),
(1545,1,4,'FR','','',202605,5,3),
(1546,1,4,'IT','','',202605,3,2),
(1547,1,4,'AU','','',202605,3,2),
(1548,1,4,'CA','','',202605,6,3),
(1549,1,4,'ID','','',202605,5,3),
(1550,1,4,'ES','','',202605,2,1),
(1551,1,4,'BD','','',202605,3,2),
(1552,1,4,'MX','','',202605,5,3),
(1553,1,4,'ZA','','',202605,5,3),
(1554,1,4,'NL','','',202605,4,3),
(1555,1,4,'JP','','',202605,3,2),
(1556,1,4,'SA','','',202605,3,2),
(1557,1,4,'MY','','',202605,3,2),
(1558,1,4,'PL','','',202605,2,1),
(1559,1,4,'GH','','',202605,2,1),
(1560,1,4,'VN','','',202605,2,1),
(1561,1,4,'AR','','',202605,2,1),
(1562,1,4,'NZ','','',202605,2,1),
(1563,1,4,'SE','','',202605,2,1),
(1564,1,4,'US','','',202606,20,11),
(1565,1,4,'IN','','',202606,31,17),
(1566,1,4,'CN','','',202606,22,12),
(1567,1,4,'GB','','',202606,15,8),
(1568,1,4,'DE','','',202606,14,8),
(1569,1,4,'BR','','',202606,13,7),
(1570,1,4,'NG','','',202606,11,6),
(1571,1,4,'IR','','',202606,11,6),
(1572,1,4,'PK','','',202606,11,6),
(1573,1,4,'EG','','',202606,6,3),
(1574,1,4,'ET','','',202606,5,3),
(1575,1,4,'KE','','',202606,7,4),
(1576,1,4,'TR','','',202606,6,3),
(1577,1,4,'FR','','',202606,6,3),
(1578,1,4,'IT','','',202606,5,3),
(1579,1,4,'AU','','',202606,6,3),
(1580,1,4,'CA','','',202606,4,2),
(1581,1,4,'ID','','',202606,7,4),
(1582,1,4,'ES','','',202606,4,2),
(1583,1,4,'BD','','',202606,4,2),
(1584,1,4,'MX','','',202606,5,3),
(1585,1,4,'ZA','','',202606,5,2),
(1586,1,4,'NL','','',202606,6,3),
(1587,1,4,'JP','','',202606,5,3),
(1588,1,4,'SA','','',202606,5,3),
(1589,1,4,'MY','','',202606,3,2),
(1590,1,4,'PL','','',202606,2,1),
(1591,1,4,'GH','','',202606,2,1),
(1592,1,4,'VN','','',202606,1,1),
(1593,1,4,'AR','','',202606,3,1),
(1594,1,4,'NZ','','',202606,3,1),
(1595,1,4,'SE','','',202606,2,1),
(1596,1,4,'US','','',202607,23,14),
(1597,1,4,'IN','','',202607,17,10),
(1598,1,4,'CN','','',202607,13,8),
(1599,1,4,'GB','','',202607,16,9),
(1600,1,4,'DE','','',202607,7,4),
(1601,1,4,'BR','','',202607,9,5),
(1602,1,4,'NG','','',202607,9,5),
(1603,1,4,'IR','','',202607,5,3),
(1604,1,4,'PK','','',202607,8,5),
(1605,1,4,'EG','','',202607,10,6),
(1606,1,4,'ET','','',202607,5,3),
(1607,1,4,'KE','','',202607,7,4),
(1608,1,4,'TR','','',202607,6,4),
(1609,1,4,'FR','','',202607,4,2),
(1610,1,4,'IT','','',202607,4,3),
(1611,1,4,'AU','','',202607,7,4),
(1612,1,4,'CA','','',202607,5,3),
(1613,1,4,'ID','','',202607,6,4),
(1614,1,4,'ES','','',202607,5,3),
(1615,1,4,'BD','','',202607,2,1),
(1616,1,4,'MX','','',202607,3,2),
(1617,1,4,'ZA','','',202607,4,2),
(1618,1,4,'NL','','',202607,2,1),
(1619,1,4,'JP','','',202607,2,1),
(1620,1,4,'SA','','',202607,3,2),
(1621,1,4,'MY','','',202607,5,3),
(1622,1,4,'PL','','',202607,2,1),
(1623,1,4,'GH','','',202607,1,1),
(1624,1,4,'VN','','',202607,2,1),
(1625,1,4,'AR','','',202607,1,1),
(1626,1,4,'NZ','','',202607,2,1),
(1627,1,4,'SE','','',202607,2,1),
(1628,1,4,'US','','',202608,24,12),
(1629,1,4,'IN','','',202608,15,7),
(1630,1,4,'CN','','',202608,11,5),
(1631,1,4,'GB','','',202608,5,2),
(1632,1,4,'DE','','',202608,8,4),
(1633,1,4,'BR','','',202608,7,3),
(1634,1,4,'NG','','',202608,3,2),
(1635,1,4,'IR','','',202608,6,3),
(1636,1,4,'PK','','',202608,4,2),
(1637,1,4,'EG','','',202608,4,2),
(1638,1,4,'ET','','',202608,5,2),
(1639,1,4,'KE','','',202608,4,2),
(1640,1,4,'TR','','',202608,5,3),
(1641,1,4,'FR','','',202608,2,1),
(1642,1,4,'IT','','',202608,2,1),
(1643,1,4,'AU','','',202608,3,1),
(1644,1,4,'CA','','',202608,2,1),
(1645,1,4,'ID','','',202608,4,2),
(1646,1,4,'ES','','',202608,2,1),
(1647,1,4,'BD','','',202608,3,1),
(1648,1,4,'MX','','',202608,3,2),
(1649,1,4,'ZA','','',202608,2,1),
(1650,1,4,'NL','','',202608,3,1),
(1651,1,4,'JP','','',202608,1,1),
(1652,1,4,'SA','','',202608,1,1),
(1653,1,4,'MY','','',202608,1,1),
(1654,1,4,'AR','','',202608,2,1),
(1655,1,4,'NZ','','',202608,1,1),
(1656,1,4,'SE','','',202608,1,1),
(1657,1,4,'US','','',202609,14,8),
(1658,1,4,'IN','','',202609,20,11),
(1659,1,4,'CN','','',202609,8,5),
(1660,1,4,'GB','','',202609,5,3),
(1661,1,4,'DE','','',202609,6,3),
(1662,1,4,'BR','','',202609,12,7),
(1663,1,4,'NG','','',202609,9,5),
(1664,1,4,'IR','','',202609,10,5),
(1665,1,4,'PK','','',202609,8,4),
(1666,1,4,'EG','','',202609,8,5),
(1667,1,4,'ET','','',202609,3,2),
(1668,1,4,'KE','','',202609,4,2),
(1669,1,4,'TR','','',202609,5,3),
(1670,1,4,'FR','','',202609,3,2),
(1671,1,4,'IT','','',202609,4,2),
(1672,1,4,'AU','','',202609,4,2),
(1673,1,4,'CA','','',202609,4,2),
(1674,1,4,'ID','','',202609,4,2),
(1675,1,4,'ES','','',202609,2,1),
(1676,1,4,'BD','','',202609,3,2),
(1677,1,4,'MX','','',202609,2,1),
(1678,1,4,'ZA','','',202609,2,1),
(1679,1,4,'NL','','',202609,2,1),
(1680,1,4,'JP','','',202609,3,2),
(1681,1,4,'SA','','',202609,2,1),
(1682,1,4,'MY','','',202609,2,1),
(1683,1,4,'PL','','',202609,1,1),
(1684,1,4,'GH','','',202609,2,1),
(1685,1,4,'VN','','',202609,1,1),
(1686,1,4,'AR','','',202609,2,1),
(1687,1,4,'SE','','',202609,1,1),
(1688,1,4,'US','','',202610,2,1),
(1689,1,4,'IN','','',202610,4,2),
(1690,1,4,'CN','','',202610,3,2),
(1691,1,4,'GB','','',202610,1,1),
(1692,1,4,'DE','','',202610,1,1),
(1693,1,4,'BR','','',202610,1,1),
(1694,1,4,'NG','','',202610,2,1),
(1695,1,4,'IR','','',202610,2,1),
(1696,1,4,'PK','','',202610,1,1),
(1697,1,4,'EG','','',202610,1,1),
(1698,1,4,'ET','','',202610,1,1),
(1699,1,4,'TR','','',202610,1,1),
(1700,1,4,'FR','','',202610,1,1),
(1701,1,4,'AU','','',202610,1,1),
(1702,1,5,'US','','',202509,17,10),
(1703,1,5,'IN','','',202509,27,16),
(1704,1,5,'CN','','',202509,12,7),
(1705,1,5,'GB','','',202509,10,6),
(1706,1,5,'DE','','',202509,8,5),
(1707,1,5,'BR','','',202509,13,7),
(1708,1,5,'NG','','',202509,5,3),
(1709,1,5,'IR','','',202509,5,3),
(1710,1,5,'PK','','',202509,5,3),
(1711,1,5,'EG','','',202509,5,3),
(1712,1,5,'ET','','',202509,5,3),
(1713,1,5,'KE','','',202509,7,4),
(1714,1,5,'TR','','',202509,4,2),
(1715,1,5,'FR','','',202509,6,3),
(1716,1,5,'IT','','',202509,7,4),
(1717,1,5,'AU','','',202509,4,2),
(1718,1,5,'CA','','',202509,5,3),
(1719,1,5,'ID','','',202509,5,3),
(1720,1,5,'ES','','',202509,3,2),
(1721,1,5,'BD','','',202509,3,2),
(1722,1,5,'MX','','',202509,5,3),
(1723,1,5,'ZA','','',202509,4,2),
(1724,1,5,'NL','','',202509,2,1),
(1725,1,5,'JP','','',202509,4,2),
(1726,1,5,'SA','','',202509,5,3),
(1727,1,5,'MY','','',202509,4,3),
(1728,1,5,'PL','','',202509,2,1),
(1729,1,5,'GH','','',202509,2,1),
(1730,1,5,'VN','','',202509,1,1),
(1731,1,5,'AR','','',202509,2,1),
(1732,1,5,'NZ','','',202509,2,1),
(1733,1,5,'SE','','',202509,1,1),
(1734,1,5,'US','','',202510,25,17),
(1735,1,5,'IN','','',202510,31,21),
(1736,1,5,'CN','','',202510,22,15),
(1737,1,5,'GB','','',202510,14,10),
(1738,1,5,'DE','','',202510,7,5),
(1739,1,5,'BR','','',202510,18,12),
(1740,1,5,'NG','','',202510,10,7),
(1741,1,5,'IR','','',202510,15,10),
(1742,1,5,'PK','','',202510,5,3),
(1743,1,5,'EG','','',202510,7,5),
(1744,1,5,'ET','','',202510,4,2),
(1745,1,5,'KE','','',202510,4,3),
(1746,1,5,'TR','','',202510,11,7),
(1747,1,5,'FR','','',202510,10,7),
(1748,1,5,'IT','','',202510,7,4),
(1749,1,5,'AU','','',202510,6,4),
(1750,1,5,'CA','','',202510,6,4),
(1751,1,5,'ID','','',202510,9,6),
(1752,1,5,'ES','','',202510,6,4),
(1753,1,5,'BD','','',202510,5,3),
(1754,1,5,'MX','','',202510,3,2),
(1755,1,5,'ZA','','',202510,6,4),
(1756,1,5,'NL','','',202510,6,4),
(1757,1,5,'JP','','',202510,3,2),
(1758,1,5,'SA','','',202510,3,2),
(1759,1,5,'MY','','',202510,3,2),
(1760,1,5,'PL','','',202510,3,2),
(1761,1,5,'GH','','',202510,3,2),
(1762,1,5,'VN','','',202510,3,2),
(1763,1,5,'AR','','',202510,3,2),
(1764,1,5,'NZ','','',202510,2,1),
(1765,1,5,'SE','','',202510,3,2),
(1766,1,5,'US','','',202511,21,11),
(1767,1,5,'IN','','',202511,20,10),
(1768,1,5,'CN','','',202511,19,10),
(1769,1,5,'GB','','',202511,14,7),
(1770,1,5,'DE','','',202511,8,4),
(1771,1,5,'BR','','',202511,14,7),
(1772,1,5,'NG','','',202511,13,7),
(1773,1,5,'IR','','',202511,9,5),
(1774,1,5,'PK','','',202511,11,6),
(1775,1,5,'EG','','',202511,7,4),
(1776,1,5,'ET','','',202511,6,3),
(1777,1,5,'KE','','',202511,6,3),
(1778,1,5,'TR','','',202511,8,4),
(1779,1,5,'FR','','',202511,5,3),
(1780,1,5,'IT','','',202511,7,4),
(1781,1,5,'AU','','',202511,6,3),
(1782,1,5,'CA','','',202511,9,4),
(1783,1,5,'ID','','',202511,9,5),
(1784,1,5,'ES','','',202511,2,1),
(1785,1,5,'BD','','',202511,3,1),
(1786,1,5,'MX','','',202511,5,3),
(1787,1,5,'ZA','','',202511,3,1),
(1788,1,5,'NL','','',202511,5,3),
(1789,1,5,'JP','','',202511,6,3),
(1790,1,5,'SA','','',202511,5,3),
(1791,1,5,'MY','','',202511,3,2),
(1792,1,5,'PL','','',202511,1,1),
(1793,1,5,'GH','','',202511,2,1),
(1794,1,5,'VN','','',202511,1,1),
(1795,1,5,'AR','','',202511,3,1),
(1796,1,5,'NZ','','',202511,1,1),
(1797,1,5,'SE','','',202511,2,1),
(1798,1,5,'US','','',202512,33,18),
(1799,1,5,'IN','','',202512,39,21),
(1800,1,5,'CN','','',202512,12,7),
(1801,1,5,'GB','','',202512,15,8),
(1802,1,5,'DE','','',202512,16,9),
(1803,1,5,'BR','','',202512,17,10),
(1804,1,5,'NG','','',202512,13,7),
(1805,1,5,'IR','','',202512,10,6),
(1806,1,5,'PK','','',202512,8,4),
(1807,1,5,'EG','','',202512,11,6),
(1808,1,5,'ET','','',202512,3,2),
(1809,1,5,'KE','','',202512,5,3),
(1810,1,5,'TR','','',202512,7,4),
(1811,1,5,'FR','','',202512,8,5),
(1812,1,5,'IT','','',202512,6,3),
(1813,1,5,'AU','','',202512,8,5),
(1814,1,5,'CA','','',202512,10,5),
(1815,1,5,'ID','','',202512,6,3),
(1816,1,5,'ES','','',202512,5,3),
(1817,1,5,'BD','','',202512,5,3),
(1818,1,5,'MX','','',202512,4,2),
(1819,1,5,'ZA','','',202512,6,3),
(1820,1,5,'NL','','',202512,3,2),
(1821,1,5,'JP','','',202512,7,4),
(1822,1,5,'SA','','',202512,4,2),
(1823,1,5,'MY','','',202512,5,3),
(1824,1,5,'PL','','',202512,3,2),
(1825,1,5,'GH','','',202512,3,1),
(1826,1,5,'VN','','',202512,3,2),
(1827,1,5,'AR','','',202512,3,2),
(1828,1,5,'NZ','','',202512,3,2),
(1829,1,5,'SE','','',202512,2,1),
(1830,1,5,'US','','',202601,31,18),
(1831,1,5,'IN','','',202601,16,10),
(1832,1,5,'CN','','',202601,15,9),
(1833,1,5,'GB','','',202601,15,9),
(1834,1,5,'DE','','',202601,14,8),
(1835,1,5,'BR','','',202601,10,6),
(1836,1,5,'NG','','',202601,12,7),
(1837,1,5,'IR','','',202601,10,6),
(1838,1,5,'PK','','',202601,6,4),
(1839,1,5,'EG','','',202601,5,3),
(1840,1,5,'ET','','',202601,3,2),
(1841,1,5,'KE','','',202601,3,2),
(1842,1,5,'TR','','',202601,4,2),
(1843,1,5,'FR','','',202601,4,2),
(1844,1,5,'IT','','',202601,7,4),
(1845,1,5,'AU','','',202601,6,3),
(1846,1,5,'CA','','',202601,3,2),
(1847,1,5,'ID','','',202601,7,4),
(1848,1,5,'ES','','',202601,5,3),
(1849,1,5,'BD','','',202601,4,2),
(1850,1,5,'MX','','',202601,5,3),
(1851,1,5,'ZA','','',202601,5,3),
(1852,1,5,'NL','','',202601,3,2),
(1853,1,5,'JP','','',202601,5,3),
(1854,1,5,'SA','','',202601,4,3),
(1855,1,5,'MY','','',202601,2,1),
(1856,1,5,'PL','','',202601,1,1),
(1857,1,5,'GH','','',202601,2,1),
(1858,1,5,'VN','','',202601,3,2),
(1859,1,5,'AR','','',202601,2,1),
(1860,1,5,'NZ','','',202601,1,1),
(1861,1,5,'SE','','',202601,1,1),
(1862,1,5,'US','','',202602,25,15),
(1863,1,5,'IN','','',202602,34,20),
(1864,1,5,'CN','','',202602,12,7),
(1865,1,5,'GB','','',202602,11,7),
(1866,1,5,'DE','','',202602,18,11),
(1867,1,5,'BR','','',202602,17,11),
(1868,1,5,'NG','','',202602,6,4),
(1869,1,5,'IR','','',202602,9,5),
(1870,1,5,'PK','','',202602,5,3),
(1871,1,5,'EG','','',202602,7,4),
(1872,1,5,'ET','','',202602,10,6),
(1873,1,5,'KE','','',202602,9,6),
(1874,1,5,'TR','','',202602,5,3),
(1875,1,5,'FR','','',202602,6,3),
(1876,1,5,'IT','','',202602,6,4),
(1877,1,5,'AU','','',202602,8,5),
(1878,1,5,'CA','','',202602,8,5),
(1879,1,5,'ID','','',202602,10,6),
(1880,1,5,'ES','','',202602,6,4),
(1881,1,5,'BD','','',202602,5,3),
(1882,1,5,'MX','','',202602,3,2),
(1883,1,5,'ZA','','',202602,6,4),
(1884,1,5,'NL','','',202602,4,3),
(1885,1,5,'JP','','',202602,5,3),
(1886,1,5,'SA','','',202602,5,3),
(1887,1,5,'MY','','',202602,3,2),
(1888,1,5,'PL','','',202602,1,1),
(1889,1,5,'GH','','',202602,2,1),
(1890,1,5,'VN','','',202602,1,1),
(1891,1,5,'AR','','',202602,1,1),
(1892,1,5,'NZ','','',202602,2,1),
(1893,1,5,'SE','','',202602,1,1),
(1894,1,5,'US','','',202603,40,24),
(1895,1,5,'IN','','',202603,37,22),
(1896,1,5,'CN','','',202603,27,16),
(1897,1,5,'GB','','',202603,14,8),
(1898,1,5,'DE','','',202603,13,8),
(1899,1,5,'BR','','',202603,14,8),
(1900,1,5,'NG','','',202603,22,13),
(1901,1,5,'IR','','',202603,23,14),
(1902,1,5,'PK','','',202603,14,9),
(1903,1,5,'EG','','',202603,20,12),
(1904,1,5,'ET','','',202603,15,9),
(1905,1,5,'KE','','',202603,15,9),
(1906,1,5,'TR','','',202603,7,4),
(1907,1,5,'FR','','',202603,17,10),
(1908,1,5,'IT','','',202603,6,3),
(1909,1,5,'AU','','',202603,10,6),
(1910,1,5,'CA','','',202603,8,5),
(1911,1,5,'ID','','',202603,16,9),
(1912,1,5,'ES','','',202603,9,5),
(1913,1,5,'BD','','',202603,5,3),
(1914,1,5,'MX','','',202603,10,6),
(1915,1,5,'ZA','','',202603,9,5),
(1916,1,5,'NL','','',202603,8,5),
(1917,1,5,'JP','','',202603,9,5),
(1918,1,5,'SA','','',202603,10,6),
(1919,1,5,'MY','','',202603,5,3),
(1920,1,5,'PL','','',202603,5,3),
(1921,1,5,'GH','','',202603,5,3),
(1922,1,5,'VN','','',202603,3,2),
(1923,1,5,'AR','','',202603,3,2),
(1924,1,5,'NZ','','',202603,5,3),
(1925,1,5,'SE','','',202603,2,1),
(1926,1,5,'US','','',202604,58,25),
(1927,1,5,'IN','','',202604,20,8),
(1928,1,5,'CN','','',202604,17,7),
(1929,1,5,'GB','','',202604,22,9),
(1930,1,5,'DE','','',202604,19,8),
(1931,1,5,'BR','','',202604,17,7),
(1932,1,5,'NG','','',202604,12,5),
(1933,1,5,'IR','','',202604,10,4),
(1934,1,5,'PK','','',202604,11,5),
(1935,1,5,'EG','','',202604,16,7),
(1936,1,5,'ET','','',202604,11,5),
(1937,1,5,'KE','','',202604,12,5),
(1938,1,5,'TR','','',202604,10,4),
(1939,1,5,'FR','','',202604,6,2),
(1940,1,5,'IT','','',202604,6,3),
(1941,1,5,'AU','','',202604,8,4),
(1942,1,5,'CA','','',202604,6,2),
(1943,1,5,'ID','','',202604,10,4),
(1944,1,5,'ES','','',202604,8,4),
(1945,1,5,'BD','','',202604,5,2),
(1946,1,5,'MX','','',202604,5,2),
(1947,1,5,'ZA','','',202604,8,4),
(1948,1,5,'NL','','',202604,9,4),
(1949,1,5,'JP','','',202604,7,3),
(1950,1,5,'SA','','',202604,3,1),
(1951,1,5,'MY','','',202604,8,3),
(1952,1,5,'PL','','',202604,3,1),
(1953,1,5,'GH','','',202604,2,1),
(1954,1,5,'VN','','',202604,2,1),
(1955,1,5,'AR','','',202604,3,1),
(1956,1,5,'NZ','','',202604,4,2),
(1957,1,5,'SE','','',202604,3,1),
(1958,1,5,'US','','',202605,37,24),
(1959,1,5,'IN','','',202605,43,28),
(1960,1,5,'CN','','',202605,34,22),
(1961,1,5,'GB','','',202605,18,12),
(1962,1,5,'DE','','',202605,16,10),
(1963,1,5,'BR','','',202605,19,12),
(1964,1,5,'NG','','',202605,21,14),
(1965,1,5,'IR','','',202605,18,12),
(1966,1,5,'PK','','',202605,18,12),
(1967,1,5,'EG','','',202605,18,12),
(1968,1,5,'ET','','',202605,8,5),
(1969,1,5,'KE','','',202605,5,4),
(1970,1,5,'TR','','',202605,14,9),
(1971,1,5,'FR','','',202605,7,4),
(1972,1,5,'IT','','',202605,7,5),
(1973,1,5,'AU','','',202605,11,7),
(1974,1,5,'CA','','',202605,6,4),
(1975,1,5,'ID','','',202605,8,5),
(1976,1,5,'ES','','',202605,8,6),
(1977,1,5,'BD','','',202605,7,5),
(1978,1,5,'MX','','',202605,8,5),
(1979,1,5,'ZA','','',202605,7,5),
(1980,1,5,'NL','','',202605,4,3),
(1981,1,5,'JP','','',202605,5,3),
(1982,1,5,'SA','','',202605,6,4),
(1983,1,5,'MY','','',202605,6,4),
(1984,1,5,'PL','','',202605,2,1),
(1985,1,5,'GH','','',202605,2,1),
(1986,1,5,'VN','','',202605,4,3),
(1987,1,5,'AR','','',202605,5,3),
(1988,1,5,'NZ','','',202605,2,2),
(1989,1,5,'SE','','',202605,4,2),
(1990,1,5,'US','','',202606,53,24),
(1991,1,5,'IN','','',202606,30,14),
(1992,1,5,'CN','','',202606,29,13),
(1993,1,5,'GB','','',202606,14,6),
(1994,1,5,'DE','','',202606,12,5),
(1995,1,5,'BR','','',202606,23,11),
(1996,1,5,'NG','','',202606,22,10),
(1997,1,5,'IR','','',202606,13,6),
(1998,1,5,'PK','','',202606,20,9),
(1999,1,5,'EG','','',202606,19,9),
(2000,1,5,'ET','','',202606,13,6),
(2001,1,5,'KE','','',202606,12,5),
(2002,1,5,'TR','','',202606,8,3),
(2003,1,5,'FR','','',202606,11,5),
(2004,1,5,'IT','','',202606,14,6),
(2005,1,5,'AU','','',202606,6,3),
(2006,1,5,'CA','','',202606,13,6),
(2007,1,5,'ID','','',202606,11,5),
(2008,1,5,'ES','','',202606,5,2),
(2009,1,5,'BD','','',202606,5,2),
(2010,1,5,'MX','','',202606,7,3),
(2011,1,5,'ZA','','',202606,11,5),
(2012,1,5,'NL','','',202606,10,5),
(2013,1,5,'JP','','',202606,5,2),
(2014,1,5,'SA','','',202606,6,3),
(2015,1,5,'MY','','',202606,8,3),
(2016,1,5,'PL','','',202606,3,1),
(2017,1,5,'GH','','',202606,5,2),
(2018,1,5,'VN','','',202606,4,2),
(2019,1,5,'AR','','',202606,2,1),
(2020,1,5,'NZ','','',202606,3,2),
(2021,1,5,'SE','','',202606,2,1),
(2022,1,5,'US','','',202607,44,21),
(2023,1,5,'IN','','',202607,68,33),
(2024,1,5,'CN','','',202607,24,12),
(2025,1,5,'GB','','',202607,23,11),
(2026,1,5,'DE','','',202607,32,15),
(2027,1,5,'BR','','',202607,15,7),
(2028,1,5,'NG','','',202607,17,8),
(2029,1,5,'IR','','',202607,25,12),
(2030,1,5,'PK','','',202607,9,4),
(2031,1,5,'EG','','',202607,12,6),
(2032,1,5,'ET','','',202607,15,7),
(2033,1,5,'KE','','',202607,14,7),
(2034,1,5,'TR','','',202607,11,5),
(2035,1,5,'FR','','',202607,13,6),
(2036,1,5,'IT','','',202607,11,6),
(2037,1,5,'AU','','',202607,16,8),
(2038,1,5,'CA','','',202607,11,5),
(2039,1,5,'ID','','',202607,7,3),
(2040,1,5,'ES','','',202607,9,5),
(2041,1,5,'BD','','',202607,5,2),
(2042,1,5,'MX','','',202607,8,4),
(2043,1,5,'ZA','','',202607,8,4),
(2044,1,5,'NL','','',202607,9,4),
(2045,1,5,'JP','','',202607,10,5),
(2046,1,5,'SA','','',202607,11,5),
(2047,1,5,'MY','','',202607,9,5),
(2048,1,5,'PL','','',202607,3,1),
(2049,1,5,'GH','','',202607,2,1),
(2050,1,5,'VN','','',202607,4,2),
(2051,1,5,'AR','','',202607,4,2),
(2052,1,5,'NZ','','',202607,4,2),
(2053,1,5,'SE','','',202607,3,1),
(2054,1,5,'US','','',202608,43,28),
(2055,1,5,'IN','','',202608,55,36),
(2056,1,5,'CN','','',202608,27,17),
(2057,1,5,'GB','','',202608,16,11),
(2058,1,5,'DE','','',202608,14,9),
(2059,1,5,'BR','','',202608,32,21),
(2060,1,5,'NG','','',202608,21,13),
(2061,1,5,'IR','','',202608,18,12),
(2062,1,5,'PK','','',202608,25,16),
(2063,1,5,'EG','','',202608,23,15),
(2064,1,5,'ET','','',202608,10,7),
(2065,1,5,'KE','','',202608,11,7),
(2066,1,5,'TR','','',202608,10,6),
(2067,1,5,'FR','','',202608,15,10),
(2068,1,5,'IT','','',202608,11,7),
(2069,1,5,'AU','','',202608,16,10),
(2070,1,5,'CA','','',202608,20,13),
(2071,1,5,'ID','','',202608,17,11),
(2072,1,5,'ES','','',202608,5,3),
(2073,1,5,'BD','','',202608,10,7),
(2074,1,5,'MX','','',202608,8,5),
(2075,1,5,'ZA','','',202608,7,5),
(2076,1,5,'NL','','',202608,8,5),
(2077,1,5,'JP','','',202608,12,8),
(2078,1,5,'SA','','',202608,13,8),
(2079,1,5,'MY','','',202608,11,7),
(2080,1,5,'PL','','',202608,4,3),
(2081,1,5,'GH','','',202608,4,3),
(2082,1,5,'VN','','',202608,5,3),
(2083,1,5,'AR','','',202608,6,4),
(2084,1,5,'NZ','','',202608,6,4),
(2085,1,5,'SE','','',202608,3,2),
(2086,1,5,'US','','',202609,53,29),
(2087,1,5,'IN','','',202609,32,18),
(2088,1,5,'CN','','',202609,33,18),
(2089,1,5,'GB','','',202609,31,17),
(2090,1,5,'DE','','',202609,19,10),
(2091,1,5,'BR','','',202609,27,15),
(2092,1,5,'NG','','',202609,26,14),
(2093,1,5,'IR','','',202609,27,15),
(2094,1,5,'PK','','',202609,11,6),
(2095,1,5,'EG','','',202609,8,4),
(2096,1,5,'ET','','',202609,16,9),
(2097,1,5,'KE','','',202609,11,6),
(2098,1,5,'TR','','',202609,9,5),
(2099,1,5,'FR','','',202609,11,6),
(2100,1,5,'IT','','',202609,9,5),
(2101,1,5,'AU','','',202609,8,5),
(2102,1,5,'CA','','',202609,14,7),
(2103,1,5,'ID','','',202609,11,6),
(2104,1,5,'ES','','',202609,10,6),
(2105,1,5,'BD','','',202609,8,4),
(2106,1,5,'MX','','',202609,4,2),
(2107,1,5,'ZA','','',202609,7,4),
(2108,1,5,'NL','','',202609,6,3),
(2109,1,5,'JP','','',202609,6,3),
(2110,1,5,'SA','','',202609,10,5),
(2111,1,5,'MY','','',202609,6,3),
(2112,1,5,'PL','','',202609,2,1),
(2113,1,5,'GH','','',202609,3,1),
(2114,1,5,'VN','','',202609,5,3),
(2115,1,5,'AR','','',202609,2,1),
(2116,1,5,'NZ','','',202609,3,2),
(2117,1,5,'SE','','',202609,3,2),
(2118,1,5,'US','','',202610,8,5),
(2119,1,5,'IN','','',202610,8,4),
(2120,1,5,'CN','','',202610,8,5),
(2121,1,5,'GB','','',202610,5,3),
(2122,1,5,'DE','','',202610,4,3),
(2123,1,5,'BR','','',202610,5,3),
(2124,1,5,'NG','','',202610,5,3),
(2125,1,5,'IR','','',202610,3,2),
(2126,1,5,'PK','','',202610,2,1),
(2127,1,5,'EG','','',202610,2,1),
(2128,1,5,'ET','','',202610,2,1),
(2129,1,5,'KE','','',202610,1,1),
(2130,1,5,'TR','','',202610,2,1),
(2131,1,5,'FR','','',202610,2,1),
(2132,1,5,'IT','','',202610,2,1),
(2133,1,5,'AU','','',202610,3,2),
(2134,1,5,'CA','','',202610,3,2),
(2135,1,5,'ID','','',202610,3,1),
(2136,1,5,'ES','','',202610,3,1),
(2137,1,5,'BD','','',202610,3,1),
(2138,1,5,'MX','','',202610,2,1),
(2139,1,5,'ZA','','',202610,2,1),
(2140,1,5,'NL','','',202610,1,1),
(2141,1,5,'JP','','',202610,2,1),
(2142,1,5,'SA','','',202610,1,1),
(2143,1,5,'MY','','',202610,1,1),
(2144,1,5,'PL','','',202610,1,1),
(2145,1,5,'GH','','',202610,1,1),
(2146,1,5,'VN','','',202610,1,1),
(2147,1,6,'US','','',202509,32,18),
(2148,1,6,'IN','','',202509,16,9),
(2149,1,6,'CN','','',202509,16,9),
(2150,1,6,'GB','','',202509,14,8),
(2151,1,6,'DE','','',202509,5,3),
(2152,1,6,'BR','','',202509,8,5),
(2153,1,6,'NG','','',202509,10,5),
(2154,1,6,'IR','','',202509,8,4),
(2155,1,6,'PK','','',202509,6,3),
(2156,1,6,'EG','','',202509,9,5),
(2157,1,6,'ET','','',202509,7,4),
(2158,1,6,'KE','','',202509,6,3),
(2159,1,6,'TR','','',202509,5,3),
(2160,1,6,'FR','','',202509,6,3),
(2161,1,6,'IT','','',202509,3,2),
(2162,1,6,'AU','','',202509,4,2),
(2163,1,6,'CA','','',202509,7,4),
(2164,1,6,'ID','','',202509,7,4),
(2165,1,6,'ES','','',202509,4,2),
(2166,1,6,'BD','','',202509,2,1),
(2167,1,6,'MX','','',202509,4,2),
(2168,1,6,'ZA','','',202509,3,2),
(2169,1,6,'NL','','',202509,4,2),
(2170,1,6,'JP','','',202509,3,2),
(2171,1,6,'SA','','',202509,5,2),
(2172,1,6,'MY','','',202509,2,1),
(2173,1,6,'PL','','',202509,2,1),
(2174,1,6,'GH','','',202509,2,1),
(2175,1,6,'VN','','',202509,1,1),
(2176,1,6,'NZ','','',202509,2,1),
(2177,1,6,'SE','','',202509,2,1),
(2178,1,6,'US','','',202510,23,15),
(2179,1,6,'IN','','',202510,18,12),
(2180,1,6,'CN','','',202510,10,6),
(2181,1,6,'GB','','',202510,12,8),
(2182,1,6,'DE','','',202510,7,4),
(2183,1,6,'BR','','',202510,11,7),
(2184,1,6,'NG','','',202510,6,4),
(2185,1,6,'IR','','',202510,4,3),
(2186,1,6,'PK','','',202510,6,4),
(2187,1,6,'EG','','',202510,3,2),
(2188,1,6,'ET','','',202510,3,2),
(2189,1,6,'KE','','',202510,5,3),
(2190,1,6,'TR','','',202510,4,3),
(2191,1,6,'FR','','',202510,2,2),
(2192,1,6,'IT','','',202510,4,3),
(2193,1,6,'AU','','',202510,4,2),
(2194,1,6,'CA','','',202510,2,2),
(2195,1,6,'ID','','',202510,5,3),
(2196,1,6,'ES','','',202510,2,1),
(2197,1,6,'BD','','',202510,2,2),
(2198,1,6,'MX','','',202510,3,2),
(2199,1,6,'ZA','','',202510,2,1),
(2200,1,6,'NL','','',202510,3,2),
(2201,1,6,'JP','','',202510,2,2),
(2202,1,6,'SA','','',202510,2,1),
(2203,1,6,'MY','','',202510,2,1),
(2204,1,6,'PL','','',202510,1,1),
(2205,1,6,'GH','','',202510,2,1),
(2206,1,6,'AR','','',202510,1,1),
(2207,1,6,'NZ','','',202510,2,1),
(2208,1,6,'SE','','',202510,1,1),
(2209,1,6,'US','','',202511,25,11),
(2210,1,6,'IN','','',202511,17,7),
(2211,1,6,'CN','','',202511,5,2),
(2212,1,6,'GB','','',202511,7,3),
(2213,1,6,'DE','','',202511,4,2),
(2214,1,6,'BR','','',202511,5,2),
(2215,1,6,'NG','','',202511,9,4),
(2216,1,6,'IR','','',202511,10,4),
(2217,1,6,'PK','','',202511,5,2),
(2218,1,6,'EG','','',202511,7,3),
(2219,1,6,'ET','','',202511,6,3),
(2220,1,6,'KE','','',202511,3,1),
(2221,1,6,'TR','','',202511,4,2),
(2222,1,6,'FR','','',202511,6,3),
(2223,1,6,'IT','','',202511,5,2),
(2224,1,6,'AU','','',202511,3,1),
(2225,1,6,'CA','','',202511,3,1),
(2226,1,6,'ID','','',202511,5,2),
(2227,1,6,'ES','','',202511,3,1),
(2228,1,6,'BD','','',202511,2,1),
(2229,1,6,'MX','','',202511,3,1),
(2230,1,6,'ZA','','',202511,3,2),
(2231,1,6,'NL','','',202511,3,1),
(2232,1,6,'JP','','',202511,3,2),
(2233,1,6,'SA','','',202511,4,2),
(2234,1,6,'MY','','',202511,3,1),
(2235,1,6,'AR','','',202511,1,1),
(2236,1,6,'NZ','','',202511,1,1),
(2237,1,6,'SE','','',202511,2,1),
(2238,1,6,'US','','',202512,15,8),
(2239,1,6,'IN','','',202512,26,14),
(2240,1,6,'CN','','',202512,15,8),
(2241,1,6,'GB','','',202512,10,5),
(2242,1,6,'DE','','',202512,5,2),
(2243,1,6,'BR','','',202512,12,6),
(2244,1,6,'NG','','',202512,7,4),
(2245,1,6,'IR','','',202512,5,3),
(2246,1,6,'PK','','',202512,8,4),
(2247,1,6,'EG','','',202512,6,3),
(2248,1,6,'ET','','',202512,7,4),
(2249,1,6,'KE','','',202512,5,2),
(2250,1,6,'TR','','',202512,2,1),
(2251,1,6,'FR','','',202512,3,2),
(2252,1,6,'IT','','',202512,3,1),
(2253,1,6,'AU','','',202512,6,3),
(2254,1,6,'CA','','',202512,6,3),
(2255,1,6,'ID','','',202512,5,3),
(2256,1,6,'ES','','',202512,3,1),
(2257,1,6,'BD','','',202512,3,1),
(2258,1,6,'MX','','',202512,2,1),
(2259,1,6,'ZA','','',202512,4,2),
(2260,1,6,'NL','','',202512,3,2),
(2261,1,6,'JP','','',202512,4,2),
(2262,1,6,'SA','','',202512,3,2),
(2263,1,6,'MY','','',202512,2,1),
(2264,1,6,'PL','','',202512,2,1),
(2265,1,6,'GH','','',202512,2,1),
(2266,1,6,'VN','','',202512,2,1),
(2267,1,6,'NZ','','',202512,2,1),
(2268,1,6,'US','','',202601,18,10),
(2269,1,6,'IN','','',202601,12,7),
(2270,1,6,'CN','','',202601,8,5),
(2271,1,6,'GB','','',202601,14,8),
(2272,1,6,'DE','','',202601,5,3),
(2273,1,6,'BR','','',202601,5,3),
(2274,1,6,'NG','','',202601,5,3),
(2275,1,6,'IR','','',202601,4,2),
(2276,1,6,'PK','','',202601,5,3),
(2277,1,6,'EG','','',202601,7,4),
(2278,1,6,'ET','','',202601,2,1),
(2279,1,6,'KE','','',202601,4,2),
(2280,1,6,'TR','','',202601,6,3),
(2281,1,6,'FR','','',202601,4,2),
(2282,1,6,'IT','','',202601,3,1),
(2283,1,6,'AU','','',202601,4,2),
(2284,1,6,'CA','','',202601,2,1),
(2285,1,6,'ID','','',202601,3,2),
(2286,1,6,'ES','','',202601,3,2),
(2287,1,6,'BD','','',202601,2,1),
(2288,1,6,'MX','','',202601,2,1),
(2289,1,6,'ZA','','',202601,3,1),
(2290,1,6,'NL','','',202601,2,1),
(2291,1,6,'JP','','',202601,2,1),
(2292,1,6,'SA','','',202601,4,2),
(2293,1,6,'MY','','',202601,3,2),
(2294,1,6,'PL','','',202601,1,1),
(2295,1,6,'GH','','',202601,2,1),
(2296,1,6,'NZ','','',202601,2,1),
(2297,1,6,'SE','','',202601,2,1),
(2298,1,6,'US','','',202602,28,16),
(2299,1,6,'IN','','',202602,13,8),
(2300,1,6,'CN','','',202602,14,9),
(2301,1,6,'GB','','',202602,6,4),
(2302,1,6,'DE','','',202602,13,8),
(2303,1,6,'BR','','',202602,8,5),
(2304,1,6,'NG','','',202602,6,4),
(2305,1,6,'IR','','',202602,9,5),
(2306,1,6,'PK','','',202602,7,4),
(2307,1,6,'EG','','',202602,7,4),
(2308,1,6,'ET','','',202602,5,3),
(2309,1,6,'KE','','',202602,5,3),
(2310,1,6,'TR','','',202602,6,3),
(2311,1,6,'FR','','',202602,6,4),
(2312,1,6,'IT','','',202602,5,3),
(2313,1,6,'AU','','',202602,4,2),
(2314,1,6,'CA','','',202602,4,2),
(2315,1,6,'ID','','',202602,6,3),
(2316,1,6,'ES','','',202602,3,2),
(2317,1,6,'BD','','',202602,3,2),
(2318,1,6,'MX','','',202602,2,1),
(2319,1,6,'ZA','','',202602,3,2),
(2320,1,6,'NL','','',202602,2,1),
(2321,1,6,'JP','','',202602,3,2),
(2322,1,6,'SA','','',202602,4,2),
(2323,1,6,'MY','','',202602,4,2),
(2324,1,6,'PL','','',202602,1,1),
(2325,1,6,'GH','','',202602,1,1),
(2326,1,6,'VN','','',202602,1,1),
(2327,1,6,'AR','','',202602,1,1),
(2328,1,6,'NZ','','',202602,2,1),
(2329,1,6,'SE','','',202602,1,1),
(2330,1,6,'US','','',202603,15,8),
(2331,1,6,'IN','','',202603,17,9),
(2332,1,6,'CN','','',202603,9,4),
(2333,1,6,'GB','','',202603,14,7),
(2334,1,6,'DE','','',202603,8,4),
(2335,1,6,'BR','','',202603,9,4),
(2336,1,6,'NG','','',202603,11,5),
(2337,1,6,'IR','','',202603,6,3),
(2338,1,6,'PK','','',202603,4,2),
(2339,1,6,'EG','','',202603,9,5),
(2340,1,6,'ET','','',202603,3,1),
(2341,1,6,'KE','','',202603,5,2),
(2342,1,6,'TR','','',202603,7,3),
(2343,1,6,'FR','','',202603,4,2),
(2344,1,6,'IT','','',202603,3,2),
(2345,1,6,'AU','','',202603,6,3),
(2346,1,6,'CA','','',202603,7,4),
(2347,1,6,'ID','','',202603,3,1),
(2348,1,6,'ES','','',202603,3,1),
(2349,1,6,'BD','','',202603,5,3),
(2350,1,6,'MX','','',202603,3,1),
(2351,1,6,'ZA','','',202603,2,1),
(2352,1,6,'NL','','',202603,4,2),
(2353,1,6,'JP','','',202603,2,1),
(2354,1,6,'SA','','',202603,5,2),
(2355,1,6,'MY','','',202603,5,3),
(2356,1,6,'PL','','',202603,2,1),
(2357,1,6,'GH','','',202603,2,1),
(2358,1,6,'VN','','',202603,1,1),
(2359,1,6,'AR','','',202603,2,1),
(2360,1,6,'NZ','','',202603,1,1),
(2361,1,6,'SE','','',202603,2,1),
(2362,1,6,'US','','',202604,20,14),
(2363,1,6,'IN','','',202604,31,21),
(2364,1,6,'CN','','',202604,15,10),
(2365,1,6,'GB','','',202604,14,9),
(2366,1,6,'DE','','',202604,11,8),
(2367,1,6,'BR','','',202604,8,5),
(2368,1,6,'NG','','',202604,14,9),
(2369,1,6,'IR','','',202604,6,4),
(2370,1,6,'PK','','',202604,8,5),
(2371,1,6,'EG','','',202604,6,4),
(2372,1,6,'ET','','',202604,6,4),
(2373,1,6,'KE','','',202604,4,3),
(2374,1,6,'TR','','',202604,8,5),
(2375,1,6,'FR','','',202604,8,5),
(2376,1,6,'IT','','',202604,9,6),
(2377,1,6,'AU','','',202604,9,6),
(2378,1,6,'CA','','',202604,7,5),
(2379,1,6,'ID','','',202604,6,4),
(2380,1,6,'ES','','',202604,6,4),
(2381,1,6,'BD','','',202604,5,3),
(2382,1,6,'MX','','',202604,3,2),
(2383,1,6,'ZA','','',202604,5,4),
(2384,1,6,'NL','','',202604,4,3),
(2385,1,6,'JP','','',202604,4,3),
(2386,1,6,'SA','','',202604,5,3),
(2387,1,6,'MY','','',202604,4,3),
(2388,1,6,'PL','','',202604,3,2),
(2389,1,6,'GH','','',202604,3,2),
(2390,1,6,'VN','','',202604,3,2),
(2391,1,6,'AR','','',202604,1,1),
(2392,1,6,'NZ','','',202604,2,2),
(2393,1,6,'SE','','',202604,2,2),
(2394,1,6,'US','','',202605,34,18),
(2395,1,6,'IN','','',202605,21,11),
(2396,1,6,'CN','','',202605,26,14),
(2397,1,6,'GB','','',202605,21,11),
(2398,1,6,'DE','','',202605,21,11),
(2399,1,6,'BR','','',202605,18,9),
(2400,1,6,'NG','','',202605,15,8),
(2401,1,6,'IR','','',202605,13,7),
(2402,1,6,'PK','','',202605,6,3),
(2403,1,6,'EG','','',202605,12,6),
(2404,1,6,'ET','','',202605,7,4),
(2405,1,6,'KE','','',202605,4,2),
(2406,1,6,'TR','','',202605,10,5),
(2407,1,6,'FR','','',202605,8,4),
(2408,1,6,'IT','','',202605,9,5),
(2409,1,6,'AU','','',202605,12,6),
(2410,1,6,'CA','','',202605,11,6),
(2411,1,6,'ID','','',202605,7,4),
(2412,1,6,'ES','','',202605,3,1),
(2413,1,6,'BD','','',202605,4,2),
(2414,1,6,'MX','','',202605,8,4),
(2415,1,6,'ZA','','',202605,6,3),
(2416,1,6,'NL','','',202605,6,3),
(2417,1,6,'JP','','',202605,7,3),
(2418,1,6,'SA','','',202605,4,2),
(2419,1,6,'MY','','',202605,3,1),
(2420,1,6,'PL','','',202605,3,2),
(2421,1,6,'GH','','',202605,2,1),
(2422,1,6,'VN','','',202605,1,1),
(2423,1,6,'AR','','',202605,3,1),
(2424,1,6,'NZ','','',202605,2,1),
(2425,1,6,'SE','','',202605,2,1),
(2426,1,6,'US','','',202606,40,23),
(2427,1,6,'IN','','',202606,34,19),
(2428,1,6,'CN','','',202606,18,10),
(2429,1,6,'GB','','',202606,16,9),
(2430,1,6,'DE','','',202606,15,9),
(2431,1,6,'BR','','',202606,19,10),
(2432,1,6,'NG','','',202606,14,8),
(2433,1,6,'IR','','',202606,12,7),
(2434,1,6,'PK','','',202606,11,6),
(2435,1,6,'EG','','',202606,6,3),
(2436,1,6,'ET','','',202606,4,2),
(2437,1,6,'KE','','',202606,7,4),
(2438,1,6,'TR','','',202606,5,3),
(2439,1,6,'FR','','',202606,5,3),
(2440,1,6,'IT','','',202606,4,2),
(2441,1,6,'AU','','',202606,7,4),
(2442,1,6,'CA','','',202606,6,3),
(2443,1,6,'ID','','',202606,6,3),
(2444,1,6,'ES','','',202606,4,2),
(2445,1,6,'BD','','',202606,3,2),
(2446,1,6,'MX','','',202606,6,3),
(2447,1,6,'ZA','','',202606,4,2),
(2448,1,6,'NL','','',202606,5,3),
(2449,1,6,'JP','','',202606,3,2),
(2450,1,6,'SA','','',202606,5,3),
(2451,1,6,'MY','','',202606,6,4),
(2452,1,6,'PL','','',202606,2,1),
(2453,1,6,'GH','','',202606,2,1),
(2454,1,6,'VN','','',202606,2,1),
(2455,1,6,'AR','','',202606,3,2),
(2456,1,6,'NZ','','',202606,2,1),
(2457,1,6,'SE','','',202606,2,1),
(2458,1,6,'US','','',202607,48,31),
(2459,1,6,'IN','','',202607,24,16),
(2460,1,6,'CN','','',202607,10,7),
(2461,1,6,'GB','','',202607,23,15),
(2462,1,6,'DE','','',202607,9,6),
(2463,1,6,'BR','','',202607,9,6),
(2464,1,6,'NG','','',202607,8,5),
(2465,1,6,'IR','','',202607,18,12),
(2466,1,6,'PK','','',202607,15,10),
(2467,1,6,'EG','','',202607,13,9),
(2468,1,6,'ET','','',202607,10,7),
(2469,1,6,'KE','','',202607,9,6),
(2470,1,6,'TR','','',202607,4,3),
(2471,1,6,'FR','','',202607,5,3),
(2472,1,6,'IT','','',202607,10,7),
(2473,1,6,'AU','','',202607,10,6),
(2474,1,6,'CA','','',202607,9,6),
(2475,1,6,'ID','','',202607,9,6),
(2476,1,6,'ES','','',202607,3,2),
(2477,1,6,'BD','','',202607,4,3),
(2478,1,6,'MX','','',202607,3,2),
(2479,1,6,'ZA','','',202607,5,3),
(2480,1,6,'NL','','',202607,3,2),
(2481,1,6,'JP','','',202607,5,3),
(2482,1,6,'SA','','',202607,5,3),
(2483,1,6,'MY','','',202607,4,3),
(2484,1,6,'PL','','',202607,2,1),
(2485,1,6,'GH','','',202607,4,2),
(2486,1,6,'VN','','',202607,2,1),
(2487,1,6,'AR','','',202607,3,2),
(2488,1,6,'NZ','','',202607,3,2),
(2489,1,6,'SE','','',202607,2,1),
(2490,1,6,'US','','',202608,49,31),
(2491,1,6,'IN','','',202608,16,10),
(2492,1,6,'CN','','',202608,18,11),
(2493,1,6,'GB','','',202608,20,13),
(2494,1,6,'DE','','',202608,10,6),
(2495,1,6,'BR','','',202608,20,12),
(2496,1,6,'NG','','',202608,11,7),
(2497,1,6,'IR','','',202608,9,6),
(2498,1,6,'PK','','',202608,6,4),
(2499,1,6,'EG','','',202608,7,4),
(2500,1,6,'ET','','',202608,9,5),
(2501,1,6,'KE','','',202608,6,4),
(2502,1,6,'TR','','',202608,8,5),
(2503,1,6,'FR','','',202608,9,6),
(2504,1,6,'IT','','',202608,6,4),
(2505,1,6,'AU','','',202608,5,3),
(2506,1,6,'CA','','',202608,7,4),
(2507,1,6,'ID','','',202608,5,3),
(2508,1,6,'ES','','',202608,4,2),
(2509,1,6,'BD','','',202608,4,2),
(2510,1,6,'MX','','',202608,4,3),
(2511,1,6,'ZA','','',202608,3,2),
(2512,1,6,'NL','','',202608,3,2),
(2513,1,6,'JP','','',202608,4,2),
(2514,1,6,'SA','','',202608,6,4),
(2515,1,6,'MY','','',202608,3,2),
(2516,1,6,'PL','','',202608,2,1),
(2517,1,6,'GH','','',202608,3,2),
(2518,1,6,'VN','','',202608,2,1),
(2519,1,6,'AR','','',202608,3,2),
(2520,1,6,'NZ','','',202608,2,1),
(2521,1,6,'SE','','',202608,3,2),
(2522,1,6,'US','','',202609,27,15),
(2523,1,6,'IN','','',202609,29,16),
(2524,1,6,'CN','','',202609,14,8),
(2525,1,6,'GB','','',202609,20,11),
(2526,1,6,'DE','','',202609,19,11),
(2527,1,6,'BR','','',202609,15,9),
(2528,1,6,'NG','','',202609,10,6),
(2529,1,6,'IR','','',202609,9,5),
(2530,1,6,'PK','','',202609,13,8),
(2531,1,6,'EG','','',202609,8,5),
(2532,1,6,'ET','','',202609,9,5),
(2533,1,6,'KE','','',202609,5,3),
(2534,1,6,'TR','','',202609,10,6),
(2535,1,6,'FR','','',202609,7,4),
(2536,1,6,'IT','','',202609,5,3),
(2537,1,6,'AU','','',202609,4,2),
(2538,1,6,'CA','','',202609,4,2),
(2539,1,6,'ID','','',202609,5,3),
(2540,1,6,'ES','','',202609,5,3),
(2541,1,6,'BD','','',202609,3,2),
(2542,1,6,'MX','','',202609,6,3),
(2543,1,6,'ZA','','',202609,6,3),
(2544,1,6,'NL','','',202609,5,3),
(2545,1,6,'JP','','',202609,5,3),
(2546,1,6,'SA','','',202609,5,3),
(2547,1,6,'MY','','',202609,5,3),
(2548,1,6,'PL','','',202609,2,1),
(2549,1,6,'GH','','',202609,2,1),
(2550,1,6,'VN','','',202609,3,2),
(2551,1,6,'AR','','',202609,2,1),
(2552,1,6,'NZ','','',202609,1,1),
(2553,1,6,'SE','','',202609,3,2),
(2554,1,6,'US','','',202610,9,5),
(2555,1,6,'IN','','',202610,5,3),
(2556,1,6,'CN','','',202610,3,1),
(2557,1,6,'GB','','',202610,6,3),
(2558,1,6,'DE','','',202610,4,2),
(2559,1,6,'BR','','',202610,4,2),
(2560,1,6,'NG','','',202610,3,2),
(2561,1,6,'IR','','',202610,2,1),
(2562,1,6,'PK','','',202610,3,2),
(2563,1,6,'EG','','',202610,2,1),
(2564,1,6,'ET','','',202610,1,1),
(2565,1,6,'KE','','',202610,2,1),
(2566,1,6,'TR','','',202610,1,1),
(2567,1,6,'FR','','',202610,3,1),
(2568,1,6,'IT','','',202610,2,1),
(2569,1,6,'AU','','',202610,3,1),
(2570,1,6,'CA','','',202610,2,1),
(2571,1,6,'ID','','',202610,1,1),
(2572,1,6,'ES','','',202610,1,1),
(2573,1,6,'BD','','',202610,1,1),
(2574,1,6,'MX','','',202610,1,1),
(2575,1,6,'NL','','',202610,1,1),
(2576,1,6,'SA','','',202610,1,1),
(2577,1,6,'MY','','',202610,1,1),
(2578,1,7,'US','','',202509,26,18),
(2579,1,7,'IN','','',202509,14,9),
(2580,1,7,'CN','','',202509,7,5),
(2581,1,7,'GB','','',202509,10,7),
(2582,1,7,'DE','','',202509,10,7),
(2583,1,7,'BR','','',202509,8,6),
(2584,1,7,'NG','','',202509,5,3),
(2585,1,7,'IR','','',202509,5,3),
(2586,1,7,'PK','','',202509,4,3),
(2587,1,7,'EG','','',202509,6,4),
(2588,1,7,'ET','','',202509,3,2),
(2589,1,7,'KE','','',202509,3,2),
(2590,1,7,'TR','','',202509,5,3),
(2591,1,7,'FR','','',202509,4,3),
(2592,1,7,'IT','','',202509,4,3),
(2593,1,7,'AU','','',202509,3,2),
(2594,1,7,'CA','','',202509,2,2),
(2595,1,7,'ID','','',202509,3,2),
(2596,1,7,'ES','','',202509,2,1),
(2597,1,7,'BD','','',202509,3,2),
(2598,1,7,'MX','','',202509,2,2),
(2599,1,7,'ZA','','',202509,2,2),
(2600,1,7,'NL','','',202509,4,2),
(2601,1,7,'JP','','',202509,2,1),
(2602,1,7,'SA','','',202509,2,1),
(2603,1,7,'MY','','',202509,4,3),
(2604,1,7,'PL','','',202509,1,1),
(2605,1,7,'GH','','',202509,1,1),
(2606,1,7,'VN','','',202509,2,1),
(2607,1,7,'AR','','',202509,2,1),
(2608,1,7,'NZ','','',202509,1,1),
(2609,1,7,'SE','','',202509,2,1),
(2610,1,7,'US','','',202510,9,5),
(2611,1,7,'IN','','',202510,8,5),
(2612,1,7,'CN','','',202510,12,7),
(2613,1,7,'GB','','',202510,9,5),
(2614,1,7,'DE','','',202510,7,4),
(2615,1,7,'BR','','',202510,4,2),
(2616,1,7,'NG','','',202510,5,3),
(2617,1,7,'IR','','',202510,5,3),
(2618,1,7,'PK','','',202510,3,2),
(2619,1,7,'EG','','',202510,5,3),
(2620,1,7,'ET','','',202510,4,3),
(2621,1,7,'KE','','',202510,4,3),
(2622,1,7,'TR','','',202510,4,3),
(2623,1,7,'FR','','',202510,3,2),
(2624,1,7,'IT','','',202510,3,2),
(2625,1,7,'AU','','',202510,4,2),
(2626,1,7,'CA','','',202510,4,2),
(2627,1,7,'ID','','',202510,3,2),
(2628,1,7,'ES','','',202510,2,1),
(2629,1,7,'BD','','',202510,2,1),
(2630,1,7,'MX','','',202510,2,1),
(2631,1,7,'ZA','','',202510,2,1),
(2632,1,7,'NL','','',202510,2,1),
(2633,1,7,'JP','','',202510,1,1),
(2634,1,7,'SA','','',202510,2,1),
(2635,1,7,'MY','','',202510,3,2),
(2636,1,7,'VN','','',202510,1,1),
(2637,1,7,'AR','','',202510,1,1),
(2638,1,7,'NZ','','',202510,1,1),
(2639,1,7,'SE','','',202510,2,1),
(2640,1,7,'US','','',202511,18,11),
(2641,1,7,'IN','','',202511,30,17),
(2642,1,7,'CN','','',202511,20,12),
(2643,1,7,'GB','','',202511,21,12),
(2644,1,7,'DE','','',202511,11,6),
(2645,1,7,'BR','','',202511,7,4),
(2646,1,7,'NG','','',202511,11,6),
(2647,1,7,'IR','','',202511,13,7),
(2648,1,7,'PK','','',202511,5,3),
(2649,1,7,'EG','','',202511,11,6),
(2650,1,7,'ET','','',202511,6,3),
(2651,1,7,'KE','','',202511,7,4),
(2652,1,7,'TR','','',202511,6,3),
(2653,1,7,'FR','','',202511,7,4),
(2654,1,7,'IT','','',202511,8,5),
(2655,1,7,'AU','','',202511,9,5),
(2656,1,7,'CA','','',202511,8,4),
(2657,1,7,'ID','','',202511,5,3),
(2658,1,7,'ES','','',202511,3,2),
(2659,1,7,'BD','','',202511,3,2),
(2660,1,7,'MX','','',202511,3,2),
(2661,1,7,'ZA','','',202511,4,2),
(2662,1,7,'NL','','',202511,6,3),
(2663,1,7,'JP','','',202511,5,3),
(2664,1,7,'SA','','',202511,7,4),
(2665,1,7,'MY','','',202511,3,2),
(2666,1,7,'PL','','',202511,2,1),
(2667,1,7,'GH','','',202511,1,1),
(2668,1,7,'VN','','',202511,2,1),
(2669,1,7,'AR','','',202511,1,1),
(2670,1,7,'NZ','','',202511,2,1),
(2671,1,7,'SE','','',202511,2,1),
(2672,1,7,'US','','',202512,22,10),
(2673,1,7,'IN','','',202512,13,6),
(2674,1,7,'CN','','',202512,8,4),
(2675,1,7,'GB','','',202512,15,6),
(2676,1,7,'DE','','',202512,14,6),
(2677,1,7,'BR','','',202512,8,4),
(2678,1,7,'NG','','',202512,10,4),
(2679,1,7,'IR','','',202512,10,4),
(2680,1,7,'PK','','',202512,8,3),
(2681,1,7,'EG','','',202512,4,2),
(2682,1,7,'ET','','',202512,7,3),
(2683,1,7,'KE','','',202512,4,2),
(2684,1,7,'TR','','',202512,7,3),
(2685,1,7,'FR','','',202512,3,1),
(2686,1,7,'IT','','',202512,5,2),
(2687,1,7,'AU','','',202512,4,2),
(2688,1,7,'CA','','',202512,5,2),
(2689,1,7,'ID','','',202512,5,2),
(2690,1,7,'ES','','',202512,4,2),
(2691,1,7,'BD','','',202512,3,2),
(2692,1,7,'MX','','',202512,4,2),
(2693,1,7,'ZA','','',202512,2,1),
(2694,1,7,'NL','','',202512,2,1),
(2695,1,7,'JP','','',202512,4,2),
(2696,1,7,'SA','','',202512,4,2),
(2697,1,7,'MY','','',202512,4,2),
(2698,1,7,'GH','','',202512,1,1),
(2699,1,7,'VN','','',202512,1,1),
(2700,1,7,'SE','','',202512,2,1),
(2701,1,7,'US','','',202601,16,8),
(2702,1,7,'IN','','',202601,15,8),
(2703,1,7,'CN','','',202601,8,4),
(2704,1,7,'GB','','',202601,12,6),
(2705,1,7,'DE','','',202601,12,6),
(2706,1,7,'BR','','',202601,9,5),
(2707,1,7,'NG','','',202601,10,5),
(2708,1,7,'IR','','',202601,5,3),
(2709,1,7,'PK','','',202601,9,5),
(2710,1,7,'EG','','',202601,8,4),
(2711,1,7,'ET','','',202601,6,3),
(2712,1,7,'KE','','',202601,6,3),
(2713,1,7,'TR','','',202601,3,1),
(2714,1,7,'FR','','',202601,6,3),
(2715,1,7,'IT','','',202601,3,1),
(2716,1,7,'AU','','',202601,3,2),
(2717,1,7,'CA','','',202601,4,2),
(2718,1,7,'ID','','',202601,5,3),
(2719,1,7,'ES','','',202601,3,2),
(2720,1,7,'BD','','',202601,3,1),
(2721,1,7,'MX','','',202601,4,2),
(2722,1,7,'ZA','','',202601,3,2),
(2723,1,7,'NL','','',202601,2,1),
(2724,1,7,'JP','','',202601,2,1),
(2725,1,7,'SA','','',202601,3,2),
(2726,1,7,'MY','','',202601,3,2),
(2727,1,7,'PL','','',202601,1,1),
(2728,1,7,'GH','','',202601,2,1),
(2729,1,7,'VN','','',202601,1,1),
(2730,1,7,'AR','','',202601,2,1),
(2731,1,7,'NZ','','',202601,2,1),
(2732,1,7,'US','','',202602,33,18),
(2733,1,7,'IN','','',202602,30,16),
(2734,1,7,'CN','','',202602,21,11),
(2735,1,7,'GB','','',202602,9,5),
(2736,1,7,'DE','','',202602,15,8),
(2737,1,7,'BR','','',202602,15,8),
(2738,1,7,'NG','','',202602,6,3),
(2739,1,7,'IR','','',202602,5,3),
(2740,1,7,'PK','','',202602,10,6),
(2741,1,7,'EG','','',202602,11,6),
(2742,1,7,'ET','','',202602,7,4),
(2743,1,7,'KE','','',202602,8,4),
(2744,1,7,'TR','','',202602,3,2),
(2745,1,7,'FR','','',202602,8,4),
(2746,1,7,'IT','','',202602,7,4),
(2747,1,7,'AU','','',202602,6,3),
(2748,1,7,'CA','','',202602,3,2),
(2749,1,7,'ID','','',202602,8,4),
(2750,1,7,'ES','','',202602,4,2),
(2751,1,7,'BD','','',202602,3,1),
(2752,1,7,'MX','','',202602,3,1),
(2753,1,7,'ZA','','',202602,4,2),
(2754,1,7,'NL','','',202602,2,1),
(2755,1,7,'JP','','',202602,4,2),
(2756,1,7,'SA','','',202602,3,2),
(2757,1,7,'MY','','',202602,5,3),
(2758,1,7,'PL','','',202602,1,1),
(2759,1,7,'GH','','',202602,2,1),
(2760,1,7,'VN','','',202602,2,1),
(2761,1,7,'AR','','',202602,1,1),
(2762,1,7,'NZ','','',202602,3,1),
(2763,1,7,'SE','','',202602,3,1),
(2764,1,7,'US','','',202603,35,21),
(2765,1,7,'IN','','',202603,19,11),
(2766,1,7,'CN','','',202603,23,14),
(2767,1,7,'GB','','',202603,8,5),
(2768,1,7,'DE','','',202603,18,11),
(2769,1,7,'BR','','',202603,18,11),
(2770,1,7,'NG','','',202603,9,5),
(2771,1,7,'IR','','',202603,12,8),
(2772,1,7,'PK','','',202603,11,7),
(2773,1,7,'EG','','',202603,5,3),
(2774,1,7,'ET','','',202603,9,5),
(2775,1,7,'KE','','',202603,8,5),
(2776,1,7,'TR','','',202603,6,4),
(2777,1,7,'FR','','',202603,4,2),
(2778,1,7,'IT','','',202603,8,5),
(2779,1,7,'AU','','',202603,6,3),
(2780,1,7,'CA','','',202603,5,3),
(2781,1,7,'ID','','',202603,8,5),
(2782,1,7,'ES','','',202603,3,2),
(2783,1,7,'BD','','',202603,4,2),
(2784,1,7,'MX','','',202603,5,3),
(2785,1,7,'ZA','','',202603,5,3),
(2786,1,7,'NL','','',202603,5,3),
(2787,1,7,'JP','','',202603,3,2),
(2788,1,7,'SA','','',202603,5,3),
(2789,1,7,'MY','','',202603,4,2),
(2790,1,7,'PL','','',202603,2,1),
(2791,1,7,'GH','','',202603,2,1),
(2792,1,7,'VN','','',202603,2,1),
(2793,1,7,'AR','','',202603,3,2),
(2794,1,7,'NZ','','',202603,3,2),
(2795,1,7,'SE','','',202603,3,2),
(2796,1,7,'US','','',202604,21,9),
(2797,1,7,'IN','','',202604,21,9),
(2798,1,7,'CN','','',202604,14,6),
(2799,1,7,'GB','','',202604,20,9),
(2800,1,7,'DE','','',202604,21,9),
(2801,1,7,'BR','','',202604,9,4),
(2802,1,7,'NG','','',202604,15,6),
(2803,1,7,'IR','','',202604,13,6),
(2804,1,7,'PK','','',202604,7,3),
(2805,1,7,'EG','','',202604,14,6),
(2806,1,7,'ET','','',202604,10,4),
(2807,1,7,'KE','','',202604,6,3),
(2808,1,7,'TR','','',202604,8,4),
(2809,1,7,'FR','','',202604,8,3),
(2810,1,7,'IT','','',202604,10,4),
(2811,1,7,'AU','','',202604,11,5),
(2812,1,7,'CA','','',202604,9,4),
(2813,1,7,'ID','','',202604,8,4),
(2814,1,7,'ES','','',202604,5,2),
(2815,1,7,'BD','','',202604,7,3),
(2816,1,7,'MX','','',202604,4,2),
(2817,1,7,'ZA','','',202604,7,3),
(2818,1,7,'NL','','',202604,3,1),
(2819,1,7,'JP','','',202604,5,2),
(2820,1,7,'SA','','',202604,4,2),
(2821,1,7,'MY','','',202604,7,3),
(2822,1,7,'PL','','',202604,2,1),
(2823,1,7,'GH','','',202604,3,1),
(2824,1,7,'VN','','',202604,1,1),
(2825,1,7,'AR','','',202604,4,2),
(2826,1,7,'NZ','','',202604,2,1),
(2827,1,7,'SE','','',202604,1,1),
(2828,1,7,'US','','',202605,52,30),
(2829,1,7,'IN','','',202605,19,11),
(2830,1,7,'CN','','',202605,11,6),
(2831,1,7,'GB','','',202605,27,15),
(2832,1,7,'DE','','',202605,20,11),
(2833,1,7,'BR','','',202605,18,10),
(2834,1,7,'NG','','',202605,11,6),
(2835,1,7,'IR','','',202605,8,4),
(2836,1,7,'PK','','',202605,8,5),
(2837,1,7,'EG','','',202605,10,6),
(2838,1,7,'ET','','',202605,11,6),
(2839,1,7,'KE','','',202605,7,4),
(2840,1,7,'TR','','',202605,12,7),
(2841,1,7,'FR','','',202605,9,5),
(2842,1,7,'IT','','',202605,8,5),
(2843,1,7,'AU','','',202605,10,6),
(2844,1,7,'CA','','',202605,8,5),
(2845,1,7,'ID','','',202605,6,4),
(2846,1,7,'ES','','',202605,4,2),
(2847,1,7,'BD','','',202605,7,4),
(2848,1,7,'MX','','',202605,5,3),
(2849,1,7,'ZA','','',202605,6,3),
(2850,1,7,'NL','','',202605,8,4),
(2851,1,7,'JP','','',202605,4,3),
(2852,1,7,'SA','','',202605,3,2),
(2853,1,7,'MY','','',202605,3,2),
(2854,1,7,'PL','','',202605,2,1),
(2855,1,7,'GH','','',202605,2,1),
(2856,1,7,'VN','','',202605,3,2),
(2857,1,7,'AR','','',202605,3,2),
(2858,1,7,'NZ','','',202605,3,1),
(2859,1,7,'SE','','',202605,2,1),
(2860,1,7,'US','','',202606,21,11),
(2861,1,7,'IN','','',202606,36,20),
(2862,1,7,'CN','','',202606,26,14),
(2863,1,7,'GB','','',202606,23,13),
(2864,1,7,'DE','','',202606,14,8),
(2865,1,7,'BR','','',202606,18,10),
(2866,1,7,'NG','','',202606,10,5),
(2867,1,7,'IR','','',202606,17,9),
(2868,1,7,'PK','','',202606,9,5),
(2869,1,7,'EG','','',202606,10,5),
(2870,1,7,'ET','','',202606,7,4),
(2871,1,7,'KE','','',202606,4,2),
(2872,1,7,'TR','','',202606,6,3),
(2873,1,7,'FR','','',202606,11,6),
(2874,1,7,'IT','','',202606,5,3),
(2875,1,7,'AU','','',202606,6,3),
(2876,1,7,'CA','','',202606,5,3),
(2877,1,7,'ID','','',202606,8,4),
(2878,1,7,'ES','','',202606,5,3),
(2879,1,7,'BD','','',202606,4,2),
(2880,1,7,'MX','','',202606,4,2),
(2881,1,7,'ZA','','',202606,7,4),
(2882,1,7,'NL','','',202606,5,3),
(2883,1,7,'JP','','',202606,3,2),
(2884,1,7,'SA','','',202606,7,4),
(2885,1,7,'MY','','',202606,4,2),
(2886,1,7,'PL','','',202606,2,1),
(2887,1,7,'GH','','',202606,4,2),
(2888,1,7,'VN','','',202606,3,2),
(2889,1,7,'AR','','',202606,3,2),
(2890,1,7,'NZ','','',202606,3,2),
(2891,1,7,'SE','','',202606,3,2),
(2892,1,7,'US','','',202607,42,23),
(2893,1,7,'IN','','',202607,29,16),
(2894,1,7,'CN','','',202607,20,11),
(2895,1,7,'GB','','',202607,23,13),
(2896,1,7,'DE','','',202607,12,6),
(2897,1,7,'BR','','',202607,22,12),
(2898,1,7,'NG','','',202607,18,10),
(2899,1,7,'IR','','',202607,10,5),
(2900,1,7,'PK','','',202607,15,8),
(2901,1,7,'EG','','',202607,12,6),
(2902,1,7,'ET','','',202607,13,7),
(2903,1,7,'KE','','',202607,6,3),
(2904,1,7,'TR','','',202607,11,6),
(2905,1,7,'FR','','',202607,14,8),
(2906,1,7,'IT','','',202607,7,4),
(2907,1,7,'AU','','',202607,9,5),
(2908,1,7,'CA','','',202607,6,4),
(2909,1,7,'ID','','',202607,6,3),
(2910,1,7,'ES','','',202607,7,4),
(2911,1,7,'BD','','',202607,7,4),
(2912,1,7,'MX','','',202607,7,4),
(2913,1,7,'ZA','','',202607,7,4),
(2914,1,7,'NL','','',202607,8,4),
(2915,1,7,'JP','','',202607,7,4),
(2916,1,7,'SA','','',202607,4,2),
(2917,1,7,'MY','','',202607,8,4),
(2918,1,7,'PL','','',202607,2,1),
(2919,1,7,'GH','','',202607,4,2),
(2920,1,7,'VN','','',202607,3,1),
(2921,1,7,'AR','','',202607,2,1),
(2922,1,7,'NZ','','',202607,5,3),
(2923,1,7,'SE','','',202607,4,2),
(2924,1,7,'US','','',202608,20,11),
(2925,1,7,'IN','','',202608,25,13),
(2926,1,7,'CN','','',202608,19,11),
(2927,1,7,'GB','','',202608,16,9),
(2928,1,7,'DE','','',202608,17,9),
(2929,1,7,'BR','','',202608,9,5),
(2930,1,7,'NG','','',202608,12,7),
(2931,1,7,'IR','','',202608,11,6),
(2932,1,7,'PK','','',202608,6,3),
(2933,1,7,'EG','','',202608,11,6),
(2934,1,7,'ET','','',202608,4,2),
(2935,1,7,'KE','','',202608,5,3),
(2936,1,7,'TR','','',202608,8,4),
(2937,1,7,'FR','','',202608,8,5),
(2938,1,7,'IT','','',202608,6,4),
(2939,1,7,'AU','','',202608,4,2),
(2940,1,7,'CA','','',202608,10,5),
(2941,1,7,'ID','','',202608,5,3),
(2942,1,7,'ES','','',202608,3,2),
(2943,1,7,'BD','','',202608,5,3),
(2944,1,7,'MX','','',202608,4,2),
(2945,1,7,'ZA','','',202608,3,2),
(2946,1,7,'NL','','',202608,2,1),
(2947,1,7,'JP','','',202608,4,2),
(2948,1,7,'SA','','',202608,4,2),
(2949,1,7,'MY','','',202608,4,2),
(2950,1,7,'PL','','',202608,3,1),
(2951,1,7,'GH','','',202608,3,1),
(2952,1,7,'VN','','',202608,3,2),
(2953,1,7,'AR','','',202608,2,1),
(2954,1,7,'NZ','','',202608,2,1),
(2955,1,7,'SE','','',202608,2,1),
(2956,1,7,'US','','',202609,43,23),
(2957,1,7,'IN','','',202609,34,18),
(2958,1,7,'CN','','',202609,16,9),
(2959,1,7,'GB','','',202609,14,7),
(2960,1,7,'DE','','',202609,19,10),
(2961,1,7,'BR','','',202609,13,7),
(2962,1,7,'NG','','',202609,19,10),
(2963,1,7,'IR','','',202609,8,4),
(2964,1,7,'PK','','',202609,16,9),
(2965,1,7,'EG','','',202609,8,4),
(2966,1,7,'ET','','',202609,7,4),
(2967,1,7,'KE','','',202609,10,5),
(2968,1,7,'TR','','',202609,11,6),
(2969,1,7,'FR','','',202609,10,5),
(2970,1,7,'IT','','',202609,11,6),
(2971,1,7,'AU','','',202609,12,6),
(2972,1,7,'CA','','',202609,9,5),
(2973,1,7,'ID','','',202609,6,3),
(2974,1,7,'ES','','',202609,6,3),
(2975,1,7,'BD','','',202609,6,3),
(2976,1,7,'MX','','',202609,5,3),
(2977,1,7,'ZA','','',202609,7,4),
(2978,1,7,'NL','','',202609,7,4),
(2979,1,7,'JP','','',202609,8,4),
(2980,1,7,'SA','','',202609,4,2),
(2981,1,7,'MY','','',202609,7,4),
(2982,1,7,'PL','','',202609,1,1),
(2983,1,7,'GH','','',202609,3,1),
(2984,1,7,'VN','','',202609,3,1),
(2985,1,7,'AR','','',202609,2,1),
(2986,1,7,'NZ','','',202609,2,1),
(2987,1,7,'SE','','',202609,2,1),
(2988,1,7,'US','','',202610,5,3),
(2989,1,7,'IN','','',202610,8,4),
(2990,1,7,'CN','','',202610,6,3),
(2991,1,7,'GB','','',202610,7,4),
(2992,1,7,'DE','','',202610,4,2),
(2993,1,7,'BR','','',202610,2,1),
(2994,1,7,'NG','','',202610,5,3),
(2995,1,7,'IR','','',202610,4,3),
(2996,1,7,'PK','','',202610,4,2),
(2997,1,7,'EG','','',202610,3,2),
(2998,1,7,'ET','','',202610,3,2),
(2999,1,7,'KE','','',202610,2,1),
(3000,1,7,'TR','','',202610,3,1),
(3001,1,7,'FR','','',202610,1,1),
(3002,1,7,'IT','','',202610,2,1),
(3003,1,7,'AU','','',202610,1,1),
(3004,1,7,'CA','','',202610,2,1),
(3005,1,7,'ID','','',202610,3,1),
(3006,1,7,'BD','','',202610,1,1),
(3007,1,7,'MX','','',202610,1,1),
(3008,1,7,'NL','','',202610,1,1),
(3009,1,7,'JP','','',202610,2,1),
(3010,1,7,'SA','','',202610,1,1),
(3011,1,7,'MY','','',202610,1,1),
(3012,1,8,'US','','',202509,14,6),
(3013,1,8,'IN','','',202509,7,3),
(3014,1,8,'CN','','',202509,5,2),
(3015,1,8,'GB','','',202509,5,2),
(3016,1,8,'DE','','',202509,7,3),
(3017,1,8,'BR','','',202509,6,3),
(3018,1,8,'NG','','',202509,3,1),
(3019,1,8,'IR','','',202509,4,2),
(3020,1,8,'PK','','',202509,6,3),
(3021,1,8,'EG','','',202509,3,1),
(3022,1,8,'ET','','',202509,2,1),
(3023,1,8,'KE','','',202509,3,2),
(3024,1,8,'TR','','',202509,4,2),
(3025,1,8,'FR','','',202509,2,1),
(3026,1,8,'IT','','',202509,3,1),
(3027,1,8,'AU','','',202509,3,2),
(3028,1,8,'CA','','',202509,2,1),
(3029,1,8,'ID','','',202509,2,1),
(3030,1,8,'ES','','',202509,2,1),
(3031,1,8,'BD','','',202509,2,1),
(3032,1,8,'MX','','',202509,2,1),
(3033,1,8,'ZA','','',202509,2,1),
(3034,1,8,'NL','','',202509,2,1),
(3035,1,8,'JP','','',202509,2,1),
(3036,1,8,'SA','','',202509,2,1),
(3037,1,8,'MY','','',202509,2,1),
(3038,1,8,'SE','','',202509,1,1),
(3039,1,8,'US','','',202510,10,6),
(3040,1,8,'IN','','',202510,9,5),
(3041,1,8,'CN','','',202510,7,4),
(3042,1,8,'GB','','',202510,5,3),
(3043,1,8,'DE','','',202510,6,4),
(3044,1,8,'BR','','',202510,4,2),
(3045,1,8,'NG','','',202510,2,1),
(3046,1,8,'IR','','',202510,4,2),
(3047,1,8,'PK','','',202510,4,2),
(3048,1,8,'EG','','',202510,3,2),
(3049,1,8,'ET','','',202510,3,2),
(3050,1,8,'KE','','',202510,2,1),
(3051,1,8,'TR','','',202510,1,1),
(3052,1,8,'FR','','',202510,2,1),
(3053,1,8,'IT','','',202510,2,2),
(3054,1,8,'AU','','',202510,3,2),
(3055,1,8,'CA','','',202510,1,1),
(3056,1,8,'ID','','',202510,1,1),
(3057,1,8,'ES','','',202510,1,1),
(3058,1,8,'BD','','',202510,1,1),
(3059,1,8,'MX','','',202510,2,1),
(3060,1,8,'ZA','','',202510,1,1),
(3061,1,8,'NL','','',202510,1,1),
(3062,1,8,'SA','','',202510,2,1),
(3063,1,8,'MY','','',202510,1,1),
(3064,1,8,'US','','',202511,12,7),
(3065,1,8,'IN','','',202511,11,6),
(3066,1,8,'CN','','',202511,6,3),
(3067,1,8,'GB','','',202511,8,4),
(3068,1,8,'DE','','',202511,5,3),
(3069,1,8,'BR','','',202511,7,4),
(3070,1,8,'NG','','',202511,5,3),
(3071,1,8,'IR','','',202511,5,3),
(3072,1,8,'PK','','',202511,5,3),
(3073,1,8,'EG','','',202511,4,2),
(3074,1,8,'ET','','',202511,2,1),
(3075,1,8,'KE','','',202511,4,2),
(3076,1,8,'TR','','',202511,4,2),
(3077,1,8,'FR','','',202511,3,1),
(3078,1,8,'IT','','',202511,4,2),
(3079,1,8,'AU','','',202511,3,2),
(3080,1,8,'CA','','',202511,2,1),
(3081,1,8,'ID','','',202511,4,2),
(3082,1,8,'ES','','',202511,2,1),
(3083,1,8,'BD','','',202511,2,1),
(3084,1,8,'MX','','',202511,3,2),
(3085,1,8,'ZA','','',202511,1,1),
(3086,1,8,'NL','','',202511,3,2),
(3087,1,8,'JP','','',202511,3,1),
(3088,1,8,'SA','','',202511,1,1),
(3089,1,8,'MY','','',202511,3,2),
(3090,1,8,'PL','','',202511,1,1),
(3091,1,8,'GH','','',202511,1,1),
(3092,1,8,'AR','','',202511,1,1),
(3093,1,8,'NZ','','',202511,2,1),
(3094,1,8,'SE','','',202511,2,1),
(3095,1,8,'US','','',202512,28,15),
(3096,1,8,'IN','','',202512,24,13),
(3097,1,8,'CN','','',202512,8,5),
(3098,1,8,'GB','','',202512,14,8),
(3099,1,8,'DE','','',202512,8,4),
(3100,1,8,'BR','','',202512,13,7),
(3101,1,8,'NG','','',202512,9,5),
(3102,1,8,'IR','','',202512,5,3),
(3103,1,8,'PK','','',202512,5,3),
(3104,1,8,'EG','','',202512,7,4),
(3105,1,8,'ET','','',202512,3,2),
(3106,1,8,'KE','','',202512,3,2),
(3107,1,8,'TR','','',202512,3,2),
(3108,1,8,'FR','','',202512,7,4),
(3109,1,8,'IT','','',202512,3,2),
(3110,1,8,'AU','','',202512,3,2),
(3111,1,8,'CA','','',202512,4,2),
(3112,1,8,'ID','','',202512,7,4),
(3113,1,8,'ES','','',202512,2,1),
(3114,1,8,'BD','','',202512,2,1),
(3115,1,8,'MX','','',202512,3,2),
(3116,1,8,'ZA','','',202512,4,2),
(3117,1,8,'NL','','',202512,2,1),
(3118,1,8,'JP','','',202512,4,2),
(3119,1,8,'SA','','',202512,4,2),
(3120,1,8,'MY','','',202512,2,1),
(3121,1,8,'PL','','',202512,2,1),
(3122,1,8,'GH','','',202512,2,1),
(3123,1,8,'VN','','',202512,2,1),
(3124,1,8,'AR','','',202512,2,1),
(3125,1,8,'NZ','','',202512,1,1),
(3126,1,8,'SE','','',202512,2,1),
(3127,1,8,'US','','',202601,11,6),
(3128,1,8,'IN','','',202601,14,8),
(3129,1,8,'CN','','',202601,11,6),
(3130,1,8,'GB','','',202601,9,5),
(3131,1,8,'DE','','',202601,4,2),
(3132,1,8,'BR','','',202601,5,3),
(3133,1,8,'NG','','',202601,3,2),
(3134,1,8,'IR','','',202601,7,4),
(3135,1,8,'PK','','',202601,3,2),
(3136,1,8,'EG','','',202601,4,2),
(3137,1,8,'ET','','',202601,2,1),
(3138,1,8,'KE','','',202601,3,1),
(3139,1,8,'TR','','',202601,4,2),
(3140,1,8,'FR','','',202601,3,2),
(3141,1,8,'IT','','',202601,2,1),
(3142,1,8,'AU','','',202601,4,2),
(3143,1,8,'CA','','',202601,3,2),
(3144,1,8,'ID','','',202601,3,2),
(3145,1,8,'ES','','',202601,3,2),
(3146,1,8,'BD','','',202601,2,1),
(3147,1,8,'MX','','',202601,1,1),
(3148,1,8,'ZA','','',202601,2,1),
(3149,1,8,'NL','','',202601,2,1),
(3150,1,8,'JP','','',202601,3,2),
(3151,1,8,'SA','','',202601,3,2),
(3152,1,8,'MY','','',202601,3,1),
(3153,1,8,'PL','','',202601,1,1),
(3154,1,8,'GH','','',202601,1,1),
(3155,1,8,'VN','','',202601,1,1),
(3156,1,8,'US','','',202602,12,7),
(3157,1,8,'IN','','',202602,13,7),
(3158,1,8,'CN','','',202602,7,4),
(3159,1,8,'GB','','',202602,9,5),
(3160,1,8,'DE','','',202602,6,4),
(3161,1,8,'BR','','',202602,4,2),
(3162,1,8,'NG','','',202602,7,4),
(3163,1,8,'IR','','',202602,6,3),
(3164,1,8,'PK','','',202602,3,2),
(3165,1,8,'EG','','',202602,4,3),
(3166,1,8,'ET','','',202602,3,2),
(3167,1,8,'KE','','',202602,5,3),
(3168,1,8,'TR','','',202602,3,2),
(3169,1,8,'FR','','',202602,2,1),
(3170,1,8,'IT','','',202602,4,2),
(3171,1,8,'AU','','',202602,2,1),
(3172,1,8,'CA','','',202602,3,1),
(3173,1,8,'ID','','',202602,3,2),
(3174,1,8,'ES','','',202602,2,1),
(3175,1,8,'BD','','',202602,2,1),
(3176,1,8,'MX','','',202602,3,2),
(3177,1,8,'ZA','','',202602,2,1),
(3178,1,8,'NL','','',202602,2,1),
(3179,1,8,'JP','','',202602,1,1),
(3180,1,8,'SA','','',202602,2,1),
(3181,1,8,'MY','','',202602,3,2),
(3182,1,8,'PL','','',202602,1,1),
(3183,1,8,'GH','','',202602,1,1),
(3184,1,8,'VN','','',202602,1,1),
(3185,1,8,'AR','','',202602,2,1),
(3186,1,8,'NZ','','',202602,1,1),
(3187,1,8,'SE','','',202602,1,1),
(3188,1,8,'US','','',202603,21,9),
(3189,1,8,'IN','','',202603,21,9),
(3190,1,8,'CN','','',202603,14,6),
(3191,1,8,'GB','','',202603,9,4),
(3192,1,8,'DE','','',202603,5,2),
(3193,1,8,'BR','','',202603,7,3),
(3194,1,8,'NG','','',202603,7,3),
(3195,1,8,'IR','','',202603,9,4),
(3196,1,8,'PK','','',202603,6,3),
(3197,1,8,'EG','','',202603,6,2),
(3198,1,8,'ET','','',202603,6,3),
(3199,1,8,'KE','','',202603,5,2),
(3200,1,8,'TR','','',202603,4,2),
(3201,1,8,'FR','','',202603,3,1),
(3202,1,8,'IT','','',202603,6,3),
(3203,1,8,'AU','','',202603,4,2),
(3204,1,8,'CA','','',202603,2,1),
(3205,1,8,'ID','','',202603,5,2),
(3206,1,8,'ES','','',202603,2,1),
(3207,1,8,'BD','','',202603,4,2),
(3208,1,8,'MX','','',202603,2,1),
(3209,1,8,'ZA','','',202603,1,1),
(3210,1,8,'NL','','',202603,3,1),
(3211,1,8,'JP','','',202603,3,1),
(3212,1,8,'SA','','',202603,3,1),
(3213,1,8,'MY','','',202603,2,1),
(3214,1,8,'GH','','',202603,1,1),
(3215,1,8,'AR','','',202603,1,1),
(3216,1,8,'SE','','',202603,1,1),
(3217,1,8,'US','','',202604,19,11),
(3218,1,8,'IN','','',202604,16,9),
(3219,1,8,'CN','','',202604,10,6),
(3220,1,8,'GB','','',202604,10,6),
(3221,1,8,'DE','','',202604,9,5),
(3222,1,8,'BR','','',202604,7,4),
(3223,1,8,'NG','','',202604,9,5),
(3224,1,8,'IR','','',202604,7,4),
(3225,1,8,'PK','','',202604,6,4),
(3226,1,8,'EG','','',202604,4,2),
(3227,1,8,'ET','','',202604,5,3),
(3228,1,8,'KE','','',202604,3,2),
(3229,1,8,'TR','','',202604,3,2),
(3230,1,8,'FR','','',202604,4,2),
(3231,1,8,'IT','','',202604,3,2),
(3232,1,8,'AU','','',202604,4,2),
(3233,1,8,'CA','','',202604,6,3),
(3234,1,8,'ID','','',202604,6,3),
(3235,1,8,'ES','','',202604,2,1),
(3236,1,8,'BD','','',202604,4,2),
(3237,1,8,'MX','','',202604,2,1),
(3238,1,8,'ZA','','',202604,2,1),
(3239,1,8,'NL','','',202604,3,2),
(3240,1,8,'JP','','',202604,3,2),
(3241,1,8,'SA','','',202604,4,2),
(3242,1,8,'MY','','',202604,2,1),
(3243,1,8,'PL','','',202604,2,1),
(3244,1,8,'GH','','',202604,2,1),
(3245,1,8,'VN','','',202604,2,1),
(3246,1,8,'AR','','',202604,2,1),
(3247,1,8,'NZ','','',202604,1,1),
(3248,1,8,'SE','','',202604,1,1),
(3249,1,8,'US','','',202605,21,13),
(3250,1,8,'IN','','',202605,26,16),
(3251,1,8,'CN','','',202605,16,10),
(3252,1,8,'GB','','',202605,10,6),
(3253,1,8,'DE','','',202605,12,8),
(3254,1,8,'BR','','',202605,14,9),
(3255,1,8,'NG','','',202605,9,6),
(3256,1,8,'IR','','',202605,12,7),
(3257,1,8,'PK','','',202605,5,3),
(3258,1,8,'EG','','',202605,8,5),
(3259,1,8,'ET','','',202605,6,4),
(3260,1,8,'KE','','',202605,6,4),
(3261,1,8,'TR','','',202605,7,4),
(3262,1,8,'FR','','',202605,3,2),
(3263,1,8,'IT','','',202605,7,4),
(3264,1,8,'AU','','',202605,4,3),
(3265,1,8,'CA','','',202605,3,2),
(3266,1,8,'ID','','',202605,5,3),
(3267,1,8,'ES','','',202605,3,2),
(3268,1,8,'BD','','',202605,4,2),
(3269,1,8,'MX','','',202605,4,2),
(3270,1,8,'ZA','','',202605,5,3),
(3271,1,8,'NL','','',202605,4,3),
(3272,1,8,'JP','','',202605,5,3),
(3273,1,8,'SA','','',202605,2,1),
(3274,1,8,'MY','','',202605,5,3),
(3275,1,8,'PL','','',202605,2,1),
(3276,1,8,'GH','','',202605,2,1),
(3277,1,8,'VN','','',202605,2,1),
(3278,1,8,'AR','','',202605,2,2),
(3279,1,8,'NZ','','',202605,2,1),
(3280,1,8,'SE','','',202605,1,1),
(3281,1,8,'US','','',202606,16,9),
(3282,1,8,'IN','','',202606,16,9),
(3283,1,8,'CN','','',202606,13,8),
(3284,1,8,'GB','','',202606,15,9),
(3285,1,8,'DE','','',202606,13,7),
(3286,1,8,'BR','','',202606,10,6),
(3287,1,8,'NG','','',202606,5,3),
(3288,1,8,'IR','','',202606,5,3),
(3289,1,8,'PK','','',202606,7,4),
(3290,1,8,'EG','','',202606,5,3),
(3291,1,8,'ET','','',202606,6,4),
(3292,1,8,'KE','','',202606,5,3),
(3293,1,8,'TR','','',202606,7,4),
(3294,1,8,'FR','','',202606,3,2),
(3295,1,8,'IT','','',202606,4,2),
(3296,1,8,'AU','','',202606,3,2),
(3297,1,8,'CA','','',202606,7,4),
(3298,1,8,'ID','','',202606,2,1),
(3299,1,8,'ES','','',202606,2,1),
(3300,1,8,'BD','','',202606,3,2),
(3301,1,8,'MX','','',202606,2,1),
(3302,1,8,'ZA','','',202606,2,1),
(3303,1,8,'NL','','',202606,4,2),
(3304,1,8,'JP','','',202606,3,2),
(3305,1,8,'SA','','',202606,4,2),
(3306,1,8,'MY','','',202606,3,2),
(3307,1,8,'PL','','',202606,1,1),
(3308,1,8,'GH','','',202606,1,1),
(3309,1,8,'VN','','',202606,2,1),
(3310,1,8,'AR','','',202606,1,1),
(3311,1,8,'NZ','','',202606,2,1),
(3312,1,8,'SE','','',202606,1,1),
(3313,1,8,'US','','',202607,25,13),
(3314,1,8,'IN','','',202607,19,10),
(3315,1,8,'CN','','',202607,14,7),
(3316,1,8,'GB','','',202607,12,6),
(3317,1,8,'DE','','',202607,6,3),
(3318,1,8,'BR','','',202607,9,5),
(3319,1,8,'NG','','',202607,6,3),
(3320,1,8,'IR','','',202607,8,4),
(3321,1,8,'PK','','',202607,6,3),
(3322,1,8,'EG','','',202607,4,2),
(3323,1,8,'ET','','',202607,3,2),
(3324,1,8,'KE','','',202607,4,2),
(3325,1,8,'TR','','',202607,3,2),
(3326,1,8,'FR','','',202607,3,1),
(3327,1,8,'IT','','',202607,3,1),
(3328,1,8,'AU','','',202607,3,1),
(3329,1,8,'CA','','',202607,2,1),
(3330,1,8,'ID','','',202607,5,3),
(3331,1,8,'ES','','',202607,3,2),
(3332,1,8,'BD','','',202607,4,2),
(3333,1,8,'MX','','',202607,2,1),
(3334,1,8,'ZA','','',202607,4,2),
(3335,1,8,'NL','','',202607,2,1),
(3336,1,8,'JP','','',202607,2,1),
(3337,1,8,'SA','','',202607,3,1),
(3338,1,8,'MY','','',202607,2,1),
(3339,1,8,'PL','','',202607,2,1),
(3340,1,8,'GH','','',202607,1,1),
(3341,1,8,'VN','','',202607,2,1),
(3342,1,8,'NZ','','',202607,2,1),
(3343,1,8,'SE','','',202607,2,1),
(3344,1,8,'US','','',202608,38,25),
(3345,1,8,'IN','','',202608,32,21),
(3346,1,8,'CN','','',202608,9,6),
(3347,1,8,'GB','','',202608,10,6),
(3348,1,8,'DE','','',202608,15,9),
(3349,1,8,'BR','','',202608,15,10),
(3350,1,8,'NG','','',202608,5,4),
(3351,1,8,'IR','','',202608,5,3),
(3352,1,8,'PK','','',202608,10,7),
(3353,1,8,'EG','','',202608,8,5),
(3354,1,8,'ET','','',202608,6,4),
(3355,1,8,'KE','','',202608,7,4),
(3356,1,8,'TR','','',202608,7,5),
(3357,1,8,'FR','','',202608,8,5),
(3358,1,8,'IT','','',202608,5,4),
(3359,1,8,'AU','','',202608,4,3),
(3360,1,8,'CA','','',202608,7,4),
(3361,1,8,'ID','','',202608,4,3),
(3362,1,8,'ES','','',202608,4,3),
(3363,1,8,'BD','','',202608,2,1),
(3364,1,8,'MX','','',202608,3,2),
(3365,1,8,'ZA','','',202608,2,1),
(3366,1,8,'NL','','',202608,4,3),
(3367,1,8,'JP','','',202608,5,3),
(3368,1,8,'SA','','',202608,4,3),
(3369,1,8,'MY','','',202608,5,3),
(3370,1,8,'PL','','',202608,2,1),
(3371,1,8,'GH','','',202608,3,2),
(3372,1,8,'VN','','',202608,2,1),
(3373,1,8,'AR','','',202608,1,1),
(3374,1,8,'NZ','','',202608,1,1),
(3375,1,8,'SE','','',202608,1,1),
(3376,1,8,'US','','',202609,34,20),
(3377,1,8,'IN','','',202609,13,8),
(3378,1,8,'CN','','',202609,15,9),
(3379,1,8,'GB','','',202609,6,4),
(3380,1,8,'DE','','',202609,9,5),
(3381,1,8,'BR','','',202609,9,5),
(3382,1,8,'NG','','',202609,12,7),
(3383,1,8,'IR','','',202609,6,4),
(3384,1,8,'PK','','',202609,7,4),
(3385,1,8,'EG','','',202609,9,5),
(3386,1,8,'ET','','',202609,4,3),
(3387,1,8,'KE','','',202609,5,3),
(3388,1,8,'TR','','',202609,7,4),
(3389,1,8,'FR','','',202609,7,4),
(3390,1,8,'IT','','',202609,4,2),
(3391,1,8,'AU','','',202609,7,4),
(3392,1,8,'CA','','',202609,3,2),
(3393,1,8,'ID','','',202609,7,4),
(3394,1,8,'ES','','',202609,4,2),
(3395,1,8,'BD','','',202609,2,1),
(3396,1,8,'MX','','',202609,3,2),
(3397,1,8,'ZA','','',202609,3,2),
(3398,1,8,'NL','','',202609,2,1),
(3399,1,8,'JP','','',202609,3,2),
(3400,1,8,'SA','','',202609,2,1),
(3401,1,8,'MY','','',202609,4,2),
(3402,1,8,'PL','','',202609,2,1),
(3403,1,8,'GH','','',202609,2,1),
(3404,1,8,'VN','','',202609,1,1),
(3405,1,8,'AR','','',202609,2,1),
(3406,1,8,'NZ','','',202609,2,1),
(3407,1,8,'SE','','',202609,2,1),
(3408,1,8,'US','','',202610,4,2),
(3409,1,8,'IN','','',202610,4,3),
(3410,1,8,'CN','','',202610,3,1),
(3411,1,8,'GB','','',202610,3,2),
(3412,1,8,'DE','','',202610,2,1),
(3413,1,8,'BR','','',202610,2,1),
(3414,1,8,'NG','','',202610,1,1),
(3415,1,8,'IR','','',202610,1,1),
(3416,1,8,'PK','','',202610,1,1),
(3417,1,8,'FR','','',202610,1,1),
(3418,1,8,'AU','','',202610,1,1),
(3419,1,8,'CA','','',202610,2,1),
(3420,1,8,'BD','','',202610,1,1),
(3421,1,8,'JP','','',202610,1,1);
/*!40000 ALTER TABLE `metrics_submission_geo_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_item_assignment_settings`
--

DROP TABLE IF EXISTS `navigation_menu_item_assignment_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_item_assignment_settings` (
  `navigation_menu_item_assignment_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `navigation_menu_item_assignment_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`navigation_menu_item_assignment_setting_id`),
  UNIQUE KEY `navigation_menu_item_assignment_settings_unique` (`navigation_menu_item_assignment_id`,`locale`,`setting_name`),
  KEY `navigation_menu_item_assignment_settings_n_m_i_a_id` (`navigation_menu_item_assignment_id`),
  CONSTRAINT `assignment_settings_navigation_menu_item_assignment_id` FOREIGN KEY (`navigation_menu_item_assignment_id`) REFERENCES `navigation_menu_item_assignments` (`navigation_menu_item_assignment_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about navigation menu item assignments to navigation menus, including localized content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_item_assignment_settings`
--

LOCK TABLES `navigation_menu_item_assignment_settings` WRITE;
/*!40000 ALTER TABLE `navigation_menu_item_assignment_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `navigation_menu_item_assignment_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_item_assignments`
--

DROP TABLE IF EXISTS `navigation_menu_item_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_item_assignments` (
  `navigation_menu_item_assignment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `navigation_menu_id` bigint(20) NOT NULL,
  `navigation_menu_item_id` bigint(20) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `seq` bigint(20) DEFAULT 0,
  PRIMARY KEY (`navigation_menu_item_assignment_id`),
  KEY `navigation_menu_item_assignments_navigation_menu_id` (`navigation_menu_id`),
  KEY `navigation_menu_item_assignments_navigation_menu_item_id` (`navigation_menu_item_id`),
  KEY `navigation_menu_item_assignments_parent_id` (`parent_id`),
  CONSTRAINT `navigation_menu_item_assignments_navigation_menu_id_foreign` FOREIGN KEY (`navigation_menu_id`) REFERENCES `navigation_menus` (`navigation_menu_id`) ON DELETE CASCADE,
  CONSTRAINT `navigation_menu_item_assignments_navigation_menu_item_id_foreign` FOREIGN KEY (`navigation_menu_item_id`) REFERENCES `navigation_menu_items` (`navigation_menu_item_id`) ON DELETE CASCADE,
  CONSTRAINT `navigation_menu_item_assignments_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `navigation_menu_items` (`navigation_menu_item_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Links navigation menu items to navigation menus.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_item_assignments`
--

LOCK TABLES `navigation_menu_item_assignments` WRITE;
/*!40000 ALTER TABLE `navigation_menu_item_assignments` DISABLE KEYS */;
INSERT INTO `navigation_menu_item_assignments` VALUES
(1,1,1,NULL,0),
(2,1,2,NULL,1),
(3,1,3,NULL,2),
(4,1,4,3,0),
(5,1,5,3,1),
(6,1,6,3,2),
(7,1,7,3,3),
(8,2,8,NULL,0),
(9,2,9,NULL,1),
(10,2,10,NULL,2),
(11,2,11,10,0),
(12,2,12,10,1),
(13,2,13,10,2),
(14,2,14,10,3),
(54,3,15,NULL,0),
(55,3,16,NULL,1),
(56,3,18,NULL,2),
(57,3,19,18,0),
(58,3,101,18,1),
(59,3,21,18,2),
(60,3,106,18,2),
(61,3,102,18,3),
(62,3,103,18,4),
(63,3,23,18,5),
(64,3,22,18,6),
(65,3,104,NULL,3),
(66,3,20,104,0),
(67,3,105,104,1),
(68,3,17,NULL,4);
/*!40000 ALTER TABLE `navigation_menu_item_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_item_settings`
--

DROP TABLE IF EXISTS `navigation_menu_item_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_item_settings` (
  `navigation_menu_item_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `navigation_menu_item_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` longtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`navigation_menu_item_setting_id`),
  UNIQUE KEY `navigation_menu_item_settings_unique` (`navigation_menu_item_id`,`locale`,`setting_name`),
  KEY `navigation_menu_item_settings_navigation_menu_item_id` (`navigation_menu_item_id`),
  CONSTRAINT `navigation_menu_item_settings_navigation_menu_id` FOREIGN KEY (`navigation_menu_item_id`) REFERENCES `navigation_menu_items` (`navigation_menu_item_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about navigation menu items, including localized content such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_item_settings`
--

LOCK TABLES `navigation_menu_item_settings` WRITE;
/*!40000 ALTER TABLE `navigation_menu_item_settings` DISABLE KEYS */;
INSERT INTO `navigation_menu_item_settings` VALUES
(1,1,'','titleLocaleKey','navigation.register','string'),
(2,2,'','titleLocaleKey','navigation.login','string'),
(3,3,'','titleLocaleKey','{$loggedInUsername}','string'),
(4,4,'','titleLocaleKey','navigation.dashboard','string'),
(5,5,'','titleLocaleKey','common.viewProfile','string'),
(6,6,'','titleLocaleKey','navigation.admin','string'),
(7,7,'','titleLocaleKey','user.logOut','string'),
(8,8,'','titleLocaleKey','navigation.register','string'),
(9,9,'','titleLocaleKey','navigation.login','string'),
(10,10,'','titleLocaleKey','{$loggedInUsername}','string'),
(11,11,'','titleLocaleKey','navigation.dashboard','string'),
(12,12,'','titleLocaleKey','common.viewProfile','string'),
(13,13,'','titleLocaleKey','navigation.admin','string'),
(14,14,'','titleLocaleKey','user.logOut','string'),
(15,15,'','titleLocaleKey','navigation.current','string'),
(16,16,'','titleLocaleKey','navigation.archives','string'),
(17,17,'','titleLocaleKey','manager.announcements','string'),
(18,18,'','titleLocaleKey','navigation.about','string'),
(19,19,'','titleLocaleKey','about.aboutContext','string'),
(20,20,'','titleLocaleKey','about.submissions','string'),
(21,21,'','titleLocaleKey','common.editorialMasthead','string'),
(22,22,'','titleLocaleKey','manager.setup.privacyStatement','string'),
(23,23,'','titleLocaleKey','about.contact','string'),
(24,24,'','titleLocaleKey','common.search','string'),
(49,101,'en','title','Aims & Scope','string'),
(50,101,'en','remoteUrl','http://localhost:8080/djas/aims-and-scope','string'),
(51,102,'en','title','Journal Policies','string'),
(52,102,'en','remoteUrl','http://localhost:8080/djas/policies','string'),
(53,103,'en','title','Indexing & Abstracting','string'),
(54,103,'en','remoteUrl','http://localhost:8080/djas/indexing','string'),
(55,104,'en','title','For Authors','string'),
(56,104,'en','remoteUrl','http://localhost:8080/djas/about/submissions','string'),
(57,105,'en','title','Submit a Manuscript','string'),
(58,105,'en','remoteUrl','http://localhost:8080/djas/submission','string'),
(59,106,'en','title','Authors','string'),
(60,106,'en','remoteUrl','http://localhost:8080/djas/authors','string');
/*!40000 ALTER TABLE `navigation_menu_item_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_items`
--

DROP TABLE IF EXISTS `navigation_menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_items` (
  `navigation_menu_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) DEFAULT NULL,
  `path` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT '',
  PRIMARY KEY (`navigation_menu_item_id`),
  KEY `navigation_menu_items_context_id` (`context_id`),
  CONSTRAINT `navigation_menu_items_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Navigation menu items are single elements within a navigation menu.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_items`
--

LOCK TABLES `navigation_menu_items` WRITE;
/*!40000 ALTER TABLE `navigation_menu_items` DISABLE KEYS */;
INSERT INTO `navigation_menu_items` VALUES
(1,NULL,NULL,'NMI_TYPE_USER_REGISTER'),
(2,NULL,NULL,'NMI_TYPE_USER_LOGIN'),
(3,NULL,NULL,'NMI_TYPE_USER_DASHBOARD'),
(4,NULL,NULL,'NMI_TYPE_USER_DASHBOARD'),
(5,NULL,NULL,'NMI_TYPE_USER_PROFILE'),
(6,NULL,NULL,'NMI_TYPE_ADMINISTRATION'),
(7,NULL,NULL,'NMI_TYPE_USER_LOGOUT'),
(8,1,NULL,'NMI_TYPE_USER_REGISTER'),
(9,1,NULL,'NMI_TYPE_USER_LOGIN'),
(10,1,NULL,'NMI_TYPE_USER_DASHBOARD'),
(11,1,NULL,'NMI_TYPE_USER_DASHBOARD'),
(12,1,NULL,'NMI_TYPE_USER_PROFILE'),
(13,1,NULL,'NMI_TYPE_ADMINISTRATION'),
(14,1,NULL,'NMI_TYPE_USER_LOGOUT'),
(15,1,NULL,'NMI_TYPE_CURRENT'),
(16,1,NULL,'NMI_TYPE_ARCHIVES'),
(17,1,NULL,'NMI_TYPE_ANNOUNCEMENTS'),
(18,1,NULL,'NMI_TYPE_ABOUT'),
(19,1,NULL,'NMI_TYPE_ABOUT'),
(20,1,NULL,'NMI_TYPE_SUBMISSIONS'),
(21,1,NULL,'NMI_TYPE_MASTHEAD'),
(22,1,NULL,'NMI_TYPE_PRIVACY'),
(23,1,NULL,'NMI_TYPE_CONTACT'),
(24,1,NULL,'NMI_TYPE_SEARCH'),
(101,1,'','NMI_TYPE_REMOTE_URL'),
(102,1,'','NMI_TYPE_REMOTE_URL'),
(103,1,'','NMI_TYPE_REMOTE_URL'),
(104,1,'','NMI_TYPE_REMOTE_URL'),
(105,1,'','NMI_TYPE_REMOTE_URL'),
(106,1,'','NMI_TYPE_REMOTE_URL');
/*!40000 ALTER TABLE `navigation_menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menus`
--

DROP TABLE IF EXISTS `navigation_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menus` (
  `navigation_menu_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) DEFAULT NULL,
  `area_name` varchar(255) DEFAULT '',
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`navigation_menu_id`),
  KEY `navigation_menus_context_id` (`context_id`),
  CONSTRAINT `navigation_menus_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Navigation menus on the website are installed with the software as a default set, and can be customized.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menus`
--

LOCK TABLES `navigation_menus` WRITE;
/*!40000 ALTER TABLE `navigation_menus` DISABLE KEYS */;
INSERT INTO `navigation_menus` VALUES
(1,NULL,'user','User Navigation Menu'),
(2,1,'user','User Navigation Menu'),
(3,1,'primary','Primary Navigation Menu');
/*!40000 ALTER TABLE `navigation_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `note_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `contents` text DEFAULT NULL,
  PRIMARY KEY (`note_id`),
  KEY `notes_user_id` (`user_id`),
  KEY `notes_assoc` (`assoc_type`,`assoc_id`),
  CONSTRAINT `notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Notes allow users to annotate associated entities, such as submissions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_settings`
--

DROP TABLE IF EXISTS `notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_settings` (
  `notification_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `notification_id` bigint(20) NOT NULL,
  `locale` varchar(28) DEFAULT NULL,
  `setting_name` varchar(64) NOT NULL,
  `setting_value` mediumtext NOT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`notification_setting_id`),
  UNIQUE KEY `notification_settings_unique` (`notification_id`,`locale`,`setting_name`),
  KEY `notification_settings_notification_id` (`notification_id`),
  CONSTRAINT `notification_settings_notification_id_foreign` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`notification_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about notifications, including localized properties.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_settings`
--

LOCK TABLES `notification_settings` WRITE;
/*!40000 ALTER TABLE `notification_settings` DISABLE KEYS */;
INSERT INTO `notification_settings` VALUES
(14,14,'','contents','Call for papers: Heat stress and animal welfare','string'),
(15,15,'','contents','The journal is now accepting submissions','string');
/*!40000 ALTER TABLE `notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_subscription_settings`
--

DROP TABLE IF EXISTS `notification_subscription_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_subscription_settings` (
  `setting_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(64) NOT NULL,
  `setting_value` mediumtext NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `context_id` bigint(20) DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`setting_id`),
  KEY `notification_subscription_settings_user_id` (`user_id`),
  KEY `notification_subscription_settings_context` (`context_id`),
  CONSTRAINT `notification_subscription_settings_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `notification_subscription_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Which email notifications a user has chosen to unsubscribe from.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_subscription_settings`
--

LOCK TABLES `notification_subscription_settings` WRITE;
/*!40000 ALTER TABLE `notification_subscription_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_subscription_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `notification_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `level` bigint(20) NOT NULL,
  `type` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_read` datetime DEFAULT NULL,
  `assoc_type` bigint(20) DEFAULT NULL,
  `assoc_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `notifications_context_id` (`context_id`),
  KEY `notifications_user_id` (`user_id`),
  KEY `notifications_context_id_user_id` (`context_id`,`user_id`,`level`),
  KEY `notifications_context_id_level` (`context_id`,`level`),
  KEY `notifications_assoc` (`assoc_type`,`assoc_id`),
  KEY `notifications_user_id_level` (`user_id`,`level`),
  CONSTRAINT `notifications_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='User notifications created during certain operations.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(14,1,1,2,8,'2026-09-25 16:09:35',NULL,NULL,NULL),
(15,1,1,2,8,'2026-09-25 16:09:35',NULL,NULL,NULL),
(16,1,NULL,2,16777236,'2026-10-06 21:06:22',NULL,523,1),
(17,1,211,3,16777227,'2026-10-06 21:06:51',NULL,517,1),
(19,1,212,3,16777227,'2026-10-06 21:07:04',NULL,517,2);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oai_resumption_tokens`
--

DROP TABLE IF EXISTS `oai_resumption_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oai_resumption_tokens` (
  `oai_resumption_token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(32) NOT NULL,
  `expire` bigint(20) NOT NULL,
  `record_offset` int(11) NOT NULL,
  `params` text DEFAULT NULL,
  PRIMARY KEY (`oai_resumption_token_id`),
  UNIQUE KEY `oai_resumption_tokens_unique` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='OAI resumption tokens are used to allow for pagination of large result sets into manageable pieces.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oai_resumption_tokens`
--

LOCK TABLES `oai_resumption_tokens` WRITE;
/*!40000 ALTER TABLE `oai_resumption_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oai_resumption_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin_settings`
--

DROP TABLE IF EXISTS `plugin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugin_settings` (
  `plugin_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `plugin_name` varchar(80) NOT NULL,
  `context_id` bigint(20) DEFAULT NULL,
  `setting_name` varchar(80) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`plugin_setting_id`),
  UNIQUE KEY `plugin_settings_unique` (`plugin_name`,`context_id`,`setting_name`),
  KEY `plugin_settings_context_id` (`context_id`),
  KEY `plugin_settings_plugin_name` (`plugin_name`),
  CONSTRAINT `plugin_settings_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about plugins, including localized properties. This table is frequently used to store plugin-specific configuration.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_settings`
--

LOCK TABLES `plugin_settings` WRITE;
/*!40000 ALTER TABLE `plugin_settings` DISABLE KEYS */;
INSERT INTO `plugin_settings` VALUES
(1,'defaultthemeplugin',NULL,'enabled','1','bool'),
(2,'usageeventplugin',NULL,'enabled','1','bool'),
(3,'tinymceplugin',NULL,'enabled','1','bool'),
(4,'languagetoggleblockplugin',NULL,'enabled','1','bool'),
(5,'languagetoggleblockplugin',NULL,'seq','4','int'),
(6,'developedbyblockplugin',NULL,'enabled','0','bool'),
(7,'developedbyblockplugin',NULL,'seq','0','int'),
(8,'defaultthemeplugin',1,'enabled','1','bool'),
(9,'tinymceplugin',1,'enabled','1','bool'),
(10,'languagetoggleblockplugin',1,'enabled','1','bool'),
(11,'languagetoggleblockplugin',1,'seq','4','int'),
(12,'developedbyblockplugin',1,'enabled','0','bool'),
(13,'developedbyblockplugin',1,'seq','0','int'),
(14,'informationblockplugin',1,'enabled','1','bool'),
(15,'informationblockplugin',1,'seq','7','int'),
(16,'subscriptionblockplugin',1,'enabled','1','bool'),
(17,'subscriptionblockplugin',1,'seq','2','int'),
(18,'htmlarticlegalleyplugin',1,'enabled','1','bool'),
(19,'googlescholarplugin',1,'enabled','1','bool'),
(20,'pdfjsviewerplugin',1,'enabled','1','bool'),
(21,'jatstemplateplugin',1,'enabled','1','bool'),
(22,'lensgalleyplugin',1,'enabled','1','bool'),
(23,'webfeedplugin',1,'enabled','1','bool'),
(24,'webfeedplugin',1,'displayPage','homepage','string'),
(25,'webfeedplugin',1,'displayItems','1','bool'),
(26,'webfeedplugin',1,'recentItems','30','int'),
(27,'webfeedplugin',1,'includeIdentifiers','0','bool'),
(28,'dublincoremetaplugin',1,'enabled','1','bool'),
(29,'meridianplugin',1,'enabled','1','bool'),
(30,'scholarlyreaderplugin',1,'enabled','1','bool'),
(31,'authorpagesplugin',1,'enabled','1','bool'),
(32,'citationstylelanguageplugin',1,'enabled','1','bool'),
(33,'staticpagesplugin',1,'enabled','1','bool'),
(34,'recommendbyauthorplugin',1,'enabled','1','bool'),
(35,'oaimetadataformatplugin_jats',1,'enabled','1','bool'),
(36,'meridianplugin',1,'tagline','\"{\\\"en\\\":\\\"Peer-reviewed · Open access · Animal and veterinary science\\\"}\"','object'),
(37,'meridianplugin',1,'indexingLogos','Google Scholar | | https://scholar.google.com\nCrossref | | https://www.crossref.org\nORCID | | https://orcid.org\nDOAJ (in preparation) | | https://doaj.org\nPKP Preservation Network | | https://pkp.sfu.ca/pkp-pn/','string'),
(38,'googleanalyticsplugin',1,'enabled','1','bool');
/*!40000 ALTER TABLE `plugin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_categories`
--

DROP TABLE IF EXISTS `publication_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_categories` (
  `publication_category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `publication_id` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL,
  PRIMARY KEY (`publication_category_id`),
  UNIQUE KEY `publication_categories_id` (`publication_id`,`category_id`),
  KEY `publication_categories_publication_id` (`publication_id`),
  KEY `publication_categories_category_id` (`category_id`),
  CONSTRAINT `publication_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE,
  CONSTRAINT `publication_categories_publication_id_foreign` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Associates publications (and thus submissions) with categories.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_categories`
--

LOCK TABLES `publication_categories` WRITE;
/*!40000 ALTER TABLE `publication_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `publication_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_galley_settings`
--

DROP TABLE IF EXISTS `publication_galley_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_galley_settings` (
  `publication_galley_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `galley_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`publication_galley_setting_id`),
  UNIQUE KEY `publication_galley_settings_unique` (`galley_id`,`locale`,`setting_name`),
  KEY `publication_galley_settings_galley_id` (`galley_id`),
  KEY `publication_galley_settings_name_value` (`setting_name`(50),`setting_value`(150)),
  CONSTRAINT `publication_galley_settings_galley_id` FOREIGN KEY (`galley_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about publication galleys, including localized content such as labels.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_galley_settings`
--

LOCK TABLES `publication_galley_settings` WRITE;
/*!40000 ALTER TABLE `publication_galley_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `publication_galley_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_galleys`
--

DROP TABLE IF EXISTS `publication_galleys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_galleys` (
  `galley_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `locale` varchar(28) DEFAULT NULL,
  `publication_id` bigint(20) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `submission_file_id` bigint(20) unsigned DEFAULT NULL,
  `seq` double NOT NULL DEFAULT 0,
  `remote_url` varchar(2047) DEFAULT NULL,
  `is_approved` smallint(6) NOT NULL DEFAULT 0,
  `url_path` varchar(64) DEFAULT NULL,
  `doi_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`galley_id`),
  KEY `publication_galleys_publication_id` (`publication_id`),
  KEY `publication_galleys_submission_file_id` (`submission_file_id`),
  KEY `publication_galleys_doi_id` (`doi_id`),
  KEY `publication_galleys_url_path` (`url_path`),
  CONSTRAINT `publication_galleys_doi_id_foreign` FOREIGN KEY (`doi_id`) REFERENCES `dois` (`doi_id`) ON DELETE SET NULL,
  CONSTRAINT `publication_galleys_publication_id` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE,
  CONSTRAINT `publication_galleys_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Publication galleys are representations of a publication in a specific format, e.g. a PDF.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_galleys`
--

LOCK TABLES `publication_galleys` WRITE;
/*!40000 ALTER TABLE `publication_galleys` DISABLE KEYS */;
INSERT INTO `publication_galleys` VALUES
(1,'en',1,'PDF',1,0,NULL,0,NULL,NULL),
(2,'en',2,'PDF',2,0,NULL,0,NULL,NULL),
(3,'en',3,'PDF',3,0,NULL,0,NULL,NULL),
(4,'en',4,'PDF',4,0,NULL,0,NULL,NULL),
(5,'en',5,'PDF',5,0,NULL,0,NULL,NULL),
(6,'en',5,'Full Text',6,1,NULL,0,NULL,NULL),
(7,'en',6,'PDF',7,0,NULL,0,NULL,NULL),
(8,'en',7,'PDF',8,0,NULL,0,NULL,NULL),
(9,'en',8,'PDF',9,0,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `publication_galleys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_settings`
--

DROP TABLE IF EXISTS `publication_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_settings` (
  `publication_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `publication_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`publication_setting_id`),
  UNIQUE KEY `publication_settings_unique` (`publication_id`,`locale`,`setting_name`),
  KEY `publication_settings_name_value` (`setting_name`(50),`setting_value`(150)),
  KEY `publication_settings_publication_id` (`publication_id`),
  CONSTRAINT `publication_settings_publication_id` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about publications, including localized properties such as the title and abstract.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_settings`
--

LOCK TABLES `publication_settings` WRITE;
/*!40000 ALTER TABLE `publication_settings` DISABLE KEYS */;
INSERT INTO `publication_settings` VALUES
(1,1,'en','abstract','<p><strong>Background:</strong> Probiotics are increasingly used as alternatives to antibiotic growth promoters in poultry production.</p><p><strong>Methods:</strong> A total of 480 one-day-old Ross 308 broilers were randomly allocated to four dietary treatments (0, 0.5, 1.0 and 1.5 g/kg of a <em>Bacillus subtilis</em> probiotic) with six replicate pens each for 42 days.</p><p><strong>Results:</strong> Supplementation at 1.0 g/kg improved body weight gain by 6.8% and the feed conversion ratio by 5.1% compared with the control (P &lt; 0.05). Villus height and villus-to-crypt ratio in the jejunum increased linearly with the dose.</p><p><strong>Conclusions:</strong> Dietary <em>B. subtilis</em> at 1.0 g/kg is an effective strategy to support growth and intestinal integrity in broilers.</p>'),
(2,1,'en','copyrightHolder','The Authors'),
(3,1,'','copyrightYear','2026'),
(4,1,'','licenseUrl','https://creativecommons.org/licenses/by/4.0/'),
(5,1,'en','title','Effects of dietary probiotic supplementation on growth performance and intestinal morphology in broiler chickens'),
(6,1,'','pages','1–9'),
(7,2,'en','abstract','<p><strong>Objective:</strong> To estimate the prevalence of subclinical mastitis (SCM) and identify herd- and cow-level risk factors in smallholder dairy farms.</p><p><strong>Methods:</strong> A cross-sectional study sampled 612 lactating cows from 94 herds. Quarters were screened with the California mastitis test and positive samples were cultured.</p><p><strong>Results:</strong> Cow-level SCM prevalence was 38.4% (95% CI 34.6–42.3). Parity ≥ 4, late lactation and the absence of post-milking teat dipping were associated with higher odds of SCM. <em>Staphylococcus aureus</em> was the most frequent isolate.</p><p><strong>Conclusions:</strong> Simple hygiene interventions could substantially reduce SCM in smallholder systems.</p>'),
(8,2,'en','copyrightHolder','The Authors'),
(9,2,'','copyrightYear','2026'),
(10,2,'','licenseUrl','https://creativecommons.org/licenses/by/4.0/'),
(11,2,'en','title','Prevalence of subclinical mastitis and associated risk factors in smallholder dairy herds'),
(12,2,'','pages','10–18'),
(13,3,'en','abstract','<p>We adapted a hands-on welfare protocol for working donkeys and mules and tested its inter-observer reliability in 120 animals. Agreement was substantial for body condition score (κ = 0.71) and lesion scoring (κ = 0.66). The protocol can be completed in under ten minutes per animal and is suitable for routine field surveillance.</p>'),
(14,3,'en','copyrightHolder','The Authors'),
(15,3,'','copyrightYear','2026'),
(16,3,'','licenseUrl','https://creativecommons.org/licenses/by/4.0/'),
(17,3,'en','title','Welfare assessment of working equids using a modified hands-on protocol'),
(18,3,'','pages','19–23'),
(19,4,'en','abstract','<p><strong>Objective:</strong> To compare recovery quality and cardiorespiratory variables between alfaxalone- and propofol-based induction protocols in cats undergoing elective ovariohysterectomy.</p><p><strong>Methods:</strong> Sixty healthy cats were randomly assigned to receive either protocol; assessors were blinded to treatment.</p><p><strong>Results:</strong> Recovery scores and times to extubation did not differ between groups. Post-induction apnoea was less frequent with alfaxalone (7% vs 27%).</p><p><strong>Conclusions:</strong> Both protocols are suitable; alfaxalone may be preferred where respiratory depression is a concern.</p>'),
(20,4,'en','copyrightHolder','The Authors'),
(21,4,'','copyrightYear','2026'),
(22,4,'','licenseUrl','https://creativecommons.org/licenses/by/4.0/'),
(23,4,'en','title','Comparison of two anaesthetic protocols for ovariohysterectomy in cats: a randomized blinded trial'),
(24,4,'','pages','24–32'),
(25,5,'en','abstract','<p><strong>Background:</strong> Rising ambient temperatures threaten the productivity and welfare of high-yielding dairy cows.</p><p><strong>Methods:</strong> Sixteen multiparous Holstein cows were enrolled in a randomized crossover design with two 21-day periods: thermoneutral (temperature–humidity index, THI &lt; 68) and heat stress (THI 78–82). Rumen fluid, milk yield and composition, and physiological variables were measured.</p><p><strong>Results:</strong> Heat stress reduced dry matter intake by 12% and milk yield by 3.9 kg/day (P &lt; 0.01). Total volatile fatty acid concentration decreased while ruminal pH and the acetate-to-propionate ratio increased.</p><p><strong>Conclusions:</strong> Heat stress impairs rumen fermentation independently of intake, supporting nutritional strategies that target rumen function during hot seasons.</p>'),
(26,5,'en','copyrightHolder','The Authors'),
(27,5,'','copyrightYear','2026'),
(28,5,'','licenseUrl','https://creativecommons.org/licenses/by/4.0/'),
(29,5,'en','title','Heat stress modulates rumen fermentation and milk yield in Holstein dairy cows: a randomized crossover study'),
(30,5,'','pages','33–44'),
(31,6,'en','abstract','<p><strong>Objective:</strong> To summarise surveillance data on antimicrobial resistance (AMR) in bacterial isolates from dogs and cats published between 2015 and 2025.</p><p><strong>Methods:</strong> Following PRISMA 2020, four databases were searched; 87 studies met the inclusion criteria and risk of bias was assessed.</p><p><strong>Results:</strong> Resistance to aminopenicillins was common in <em>Escherichia coli</em> (pooled 41%), and methicillin resistance was reported in 7–19% of <em>Staphylococcus pseudintermedius</em> isolates. Reporting standards varied widely.</p><p><strong>Conclusions:</strong> Harmonised surveillance of companion animals is needed within a One Health framework.</p>'),
(32,6,'en','copyrightHolder','The Authors'),
(33,6,'','copyrightYear','2026'),
(34,6,'','licenseUrl','https://creativecommons.org/licenses/by/4.0/'),
(35,6,'en','title','Antimicrobial resistance in companion animals: a systematic review of surveillance data (2015–2025)'),
(36,6,'','pages','45–60'),
(37,7,'en','abstract','<p>Reference intervals for 18 serum biochemistry analytes were established from 124 clinically healthy New Zealand White rabbits housed with environmental enrichment. Intervals for glucose and creatine kinase were narrower than published values from barren housing, suggesting reduced handling stress. These data support the refinement of laboratory rabbit studies.</p>'),
(38,7,'en','copyrightHolder','The Authors'),
(39,7,'','copyrightYear','2026'),
(40,7,'','licenseUrl','https://creativecommons.org/licenses/by/4.0/'),
(41,7,'en','title','Serum biochemistry reference intervals for adult laboratory rabbits (Oryctolagus cuniculus) housed under enriched conditions'),
(42,7,'','pages','61–66'),
(43,8,'en','abstract','<p>A 9-year-old male Great Dane presented with acute abdominal distension and non-productive retching. Radiography confirmed gastric dilatation–volvulus. After stabilisation and gastric decompression, derotation and incisional gastropexy were performed. The dog recovered without complications and remained healthy at the six-month follow-up.</p>'),
(44,8,'en','copyrightHolder','The Authors'),
(45,8,'','copyrightYear','2026'),
(46,8,'','licenseUrl','https://creativecommons.org/licenses/by/4.0/'),
(47,8,'en','title','Successful surgical management of gastric dilatation–volvulus in a 9-year-old Great Dane'),
(48,8,'','pages','67–70'),
(49,9,'en','abstract','<p>Lameness is among the most costly welfare problems in dairy herds, yet it is often detected late. We trained gradient-boosted models on leg-mounted accelerometer data from 212 Holstein cows and compared their predictions with weekly locomotion scores. The best model identified lame cows a median of 4 days before visual scoring, with a sensitivity of 0.84 and a specificity of 0.91.</p>'),
(50,9,'en','title','Early detection of lameness in dairy cows from accelerometer data: a machine-learning approach'),
(51,10,'en','abstract','<p>We measured enteric methane in 48 grazing ewes receiving 0%, 0.5% or 1% dietary <em>Asparagopsis</em> for 60 days. Methane yield fell by 31% at the highest inclusion rate without affecting live weight gain.</p>'),
(52,10,'en','title','Dietary seaweed supplementation and enteric methane emissions in grazing sheep'),
(53,11,'en','abstract','<p>Free-range chickens are sentinels for environmental contamination with <em>Toxoplasma gondii</em> oocysts. Of 540 chickens from 96 households, 18.3% were seropositive by modified agglutination test. Cat ownership and a soil floor in the coop were associated with seropositivity.</p>'),
(54,11,'en','title','Seroprevalence of Toxoplasma gondii in free-range backyard chickens and associated household risk factors'),
(55,12,'en','abstract','<p>A 4-month-old alpaca presented with ill thrift and neurological signs. Computed tomography confirmed a single extrahepatic shunt, which was attenuated with an ameroid constrictor. The cria was clinically normal 6 months after surgery.</p>'),
(56,12,'en','title','Surgical management of a congenital portosystemic shunt in a young alpaca');
/*!40000 ALTER TABLE `publication_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publications`
--

DROP TABLE IF EXISTS `publications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `publications` (
  `publication_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `access_status` bigint(20) DEFAULT 0,
  `date_published` date DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `primary_contact_id` bigint(20) DEFAULT NULL,
  `section_id` bigint(20) DEFAULT NULL,
  `seq` double NOT NULL DEFAULT 0,
  `submission_id` bigint(20) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT 1,
  `url_path` varchar(64) DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `doi_id` bigint(20) DEFAULT NULL,
  `issue_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`publication_id`),
  KEY `publications_primary_contact_id` (`primary_contact_id`),
  KEY `publications_section_id` (`section_id`),
  KEY `publications_submission_id` (`submission_id`),
  KEY `publications_doi_id` (`doi_id`),
  KEY `publications_issue_id_index` (`issue_id`),
  KEY `publications_url_path` (`url_path`),
  CONSTRAINT `publications_doi_id_foreign` FOREIGN KEY (`doi_id`) REFERENCES `dois` (`doi_id`) ON DELETE SET NULL,
  CONSTRAINT `publications_issue_id_foreign` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE SET NULL,
  CONSTRAINT `publications_primary_contact_id` FOREIGN KEY (`primary_contact_id`) REFERENCES `authors` (`author_id`) ON DELETE SET NULL,
  CONSTRAINT `publications_section_id` FOREIGN KEY (`section_id`) REFERENCES `sections` (`section_id`) ON DELETE SET NULL,
  CONSTRAINT `publications_submission_id` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Each publication is one version of a submission.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publications`
--

LOCK TABLES `publications` WRITE;
/*!40000 ALTER TABLE `publications` DISABLE KEYS */;
INSERT INTO `publications` VALUES
(1,0,'2026-03-15','2026-09-25 16:09:35',NULL,1,0,1,3,NULL,1,NULL,1),
(2,0,'2026-03-15','2026-09-25 16:09:36',NULL,1,1,2,3,NULL,1,NULL,1),
(3,0,'2026-03-15','2026-09-25 16:09:36',NULL,3,2,3,3,NULL,1,NULL,1),
(4,0,'2026-03-15','2026-09-25 16:09:36',NULL,1,3,4,3,NULL,1,NULL,1),
(5,0,'2026-06-15','2026-09-25 16:09:36',NULL,1,0,5,3,NULL,1,NULL,2),
(6,0,'2026-06-15','2026-09-25 16:09:36',NULL,2,1,6,3,NULL,1,NULL,2),
(7,0,'2026-06-15','2026-09-25 16:09:36',NULL,3,2,7,3,NULL,1,NULL,2),
(8,0,'2026-06-15','2026-09-25 16:09:36',NULL,4,3,8,3,NULL,1,NULL,2),
(9,0,NULL,'2026-09-25 17:47:52',NULL,1,0,9,1,NULL,1,NULL,NULL),
(10,0,NULL,'2026-09-25 17:47:52',NULL,3,0,10,1,NULL,1,NULL,NULL),
(11,0,NULL,'2026-09-25 17:47:52',NULL,1,0,11,1,NULL,1,NULL,NULL),
(12,0,NULL,'2026-09-25 17:47:52',NULL,4,0,12,1,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `publications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queries`
--

DROP TABLE IF EXISTS `queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `queries` (
  `query_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `stage_id` smallint(6) NOT NULL,
  `seq` double NOT NULL DEFAULT 0,
  `date_posted` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `closed` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`query_id`),
  KEY `queries_assoc_id` (`assoc_type`,`assoc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Discussions, usually related to a submission, created by editors, authors and other editorial staff.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queries`
--

LOCK TABLES `queries` WRITE;
/*!40000 ALTER TABLE `queries` DISABLE KEYS */;
/*!40000 ALTER TABLE `queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `query_participants`
--

DROP TABLE IF EXISTS `query_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `query_participants` (
  `query_participant_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `query_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`query_participant_id`),
  UNIQUE KEY `query_participants_unique` (`query_id`,`user_id`),
  KEY `query_participants_query_id` (`query_id`),
  KEY `query_participants_user_id` (`user_id`),
  CONSTRAINT `query_participants_query_id_foreign` FOREIGN KEY (`query_id`) REFERENCES `queries` (`query_id`) ON DELETE CASCADE,
  CONSTRAINT `query_participants_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='The users assigned to a discussion.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `query_participants`
--

LOCK TABLES `query_participants` WRITE;
/*!40000 ALTER TABLE `query_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `query_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queued_payments`
--

DROP TABLE IF EXISTS `queued_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `queued_payments` (
  `queued_payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `payment_data` text DEFAULT NULL,
  PRIMARY KEY (`queued_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Unfulfilled (queued) payments, i.e. payments that have not yet been completed via an online payment system.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queued_payments`
--

LOCK TABLES `queued_payments` WRITE;
/*!40000 ALTER TABLE `queued_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `queued_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_assignment_settings`
--

DROP TABLE IF EXISTS `review_assignment_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_assignment_settings` (
  `review_assignment_settings_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary key.',
  `review_id` bigint(20) NOT NULL COMMENT 'Foreign key referencing record in review_assignments table',
  `locale` varchar(28) DEFAULT NULL COMMENT 'Locale key.',
  `setting_name` varchar(255) NOT NULL COMMENT 'Name of settings record.',
  `setting_value` mediumtext DEFAULT NULL COMMENT 'Settings value.',
  PRIMARY KEY (`review_assignment_settings_id`),
  UNIQUE KEY `review_assignment_settings_unique` (`review_id`,`locale`,`setting_name`),
  KEY `review_assignment_settings_review_id` (`review_id`),
  CONSTRAINT `review_assignment_settings_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `review_assignments` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_assignment_settings`
--

LOCK TABLES `review_assignment_settings` WRITE;
/*!40000 ALTER TABLE `review_assignment_settings` DISABLE KEYS */;
INSERT INTO `review_assignment_settings` VALUES
(1,2,'','declineReason','expertise'),
(2,2,'','declineReasonOther',''),
(3,2,'','declineComments','The manuscript focuses on rumen microbiology, which is outside my area. Dr Ahmed and Dr Novak work on methane mitigation in small ruminants and would be well placed to review it.'),
(4,2,'','declineSuggestions','[{\"name\":\"Samir Ahmed\",\"email\":\"samir.ahmed@example.org\",\"affiliation\":\"Institute of Animal Science, Eastbrook College\"},{\"name\":\"Laura Novak\",\"email\":\"laura.novak@example.org\",\"affiliation\":\"Faculty of Agriculture, Southgate University\"}]');
/*!40000 ALTER TABLE `review_assignment_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_assignments`
--

DROP TABLE IF EXISTS `review_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_assignments` (
  `review_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) NOT NULL,
  `reviewer_id` bigint(20) NOT NULL,
  `competing_interests` text DEFAULT NULL,
  `recommendation` smallint(6) DEFAULT NULL,
  `date_assigned` datetime DEFAULT NULL,
  `date_notified` datetime DEFAULT NULL,
  `date_confirmed` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `date_considered` datetime DEFAULT NULL,
  `date_acknowledged` datetime DEFAULT NULL,
  `date_due` datetime DEFAULT NULL,
  `date_response_due` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reminder_was_automatic` smallint(6) NOT NULL DEFAULT 0,
  `declined` smallint(6) NOT NULL DEFAULT 0,
  `cancelled` smallint(6) NOT NULL DEFAULT 0,
  `date_cancelled` datetime DEFAULT NULL,
  `date_rated` datetime DEFAULT NULL,
  `date_reminded` datetime DEFAULT NULL,
  `quality` smallint(6) DEFAULT NULL,
  `review_round_id` bigint(20) NOT NULL,
  `stage_id` smallint(6) NOT NULL,
  `review_method` smallint(6) NOT NULL DEFAULT 1,
  `round` smallint(6) NOT NULL DEFAULT 1,
  `step` smallint(6) NOT NULL DEFAULT 1,
  `review_form_id` bigint(20) DEFAULT NULL,
  `considered` smallint(6) DEFAULT NULL,
  `request_resent` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`review_id`),
  KEY `review_assignments_submission_id` (`submission_id`),
  KEY `review_assignments_reviewer_id` (`reviewer_id`),
  KEY `review_assignment_reviewer_round` (`review_round_id`,`reviewer_id`),
  KEY `review_assignments_form_id` (`review_form_id`),
  KEY `review_assignments_reviewer_review` (`reviewer_id`,`review_id`),
  CONSTRAINT `review_assignments_review_form_id_foreign` FOREIGN KEY (`review_form_id`) REFERENCES `review_forms` (`review_form_id`),
  CONSTRAINT `review_assignments_review_round_id_foreign` FOREIGN KEY (`review_round_id`) REFERENCES `review_rounds` (`review_round_id`),
  CONSTRAINT `review_assignments_reviewer_id_foreign` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `review_assignments_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Data about peer review assignments for all submissions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_assignments`
--

LOCK TABLES `review_assignments` WRITE;
/*!40000 ALTER TABLE `review_assignments` DISABLE KEYS */;
INSERT INTO `review_assignments` VALUES
(1,10,211,NULL,NULL,'2026-10-06 21:06:51','2026-10-06 21:06:52',NULL,NULL,NULL,NULL,'2026-11-03 00:00:00','2026-11-03 00:00:00','2026-10-06 21:06:52',0,0,0,NULL,NULL,NULL,NULL,1,3,2,1,1,NULL,0,0),
(2,10,212,NULL,NULL,'2026-10-06 21:07:04','2026-10-06 21:07:04','2026-10-06 21:08:52',NULL,NULL,NULL,'2026-11-03 00:00:00','2026-11-03 00:00:00','2026-10-06 21:08:52',0,1,0,NULL,NULL,NULL,NULL,1,3,2,1,1,NULL,0,0);
/*!40000 ALTER TABLE `review_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_files`
--

DROP TABLE IF EXISTS `review_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_files` (
  `review_file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `review_id` bigint(20) NOT NULL,
  `submission_file_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`review_file_id`),
  UNIQUE KEY `review_files_unique` (`review_id`,`submission_file_id`),
  KEY `review_files_review_id` (`review_id`),
  KEY `review_files_submission_file_id` (`submission_file_id`),
  CONSTRAINT `review_files_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `review_assignments` (`review_id`) ON DELETE CASCADE,
  CONSTRAINT `review_files_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A list of the submission files made available to each assigned reviewer.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_files`
--

LOCK TABLES `review_files` WRITE;
/*!40000 ALTER TABLE `review_files` DISABLE KEYS */;
INSERT INTO `review_files` VALUES
(1,1,14),
(2,2,14);
/*!40000 ALTER TABLE `review_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_form_element_settings`
--

DROP TABLE IF EXISTS `review_form_element_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_form_element_settings` (
  `review_form_element_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `review_form_element_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`review_form_element_setting_id`),
  UNIQUE KEY `review_form_element_settings_unique` (`review_form_element_id`,`locale`,`setting_name`),
  KEY `review_form_element_settings_review_form_element_id` (`review_form_element_id`),
  CONSTRAINT `review_form_element_settings_review_form_element_id` FOREIGN KEY (`review_form_element_id`) REFERENCES `review_form_elements` (`review_form_element_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about review form elements, including localized content such as question text.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_form_element_settings`
--

LOCK TABLES `review_form_element_settings` WRITE;
/*!40000 ALTER TABLE `review_form_element_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_form_element_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_form_elements`
--

DROP TABLE IF EXISTS `review_form_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_form_elements` (
  `review_form_element_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `review_form_id` bigint(20) NOT NULL,
  `seq` double DEFAULT NULL,
  `element_type` bigint(20) DEFAULT NULL,
  `required` smallint(6) DEFAULT NULL,
  `included` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`review_form_element_id`),
  KEY `review_form_elements_review_form_id` (`review_form_id`),
  CONSTRAINT `review_form_elements_review_form_id` FOREIGN KEY (`review_form_id`) REFERENCES `review_forms` (`review_form_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Each review form element represents a single question on a review form.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_form_elements`
--

LOCK TABLES `review_form_elements` WRITE;
/*!40000 ALTER TABLE `review_form_elements` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_form_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_form_responses`
--

DROP TABLE IF EXISTS `review_form_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_form_responses` (
  `review_form_response_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `review_form_element_id` bigint(20) NOT NULL,
  `review_id` bigint(20) NOT NULL,
  `response_type` varchar(6) DEFAULT NULL,
  `response_value` text DEFAULT NULL,
  PRIMARY KEY (`review_form_response_id`),
  KEY `review_form_responses_review_form_element_id` (`review_form_element_id`),
  KEY `review_form_responses_review_id` (`review_id`),
  KEY `review_form_responses_unique` (`review_form_element_id`,`review_id`),
  CONSTRAINT `review_form_responses_review_form_element_id_foreign` FOREIGN KEY (`review_form_element_id`) REFERENCES `review_form_elements` (`review_form_element_id`) ON DELETE CASCADE,
  CONSTRAINT `review_form_responses_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `review_assignments` (`review_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Each review form response records a reviewer''s answer to a review form element associated with a peer review.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_form_responses`
--

LOCK TABLES `review_form_responses` WRITE;
/*!40000 ALTER TABLE `review_form_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_form_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_form_settings`
--

DROP TABLE IF EXISTS `review_form_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_form_settings` (
  `review_form_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `review_form_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`review_form_setting_id`),
  UNIQUE KEY `review_form_settings_unique` (`review_form_id`,`locale`,`setting_name`),
  KEY `review_form_settings_review_form_id` (`review_form_id`),
  CONSTRAINT `review_form_settings_review_form_id` FOREIGN KEY (`review_form_id`) REFERENCES `review_forms` (`review_form_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about review forms, including localized content such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_form_settings`
--

LOCK TABLES `review_form_settings` WRITE;
/*!40000 ALTER TABLE `review_form_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_form_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_forms`
--

DROP TABLE IF EXISTS `review_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_forms` (
  `review_form_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `seq` double DEFAULT NULL,
  `is_active` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`review_form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Review forms provide custom templates for peer reviews with several types of questions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_forms`
--

LOCK TABLES `review_forms` WRITE;
/*!40000 ALTER TABLE `review_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_round_files`
--

DROP TABLE IF EXISTS `review_round_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_round_files` (
  `review_round_file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) NOT NULL,
  `review_round_id` bigint(20) NOT NULL,
  `stage_id` smallint(6) NOT NULL,
  `submission_file_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`review_round_file_id`),
  UNIQUE KEY `review_round_files_unique` (`submission_id`,`review_round_id`,`submission_file_id`),
  KEY `review_round_files_submission_id` (`submission_id`),
  KEY `review_round_files_review_round_id` (`review_round_id`),
  KEY `review_round_files_submission_file_id` (`submission_file_id`),
  CONSTRAINT `review_round_files_review_round_id_foreign` FOREIGN KEY (`review_round_id`) REFERENCES `review_rounds` (`review_round_id`) ON DELETE CASCADE,
  CONSTRAINT `review_round_files_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `review_round_files_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Records the files made available to reviewers for a round of reviews. These can be further customized on a per review basis with review_files.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_round_files`
--

LOCK TABLES `review_round_files` WRITE;
/*!40000 ALTER TABLE `review_round_files` DISABLE KEYS */;
INSERT INTO `review_round_files` VALUES
(1,10,1,3,14);
/*!40000 ALTER TABLE `review_round_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_rounds`
--

DROP TABLE IF EXISTS `review_rounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_rounds` (
  `review_round_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) NOT NULL,
  `stage_id` bigint(20) DEFAULT NULL,
  `round` smallint(6) NOT NULL,
  `review_revision` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`review_round_id`),
  UNIQUE KEY `review_rounds_submission_id_stage_id_round_pkey` (`submission_id`,`stage_id`,`round`),
  KEY `review_rounds_submission_id` (`submission_id`),
  CONSTRAINT `review_rounds_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Peer review assignments are organized into multiple rounds on a submission.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_rounds`
--

LOCK TABLES `review_rounds` WRITE;
/*!40000 ALTER TABLE `review_rounds` DISABLE KEYS */;
INSERT INTO `review_rounds` VALUES
(1,10,3,1,NULL,7);
/*!40000 ALTER TABLE `review_rounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviewer_suggestion_settings`
--

DROP TABLE IF EXISTS `reviewer_suggestion_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviewer_suggestion_settings` (
  `reviewer_suggestion_id` bigint(20) NOT NULL COMMENT 'The foreign key mapping of this setting to reviewer_suggestions table',
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  UNIQUE KEY `reviewer_suggestion_settings_unique` (`reviewer_suggestion_id`,`locale`,`setting_name`),
  KEY `reviewer_suggestion_settings_reviewer_suggestion_id` (`reviewer_suggestion_id`),
  KEY `reviewer_suggestion_settings_locale_setting_name_index` (`setting_name`,`locale`),
  CONSTRAINT `reviewer_suggestion_settings_reviewer_suggestion_id_foreign` FOREIGN KEY (`reviewer_suggestion_id`) REFERENCES `reviewer_suggestions` (`reviewer_suggestion_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Reviewer suggestion settings table to contain multilingual or extra information';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviewer_suggestion_settings`
--

LOCK TABLES `reviewer_suggestion_settings` WRITE;
/*!40000 ALTER TABLE `reviewer_suggestion_settings` DISABLE KEYS */;
INSERT INTO `reviewer_suggestion_settings` VALUES
(1,'en','affiliation','Institute of Animal Science, Eastbrook College'),
(1,'en','familyName','Ahmed'),
(1,'en','givenName','Samir'),
(1,'en','suggestionReason','Suggested by Helen Carter when declining the review request.'),
(2,'en','affiliation','Faculty of Agriculture, Southgate University'),
(2,'en','familyName','Novak'),
(2,'en','givenName','Laura'),
(2,'en','suggestionReason','Suggested by Helen Carter when declining the review request.');
/*!40000 ALTER TABLE `reviewer_suggestion_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviewer_suggestions`
--

DROP TABLE IF EXISTS `reviewer_suggestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviewer_suggestions` (
  `reviewer_suggestion_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `suggesting_user_id` bigint(20) DEFAULT NULL COMMENT 'The user/author who has made the suggestion',
  `submission_id` bigint(20) NOT NULL COMMENT 'Submission at which the suggestion was made',
  `email` varchar(255) NOT NULL COMMENT 'Suggested reviewer email address',
  `orcid_id` varchar(255) DEFAULT NULL COMMENT 'Suggested reviewer optional Orcid Id',
  `approved_at` timestamp NULL DEFAULT NULL COMMENT 'If and when the suggestion approved to add/invite suggested_reviewer',
  `approver_id` bigint(20) DEFAULT NULL COMMENT 'The user who has approved the suggestion',
  `reviewer_id` bigint(20) DEFAULT NULL COMMENT 'The reviewer who has been added/invited through this suggestion',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`reviewer_suggestion_id`),
  KEY `reviewer_suggestions_suggesting_user_id` (`suggesting_user_id`),
  KEY `reviewer_suggestions_submission_id` (`submission_id`),
  KEY `reviewer_suggestions_approver_id_foreign` (`approver_id`),
  KEY `reviewer_suggestions_reviewer_id_foreign` (`reviewer_id`),
  CONSTRAINT `reviewer_suggestions_approver_id_foreign` FOREIGN KEY (`approver_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `reviewer_suggestions_reviewer_id_foreign` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `reviewer_suggestions_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE,
  CONSTRAINT `reviewer_suggestions_suggesting_user_id_foreign` FOREIGN KEY (`suggesting_user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Author suggested reviewers at the submission time';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviewer_suggestions`
--

LOCK TABLES `reviewer_suggestions` WRITE;
/*!40000 ALTER TABLE `reviewer_suggestions` DISABLE KEYS */;
INSERT INTO `reviewer_suggestions` VALUES
(1,212,10,'samir.ahmed@example.org',NULL,NULL,NULL,NULL,'2026-10-06 21:08:52','2026-10-06 21:08:52'),
(2,212,10,'laura.novak@example.org',NULL,NULL,NULL,NULL,'2026-10-06 21:08:52','2026-10-06 21:08:52');
/*!40000 ALTER TABLE `reviewer_suggestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ror_settings`
--

DROP TABLE IF EXISTS `ror_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ror_settings` (
  `ror_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ror_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`ror_setting_id`),
  UNIQUE KEY `ror_settings_unique` (`ror_id`,`locale`,`setting_name`),
  CONSTRAINT `ror_settings_ror_id_foreign` FOREIGN KEY (`ror_id`) REFERENCES `rors` (`ror_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about Ror registry dataset cache';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ror_settings`
--

LOCK TABLES `ror_settings` WRITE;
/*!40000 ALTER TABLE `ror_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ror_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rors`
--

DROP TABLE IF EXISTS `rors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rors` (
  `ror_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ror` varchar(255) NOT NULL,
  `display_locale` varchar(28) NOT NULL,
  `is_active` smallint(6) NOT NULL DEFAULT 1,
  `search_phrase` mediumtext DEFAULT NULL,
  PRIMARY KEY (`ror_id`),
  UNIQUE KEY `rors_unique` (`ror`),
  KEY `rors_display_locale` (`display_locale`),
  KEY `rors_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Ror registry dataset cache';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rors`
--

LOCK TABLES `rors` WRITE;
/*!40000 ALTER TABLE `rors` DISABLE KEYS */;
/*!40000 ALTER TABLE `rors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_settings`
--

DROP TABLE IF EXISTS `section_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_settings` (
  `section_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`section_setting_id`),
  UNIQUE KEY `section_settings_unique` (`section_id`,`locale`,`setting_name`),
  KEY `section_settings_section_id` (`section_id`),
  CONSTRAINT `section_settings_section_id` FOREIGN KEY (`section_id`) REFERENCES `sections` (`section_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about sections, including localized properties like section titles.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_settings`
--

LOCK TABLES `section_settings` WRITE;
/*!40000 ALTER TABLE `section_settings` DISABLE KEYS */;
INSERT INTO `section_settings` VALUES
(1,1,'en','title','Original Research'),
(2,1,'en','abbrev','ART'),
(3,1,'en','policy','Section default policy'),
(4,2,'en','title','Review Article'),
(5,2,'en','abbrev','REV'),
(6,3,'en','title','Short Communication'),
(7,3,'en','abbrev','SC'),
(8,4,'en','title','Case Report'),
(9,4,'en','abbrev','CR');
/*!40000 ALTER TABLE `section_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `section_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `journal_id` bigint(20) NOT NULL,
  `review_form_id` bigint(20) DEFAULT NULL,
  `seq` double NOT NULL DEFAULT 0,
  `editor_restricted` smallint(6) NOT NULL DEFAULT 0,
  `meta_indexed` smallint(6) NOT NULL DEFAULT 0,
  `meta_reviewed` smallint(6) NOT NULL DEFAULT 1,
  `abstracts_not_required` smallint(6) NOT NULL DEFAULT 0,
  `hide_title` smallint(6) NOT NULL DEFAULT 0,
  `hide_author` smallint(6) NOT NULL DEFAULT 0,
  `is_inactive` smallint(6) NOT NULL DEFAULT 0,
  `abstract_word_count` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`section_id`),
  KEY `sections_journal_id` (`journal_id`),
  KEY `sections_review_form_id` (`review_form_id`),
  CONSTRAINT `sections_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `sections_review_form_id` FOREIGN KEY (`review_form_id`) REFERENCES `review_forms` (`review_form_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A list of all sections into which submissions can be organized, forming the table of contents.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES
(1,1,NULL,0,0,1,1,0,0,0,0,NULL),
(2,1,NULL,2,0,1,1,0,0,0,0,300),
(3,1,NULL,3,0,1,1,0,0,0,0,300),
(4,1,NULL,4,0,1,1,0,0,0,0,300);
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `last_activity` int(11) NOT NULL,
  `payload` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`),
  CONSTRAINT `sessions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Session data for logged-in users.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `site` (
  `site_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `redirect_context_id` bigint(20) DEFAULT NULL COMMENT 'If not null, redirect to the specified journal/conference/... site.',
  `primary_locale` varchar(28) NOT NULL COMMENT 'Primary locale for the site.',
  `min_password_length` smallint(6) NOT NULL DEFAULT 6,
  `installed_locales` varchar(1024) NOT NULL DEFAULT 'en' COMMENT 'Locales for which support has been installed.',
  `supported_locales` varchar(1024) DEFAULT NULL COMMENT 'Locales supported by the site (for hosted journals/conferences/...).',
  `original_style_file_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`site_id`),
  KEY `site_context_id` (`redirect_context_id`),
  CONSTRAINT `site_redirect_context_id_foreign` FOREIGN KEY (`redirect_context_id`) REFERENCES `journals` (`journal_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A singleton table describing basic information about the site.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site`
--

LOCK TABLES `site` WRITE;
/*!40000 ALTER TABLE `site` DISABLE KEYS */;
INSERT INTO `site` VALUES
(1,NULL,'en',6,'[\"en\"]','[\"en\"]',NULL);
/*!40000 ALTER TABLE `site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `site_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(255) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`site_setting_id`),
  UNIQUE KEY `site_settings_unique` (`setting_name`,`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about the site, including localized properties such as its name.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES
(1,'contactEmail','en','admin@example.org'),
(2,'contactName','en','Open Journal Systems'),
(3,'compressStatsLogs','','0'),
(4,'enableGeoUsageStats','','country'),
(5,'enableInstitutionUsageStats','','0'),
(6,'keepDailyUsageStats','','0'),
(7,'isSiteSushiPlatform','','0'),
(8,'isSushiApiPublic','','1'),
(9,'disableSharedReviewerStatistics','','0'),
(10,'orcidClientId','',''),
(11,'orcidClientSecret','',''),
(12,'orcidEnabled','','0'),
(13,'themePluginPath','','default'),
(14,'uniqueSiteId','','C2DCD32F-1643-476D-8372-46A83295B67B');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stage_assignments`
--

DROP TABLE IF EXISTS `stage_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stage_assignments` (
  `stage_assignment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) NOT NULL,
  `user_group_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `date_assigned` datetime NOT NULL,
  `recommend_only` smallint(6) NOT NULL DEFAULT 0,
  `can_change_metadata` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`stage_assignment_id`),
  UNIQUE KEY `stage_assignment` (`submission_id`,`user_group_id`,`user_id`),
  KEY `stage_assignments_user_group_id` (`user_group_id`),
  KEY `stage_assignments_user_id` (`user_id`),
  KEY `stage_assignments_submission_id` (`submission_id`),
  CONSTRAINT `stage_assignments_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE,
  CONSTRAINT `stage_assignments_user_group_id` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE,
  CONSTRAINT `stage_assignments_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Who can access a submission while it is in the editorial workflow. Includes all editorial and author assignments. For reviewers, see review_assignments.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage_assignments`
--

LOCK TABLES `stage_assignments` WRITE;
/*!40000 ALTER TABLE `stage_assignments` DISABLE KEYS */;
INSERT INTO `stage_assignments` VALUES
(6,5,14,201,'2026-10-06 21:05:53',0,1),
(7,9,14,201,'2026-10-06 21:05:53',0,1),
(9,11,3,101,'2026-10-06 21:05:53',0,1),
(10,12,3,101,'2026-10-06 21:05:53',0,1);
/*!40000 ALTER TABLE `stage_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `static_page_settings`
--

DROP TABLE IF EXISTS `static_page_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `static_page_settings` (
  `static_page_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `static_page_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` longtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`static_page_setting_id`),
  UNIQUE KEY `static_page_settings_unique` (`static_page_id`,`locale`,`setting_name`),
  KEY `static_page_settings_static_page_id` (`static_page_id`),
  CONSTRAINT `static_page_settings_static_page_id` FOREIGN KEY (`static_page_id`) REFERENCES `static_pages` (`static_page_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `static_page_settings`
--

LOCK TABLES `static_page_settings` WRITE;
/*!40000 ALTER TABLE `static_page_settings` DISABLE KEYS */;
INSERT INTO `static_page_settings` VALUES
(13,7,'en','title','Aims & Scope','string'),
(14,7,'en','content','<p>The <em>[Journal Name]</em> publishes original research, reviews, short communications and case reports across animal and veterinary science.</p>\n<h2>Scope</h2>\n<ul><li>Animal health, disease and epidemiology</li><li>Animal welfare and behaviour</li><li>Nutrition, production and reproduction</li><li>Laboratory animal science and the 3Rs</li><li>Public health and One Health</li></ul>\n<h2>Article types</h2>\n<p>Original Research, Review Article, Short Communication and Case Report. See the <a href=\"about/submissions\">Author Guidelines</a> for requirements.</p>','string'),
(15,8,'en','title','Journal Policies','string'),
(16,8,'en','content','<p class=\"lead\">These policies describe how the journal handles manuscripts, publication ethics, access and preservation. [Template — the editorial office should review every section before launch.]</p>\n<h2 id=\"peer-review\">Peer review process</h2>\n<p>All research articles undergo double-anonymous peer review by at least two independent reviewers. The handling editor screens submissions for scope and quality before review; the Editor-in-Chief makes the final decision. Target time to first decision: [X] weeks.</p>\n<h2 id=\"open-access\">Open access</h2>\n<p>The journal provides immediate open access to its content on the principle that making research freely available to the public supports a greater global exchange of knowledge. There are no subscription or pay-per-view charges.</p>\n<h2 id=\"ethics\">Publication ethics and malpractice</h2>\n<p>The journal follows the Core Practices of the Committee on Publication Ethics (COPE). Studies involving animals must state approval by an institutional animal ethics committee and comply with the ARRIVE guidelines; studies involving humans require informed consent and ethics approval.</p>\n<h2 id=\"plagiarism\">Plagiarism</h2>\n<p>Submissions are screened with similarity-checking software. Manuscripts with substantial overlap with published work are declined; suspected misconduct is handled according to COPE flowcharts.</p>\n<h2 id=\"copyright\">Copyright and licensing</h2>\n<p>Authors retain copyright. Articles are published under the Creative Commons Attribution 4.0 International License (CC BY 4.0), which permits use, sharing and adaptation with appropriate credit.</p>\n<h2 id=\"archiving\">Archiving</h2>\n<p>The journal content is preserved through the PKP Preservation Network (PKP PN). [Add any national library deposit.]</p>\n<h2 id=\"apc\">Article processing charges</h2>\n<p>[State the APC amount, or: “The journal charges no submission or publication fees.”]</p>\n<h2 id=\"corrections\">Corrections, retractions and expressions of concern</h2>\n<p>Errors are corrected through published corrections linked to the original article. Retractions follow COPE guidance and remain openly available with a clear retraction notice.</p>\n<h2 id=\"conflicts\">Conflicts of interest</h2>\n<p>Authors, reviewers and editors must disclose any financial or personal relationships that could influence their work. Editors do not handle manuscripts where they have a conflict of interest.</p>\n<h2 id=\"data\">Data sharing</h2>\n<p>Authors are encouraged to deposit data in a public repository and to include a data availability statement.</p>\n<h2 id=\"ai\">Use of AI tools</h2>\n<p>AI tools cannot be listed as authors. Any use of generative AI in preparing a manuscript must be disclosed in the methods or acknowledgements; authors remain responsible for the content.</p>\n<h2 id=\"complaints\">Complaints and appeals</h2>\n<p>Appeals against editorial decisions and complaints should be sent to the editorial office at [email]; they are handled by an editor not involved in the original decision.</p>','string'),
(17,9,'en','title','Indexing & Abstracting','string'),
(18,9,'en','content','<p>The journal is technically prepared for academic indexing services. Current status:</p>\n<ul><li>Google Scholar — metadata provided for every article</li><li>Crossref — DOIs registered for all articles</li><li>ORCID — author identifiers integrated</li><li>PKP Preservation Network — archiving</li><li>DOAJ — application planned once eligibility criteria are met</li></ul>\n<p>OAI-PMH endpoint for harvesters: <code>/oai</code></p>','string');
/*!40000 ALTER TABLE `static_page_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `static_pages`
--

DROP TABLE IF EXISTS `static_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `static_pages` (
  `static_page_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  PRIMARY KEY (`static_page_id`),
  KEY `static_pages_context_id` (`context_id`),
  CONSTRAINT `static_pages_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `static_pages`
--

LOCK TABLES `static_pages` WRITE;
/*!40000 ALTER TABLE `static_pages` DISABLE KEYS */;
INSERT INTO `static_pages` VALUES
(7,'aims-and-scope',1),
(8,'policies',1),
(9,'indexing',1);
/*!40000 ALTER TABLE `static_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subeditor_submission_group`
--

DROP TABLE IF EXISTS `subeditor_submission_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subeditor_submission_group` (
  `subeditor_submission_group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_group_id` bigint(20) NOT NULL,
  PRIMARY KEY (`subeditor_submission_group_id`),
  UNIQUE KEY `section_editors_unique` (`context_id`,`assoc_id`,`assoc_type`,`user_id`,`user_group_id`),
  KEY `subeditor_submission_group_context_id` (`context_id`),
  KEY `subeditor_submission_group_user_id` (`user_id`),
  KEY `subeditor_submission_group_user_group_id` (`user_group_id`),
  KEY `subeditor_submission_group_assoc_id` (`assoc_id`,`assoc_type`),
  CONSTRAINT `section_editors_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `subeditor_submission_group_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE,
  CONSTRAINT `subeditor_submission_group_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Subeditor assignments to e.g. sections and categories';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subeditor_submission_group`
--

LOCK TABLES `subeditor_submission_group` WRITE;
/*!40000 ALTER TABLE `subeditor_submission_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `subeditor_submission_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_comments`
--

DROP TABLE IF EXISTS `submission_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_comments` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `comment_type` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `author_id` bigint(20) NOT NULL,
  `comment_title` text NOT NULL,
  `comments` text DEFAULT NULL,
  `date_posted` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `viewable` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `submission_comments_submission_id` (`submission_id`),
  KEY `submission_comments_author_id` (`author_id`),
  CONSTRAINT `submission_comments_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_comments_submission_id` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Comments on a submission, e.g. peer review comments';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_comments`
--

LOCK TABLES `submission_comments` WRITE;
/*!40000 ALTER TABLE `submission_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_file_revisions`
--

DROP TABLE IF EXISTS `submission_file_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_file_revisions` (
  `revision_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `submission_file_id` bigint(20) unsigned NOT NULL,
  `file_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`revision_id`),
  KEY `submission_file_revisions_submission_file_id` (`submission_file_id`),
  KEY `submission_file_revisions_file_id` (`file_id`),
  CONSTRAINT `submission_file_revisions_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`file_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_file_revisions_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Revisions map submission_file entries to files on the data store.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_file_revisions`
--

LOCK TABLES `submission_file_revisions` WRITE;
/*!40000 ALTER TABLE `submission_file_revisions` DISABLE KEYS */;
INSERT INTO `submission_file_revisions` VALUES
(1,1,1),
(2,2,2),
(3,3,3),
(4,4,4),
(5,5,5),
(6,6,6),
(7,7,7),
(8,8,8),
(9,9,9),
(10,10,10),
(11,11,11),
(12,12,12),
(13,13,13),
(14,14,11);
/*!40000 ALTER TABLE `submission_file_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_file_settings`
--

DROP TABLE IF EXISTS `submission_file_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_file_settings` (
  `submission_file_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `submission_file_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`submission_file_setting_id`),
  UNIQUE KEY `submission_file_settings_unique` (`submission_file_id`,`locale`,`setting_name`),
  KEY `submission_file_settings_submission_file_id` (`submission_file_id`),
  CONSTRAINT `submission_file_settings_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Localized data about submission files like published metadata.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_file_settings`
--

LOCK TABLES `submission_file_settings` WRITE;
/*!40000 ALTER TABLE `submission_file_settings` DISABLE KEYS */;
INSERT INTO `submission_file_settings` VALUES
(1,1,'','dateCreated',''),
(2,1,'','language',''),
(3,1,'en','name','djas-1-1-1.pdf'),
(4,2,'','dateCreated',''),
(5,2,'','language',''),
(6,2,'en','name','djas-1-1-2.pdf'),
(7,3,'','dateCreated',''),
(8,3,'','language',''),
(9,3,'en','name','djas-1-1-3.pdf'),
(10,4,'','dateCreated',''),
(11,4,'','language',''),
(12,4,'en','name','djas-1-1-4.pdf'),
(13,5,'','dateCreated',''),
(14,5,'','language',''),
(15,5,'en','name','djas-1-2-1.pdf'),
(16,6,'','dateCreated',''),
(17,6,'','language',''),
(18,6,'en','name','djas-1-2-1.html'),
(19,7,'','dateCreated',''),
(20,7,'','language',''),
(21,7,'en','name','djas-1-2-2.pdf'),
(22,8,'','dateCreated',''),
(23,8,'','language',''),
(24,8,'en','name','djas-1-2-3.pdf'),
(25,9,'','dateCreated',''),
(26,9,'','language',''),
(27,9,'en','name','djas-1-2-4.pdf'),
(28,10,'','dateCreated',''),
(29,10,'','language',''),
(30,10,'en','name','manuscript-101.pdf'),
(31,11,'','dateCreated',''),
(32,11,'','language',''),
(33,11,'en','name','manuscript-102.pdf'),
(34,12,'','dateCreated',''),
(35,12,'','language',''),
(36,12,'en','name','manuscript-103.pdf'),
(37,13,'','dateCreated',''),
(38,13,'','language',''),
(39,13,'en','name','manuscript-104.pdf'),
(40,14,'','dateCreated',''),
(41,14,'','language',''),
(42,14,'en','name','manuscript-102.pdf');
/*!40000 ALTER TABLE `submission_file_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_files`
--

DROP TABLE IF EXISTS `submission_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_files` (
  `submission_file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) NOT NULL,
  `file_id` bigint(20) unsigned NOT NULL,
  `source_submission_file_id` bigint(20) unsigned DEFAULT NULL,
  `genre_id` bigint(20) DEFAULT NULL,
  `file_stage` bigint(20) NOT NULL,
  `direct_sales_price` varchar(255) DEFAULT NULL,
  `sales_type` varchar(255) DEFAULT NULL,
  `viewable` smallint(6) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `uploader_user_id` bigint(20) DEFAULT NULL,
  `assoc_type` bigint(20) DEFAULT NULL,
  `assoc_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`submission_file_id`),
  KEY `submission_files_submission_id` (`submission_id`),
  KEY `submission_files_file_id` (`file_id`),
  KEY `submission_files_genre_id` (`genre_id`),
  KEY `submission_files_uploader_user_id` (`uploader_user_id`),
  KEY `submission_files_stage_assoc` (`file_stage`,`assoc_type`,`assoc_id`),
  KEY `submission_files_source_submission_file_id` (`source_submission_file_id`),
  CONSTRAINT `submission_files_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`file_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_files_genre_id_foreign` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`genre_id`) ON DELETE SET NULL,
  CONSTRAINT `submission_files_source_submission_file_id_foreign` FOREIGN KEY (`source_submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_files_submission_id` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_files_uploader_user_id_foreign` FOREIGN KEY (`uploader_user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='All files associated with a submission, such as those uploaded during submission, as revisions, or by copyeditors or layout editors for production.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_files`
--

LOCK TABLES `submission_files` WRITE;
/*!40000 ALTER TABLE `submission_files` DISABLE KEYS */;
INSERT INTO `submission_files` VALUES
(1,1,1,NULL,1,10,NULL,NULL,NULL,'2026-09-25 16:09:35','2026-09-25 16:09:36',1,521,1),
(2,2,2,NULL,1,10,NULL,NULL,NULL,'2026-09-25 16:09:36','2026-09-25 16:09:36',1,521,2),
(3,3,3,NULL,1,10,NULL,NULL,NULL,'2026-09-25 16:09:36','2026-09-25 16:09:36',1,521,3),
(4,4,4,NULL,1,10,NULL,NULL,NULL,'2026-09-25 16:09:36','2026-09-25 16:09:36',1,521,4),
(5,5,5,NULL,1,10,NULL,NULL,NULL,'2026-09-25 16:09:36','2026-09-25 16:09:36',1,521,5),
(6,5,6,NULL,1,10,NULL,NULL,NULL,'2026-09-25 16:09:36','2026-09-25 16:09:36',1,521,6),
(7,6,7,NULL,1,10,NULL,NULL,NULL,'2026-09-25 16:09:36','2026-09-25 16:09:36',1,521,7),
(8,7,8,NULL,1,10,NULL,NULL,NULL,'2026-09-25 16:09:36','2026-09-25 16:09:36',1,521,8),
(9,8,9,NULL,1,10,NULL,NULL,NULL,'2026-09-25 16:09:36','2026-09-25 16:09:36',1,521,9),
(10,9,10,NULL,1,2,NULL,NULL,NULL,'2026-09-25 17:47:52','2026-09-25 17:47:52',1,NULL,NULL),
(11,10,11,NULL,1,2,NULL,NULL,NULL,'2026-09-25 17:47:52','2026-09-25 17:47:52',1,NULL,NULL),
(12,11,12,NULL,1,2,NULL,NULL,NULL,'2026-09-25 17:47:52','2026-09-25 17:47:52',1,NULL,NULL),
(13,12,13,NULL,1,2,NULL,NULL,NULL,'2026-09-25 17:47:52','2026-09-25 17:47:52',1,NULL,NULL),
(14,10,11,11,1,4,NULL,NULL,NULL,'2026-10-06 21:06:22','2026-10-06 21:06:22',1,523,1);
/*!40000 ALTER TABLE `submission_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_search_keyword_list`
--

DROP TABLE IF EXISTS `submission_search_keyword_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_search_keyword_list` (
  `keyword_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `keyword_text` varchar(60) NOT NULL,
  PRIMARY KEY (`keyword_id`),
  UNIQUE KEY `submission_search_keyword_text` (`keyword_text`)
) ENGINE=InnoDB AUTO_INCREMENT=571 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A list of all keywords used in the search index';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_search_keyword_list`
--

LOCK TABLES `submission_search_keyword_list` WRITE;
/*!40000 ALTER TABLE `submission_search_keyword_list` DISABLE KEYS */;
INSERT INTO `submission_search_keyword_list` VALUES
(313,'3rs'),
(469,'abdominal'),
(105,'absence'),
(492,'accelerometer'),
(361,'accompanied'),
(299,'accounting'),
(257,'acetate'),
(253,'acid'),
(268,'acids'),
(363,'activity'),
(468,'acute'),
(456,'adams'),
(134,'adapted'),
(10,'additives'),
(311,'adhered'),
(340,'adjusted'),
(358,'adjusting'),
(431,'adult'),
(528,'affecting'),
(212,'affects'),
(542,'agglutination'),
(142,'agreement'),
(296,'aim'),
(423,'alexander'),
(181,'alfaxalone'),
(41,'allocated'),
(553,'alpaca'),
(31,'alternatives'),
(228,'ambient'),
(563,'ameroid'),
(409,'aminopenicillins'),
(396,'amr'),
(204,'anaesthesia'),
(169,'anaesthetic'),
(328,'analysed'),
(324,'analysis'),
(438,'analytes'),
(69,'andrew'),
(151,'animal'),
(141,'animals'),
(32,'antibiotic'),
(390,'antimicrobial'),
(198,'apnoea'),
(495,'approach'),
(275,'approximately'),
(525,'asparagopsis'),
(408,'assessed'),
(128,'assessment'),
(191,'assessors'),
(189,'assigned'),
(3,'assistant'),
(207,'associate'),
(562,'attenuated'),
(291,'attributed'),
(113,'aureus'),
(43,'bacillus'),
(28,'background'),
(535,'backyard'),
(397,'bacterial'),
(163,'badge'),
(448,'barren'),
(183,'based'),
(276,'begin'),
(341,'benjamini'),
(124,'bennett'),
(407,'bias'),
(428,'biochemistry'),
(174,'blinded'),
(50,'body'),
(501,'boosted'),
(25,'broiler'),
(39,'broilers'),
(165,'brooks'),
(368,'buffers'),
(306,'calculated'),
(97,'california'),
(568,'camelid'),
(375,'capture'),
(158,'carberry'),
(179,'cardiorespiratory'),
(2,'carter'),
(569,'case'),
(543,'cat'),
(172,'cats'),
(122,'cattle'),
(279,'change'),
(295,'characterised'),
(26,'chickens'),
(320,'chromatography'),
(425,'claire'),
(211,'climate'),
(454,'clinical'),
(440,'clinically'),
(412,'coli'),
(315,'collected'),
(70,'collins'),
(384,'combine'),
(378,'commercial'),
(410,'common'),
(392,'companion'),
(176,'compare'),
(55,'compared'),
(168,'comparison'),
(148,'completed'),
(483,'complications'),
(244,'composition'),
(558,'computed'),
(254,'concentration'),
(202,'concern'),
(64,'conclusions'),
(144,'condition'),
(350,'conditions'),
(474,'confirmed'),
(549,'congenital'),
(364,'consistent'),
(272,'constraints'),
(564,'constrictor'),
(538,'contamination'),
(56,'control'),
(298,'controlled'),
(53,'conversion'),
(385,'cooling'),
(547,'coop'),
(496,'costly'),
(86,'cow'),
(94,'cows'),
(445,'creatine'),
(565,'cria'),
(406,'criteria'),
(89,'cross'),
(226,'crossover'),
(59,'crypt'),
(101,'cultured'),
(370,'cultures'),
(435,'cuniculus'),
(79,'dairy'),
(465,'dane'),
(13,'daniel'),
(327,'data'),
(402,'databases'),
(37,'day'),
(47,'days'),
(360,'decline'),
(476,'decompression'),
(255,'decreased'),
(162,'demonstrate'),
(201,'depression'),
(477,'derotation'),
(236,'design'),
(284,'designs'),
(308,'detect'),
(498,'detected'),
(490,'detection'),
(18,'dietary'),
(196,'differ'),
(309,'difference'),
(300,'differences'),
(461,'dilatation'),
(109,'dipping'),
(293,'direct'),
(359,'discussion'),
(470,'distension'),
(376,'diurnal'),
(481,'dog'),
(399,'dogs'),
(156,'donkey'),
(135,'donkeys'),
(426,'donovan'),
(63,'dose'),
(248,'dry'),
(489,'early'),
(336,'effect'),
(65,'effective'),
(17,'effects'),
(214,'eleanor'),
(186,'elective'),
(487,'emergency'),
(1,'emily'),
(520,'emissions'),
(437,'enriched'),
(443,'enrichment'),
(235,'enrolled'),
(518,'enteric'),
(373,'environment'),
(271,'environmental'),
(130,'equids'),
(411,'escherichia'),
(287,'essential'),
(439,'established'),
(82,'estimate'),
(357,'evident'),
(523,'ewes'),
(210,'examines'),
(274,'exceeds'),
(277,'expected'),
(283,'experimental'),
(382,'exposure'),
(561,'extrahepatic'),
(195,'extubation'),
(77,'factors'),
(516,'farming'),
(88,'farms'),
(252,'fatty'),
(9,'feed'),
(203,'feline'),
(526,'fell'),
(222,'fermentation'),
(362,'fermentative'),
(160,'fictitious'),
(154,'field'),
(367,'findings'),
(334,'fixed'),
(546,'floor'),
(243,'fluid'),
(8,'focuses'),
(486,'follow'),
(387,'foster'),
(422,'framework'),
(533,'free'),
(114,'frequent'),
(265,'function'),
(379,'future'),
(52,'gain'),
(319,'gas'),
(460,'gastric'),
(479,'gastropexy'),
(444,'glucose'),
(532,'gondii'),
(71,'grace'),
(500,'gradient'),
(521,'grazing'),
(464,'great'),
(197,'groups'),
(21,'growth'),
(11,'gut'),
(451,'handling'),
(132,'hands'),
(164,'hannah'),
(420,'harmonised'),
(126,'hayes'),
(12,'health'),
(188,'healthy'),
(218,'heat'),
(58,'height'),
(85,'herd'),
(80,'herds'),
(231,'high'),
(110,'higher'),
(527,'highest'),
(342,'hochberg'),
(225,'holstein'),
(266,'hot'),
(436,'housed'),
(536,'household'),
(540,'households'),
(449,'housing'),
(14,'hughes'),
(240,'humidity'),
(117,'hygiene'),
(508,'identified'),
(84,'identify'),
(554,'ill'),
(322,'imaged'),
(325,'imagej'),
(259,'impairs'),
(270,'important'),
(49,'improved'),
(478,'incisional'),
(372,'include'),
(332,'including'),
(405,'inclusion'),
(61,'increased'),
(30,'increasingly'),
(260,'independently'),
(241,'index'),
(184,'induction'),
(250,'intake'),
(68,'integrity'),
(278,'intensify'),
(138,'inter'),
(288,'interpreting'),
(430,'intervals'),
(118,'interventions'),
(23,'intestinal'),
(269,'introduction'),
(115,'isolate'),
(398,'isolates'),
(60,'jejunum'),
(217,'jenkins'),
(157,'josiah'),
(455,'katherine'),
(446,'kinase'),
(432,'laboratory'),
(93,'lactating'),
(104,'lactation'),
(509,'lame'),
(491,'lameness'),
(380,'larger'),
(103,'late'),
(494,'learning'),
(502,'leg'),
(146,'lesion'),
(87,'level'),
(371,'limitations'),
(329,'linear'),
(62,'linearly'),
(529,'live'),
(515,'livestock'),
(294,'load'),
(506,'locomotion'),
(381,'longer'),
(292,'losses'),
(365,'lower'),
(493,'machine'),
(466,'male'),
(459,'management'),
(75,'mastitis'),
(301,'materials'),
(249,'matter'),
(216,'matthew'),
(352,'means'),
(246,'measured'),
(314,'measurements'),
(510,'median'),
(404,'met'),
(519,'methane'),
(414,'methicillin'),
(35,'methods'),
(366,'microbiota'),
(223,'milk'),
(107,'milking'),
(150,'minutes'),
(206,'mitchell'),
(383,'mitigation'),
(330,'mixed'),
(355,'mmol'),
(507,'model'),
(331,'models'),
(131,'modified'),
(220,'modulates'),
(485,'month'),
(567,'months'),
(16,'morgan'),
(24,'morphology'),
(323,'morphometric'),
(503,'mounted'),
(136,'mules'),
(234,'multiparous'),
(338,'multiple'),
(447,'narrower'),
(386,'natalie'),
(421,'needed'),
(556,'neurological'),
(566,'normal'),
(6,'nutrition'),
(262,'nutritional'),
(81,'objective'),
(139,'observer'),
(111,'odds'),
(166,'oliver'),
(539,'oocysts'),
(159,'orcid'),
(316,'oro'),
(434,'oryctolagus'),
(339,'outcomes'),
(171,'ovariohysterectomy'),
(544,'ownership'),
(321,'papillae'),
(102,'parity'),
(46,'pens'),
(22,'performance'),
(480,'performed'),
(318,'period'),
(237,'periods'),
(356,'ph6'),
(245,'physiological'),
(413,'pooled'),
(550,'portosystemic'),
(99,'positive'),
(106,'post'),
(5,'poultry'),
(310,'power'),
(514,'precision'),
(504,'predictions'),
(199,'preferred'),
(467,'presented'),
(73,'prevalence'),
(290,'previous'),
(215,'price'),
(312,'principles'),
(307,'priori'),
(401,'prisma'),
(19,'probiotic'),
(29,'probiotics'),
(497,'problems'),
(343,'procedure'),
(34,'production'),
(471,'productive'),
(213,'productivity'),
(4,'professor'),
(33,'promoters'),
(258,'propionate'),
(182,'propofol'),
(347,'protein'),
(133,'protocol'),
(170,'protocols'),
(416,'pseudintermedius'),
(400,'published'),
(178,'quality'),
(297,'quantify'),
(95,'quarters'),
(453,'rabbit'),
(433,'rabbits'),
(15,'rachel'),
(473,'radiography'),
(280,'raises'),
(335,'random'),
(173,'randomized'),
(40,'randomly'),
(534,'range'),
(346,'rate'),
(54,'ratio'),
(190,'receive'),
(524,'receiving'),
(482,'recovered'),
(177,'recovery'),
(344,'rectal'),
(120,'reduce'),
(247,'reduced'),
(167,'reed'),
(429,'reference'),
(452,'refinement'),
(140,'reliability'),
(484,'remained'),
(45,'replicate'),
(570,'report'),
(415,'reported'),
(286,'reporting'),
(209,'research'),
(161,'researcher'),
(391,'resistance'),
(345,'respiration'),
(200,'respiratory'),
(48,'results'),
(472,'retching'),
(394,'review'),
(227,'rising'),
(76,'risk'),
(125,'robert'),
(282,'robust'),
(38,'ross'),
(153,'routine'),
(221,'rumen'),
(256,'ruminal'),
(304,'sample'),
(92,'sampled'),
(100,'samples'),
(205,'sarah'),
(208,'science'),
(83,'scm'),
(145,'score'),
(193,'scores'),
(147,'scoring'),
(96,'screened'),
(403,'searched'),
(267,'seasons'),
(517,'seaweed'),
(90,'sectional'),
(512,'sensitivity'),
(537,'sentinels'),
(302,'separated'),
(333,'sequence'),
(541,'seropositive'),
(548,'seropositivity'),
(530,'seroprevalence'),
(427,'serum'),
(374,'setting'),
(522,'sheep'),
(551,'shunt'),
(557,'signs'),
(116,'simple'),
(560,'single'),
(233,'sixteen'),
(187,'sixty'),
(305,'size'),
(348,'slightly'),
(78,'smallholder'),
(545,'soil'),
(123,'sophie'),
(513,'specificity'),
(351,'squares'),
(475,'stabilisation'),
(417,'standards'),
(112,'staphylococcus'),
(326,'statistical'),
(263,'strategies'),
(66,'strategy'),
(219,'stress'),
(27,'strong'),
(289,'studies'),
(91,'study'),
(74,'subclinical'),
(143,'substantial'),
(119,'substantially'),
(44,'subtilis'),
(457,'successful'),
(450,'suggesting'),
(152,'suitable'),
(395,'summarise'),
(281,'summer'),
(20,'supplementation'),
(67,'support'),
(261,'supporting'),
(488,'surgery'),
(458,'surgical'),
(155,'surveillance'),
(393,'systematic'),
(121,'systems'),
(349,'table'),
(264,'target'),
(108,'teat'),
(239,'temperature'),
(229,'temperatures'),
(149,'ten'),
(98,'test'),
(137,'tested'),
(238,'thermoneutral'),
(242,'thi'),
(388,'thomas'),
(230,'threaten'),
(555,'thrift'),
(194,'times'),
(559,'tomography'),
(36,'total'),
(531,'toxoplasma'),
(499,'trained'),
(285,'transparent'),
(192,'treatment'),
(42,'treatments'),
(175,'trial'),
(317,'tube'),
(424,'turner'),
(185,'undergoing'),
(337,'values'),
(180,'variables'),
(353,'variabletnhssemp'),
(377,'variation'),
(418,'varied'),
(354,'vfa'),
(57,'villus'),
(511,'visual'),
(251,'volatile'),
(462,'volvulus'),
(389,'walker'),
(303,'washout'),
(505,'weekly'),
(51,'weight'),
(127,'welfare'),
(442,'white'),
(72,'whitfield'),
(419,'widely'),
(7,'work'),
(129,'working'),
(273,'worldwide'),
(463,'year'),
(369,'yeast'),
(224,'yield'),
(232,'yielding'),
(552,'young'),
(441,'zealand');
/*!40000 ALTER TABLE `submission_search_keyword_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_search_object_keywords`
--

DROP TABLE IF EXISTS `submission_search_object_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_search_object_keywords` (
  `submission_search_object_keyword_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) NOT NULL,
  `keyword_id` bigint(20) NOT NULL,
  `pos` int(11) NOT NULL COMMENT 'Word position of the keyword in the object.',
  PRIMARY KEY (`submission_search_object_keyword_id`),
  UNIQUE KEY `submission_search_object_keywords_unique` (`object_id`,`pos`),
  KEY `submission_search_object_keywords_object_id` (`object_id`),
  KEY `submission_search_object_keywords_keyword_id` (`keyword_id`),
  CONSTRAINT `submission_search_object_keywords_keyword_id` FOREIGN KEY (`keyword_id`) REFERENCES `submission_search_keyword_list` (`keyword_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_search_object_keywords_object_id_foreign` FOREIGN KEY (`object_id`) REFERENCES `submission_search_objects` (`object_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2022 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Relationships between search objects and keywords in the search index';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_search_object_keywords`
--

LOCK TABLES `submission_search_object_keywords` WRITE;
/*!40000 ALTER TABLE `submission_search_object_keywords` DISABLE KEYS */;
INSERT INTO `submission_search_object_keywords` VALUES
(927,50,423,0),
(928,50,424,1),
(929,50,425,2),
(930,50,426,3),
(931,51,427,0),
(932,51,428,1),
(933,51,429,2),
(934,51,430,3),
(935,51,431,4),
(936,51,432,5),
(937,51,433,6),
(938,51,434,7),
(939,51,435,8),
(940,51,436,9),
(941,51,437,10),
(942,51,350,11),
(943,52,429,0),
(944,52,430,1),
(945,52,427,2),
(946,52,428,3),
(947,52,438,4),
(948,52,439,5),
(949,52,440,6),
(950,52,188,7),
(951,52,441,8),
(952,52,442,9),
(953,52,433,10),
(954,52,436,11),
(955,52,271,12),
(956,52,443,13),
(957,52,430,14),
(958,52,444,15),
(959,52,445,16),
(960,52,446,17),
(961,52,447,18),
(962,52,400,19),
(963,52,337,20),
(964,52,448,21),
(965,52,449,22),
(966,52,450,23),
(967,52,247,24),
(968,52,451,25),
(969,52,219,26),
(970,52,327,27),
(971,52,67,28),
(972,52,452,29),
(973,52,432,30),
(974,52,453,31),
(975,52,289,32),
(976,54,432,0),
(977,54,141,1),
(978,54,453,2),
(979,54,429,3),
(980,54,430,4),
(981,54,454,5),
(982,54,428,6),
(983,54,271,7),
(984,54,443,8),
(985,58,455,0),
(986,58,456,1),
(987,59,457,0),
(988,59,458,1),
(989,59,459,2),
(990,59,460,3),
(991,59,461,4),
(992,59,462,5),
(993,59,463,6),
(994,59,464,7),
(995,59,465,8),
(996,60,463,0),
(997,60,466,1),
(998,60,464,2),
(999,60,465,3),
(1000,60,467,4),
(1001,60,468,5),
(1002,60,469,6),
(1003,60,470,7),
(1004,60,471,8),
(1005,60,472,9),
(1006,60,473,10),
(1007,60,474,11),
(1008,60,460,12),
(1009,60,461,13),
(1010,60,462,14),
(1011,60,475,15),
(1012,60,460,16),
(1013,60,476,17),
(1014,60,477,18),
(1015,60,478,19),
(1016,60,479,20),
(1017,60,480,21),
(1018,60,481,22),
(1019,60,482,23),
(1020,60,483,24),
(1021,60,484,25),
(1022,60,188,26),
(1023,60,485,27),
(1024,60,486,28),
(1025,62,481,0),
(1026,62,460,1),
(1027,62,461,2),
(1028,62,462,3),
(1029,62,479,4),
(1030,62,487,5),
(1031,62,488,6),
(1032,33,205,0),
(1033,33,206,1),
(1034,33,205,2),
(1035,33,206,3),
(1036,33,207,4),
(1037,33,4,5),
(1038,33,79,6),
(1039,33,208,7),
(1040,33,209,8),
(1041,33,210,9),
(1042,33,211,10),
(1043,33,212,11),
(1044,33,6,12),
(1045,33,12,13),
(1046,33,213,14),
(1047,33,79,15),
(1048,33,122,16),
(1049,33,157,17),
(1050,33,158,18),
(1051,33,214,19),
(1052,33,215,20),
(1053,33,216,21),
(1054,33,217,22),
(1055,34,218,0),
(1056,34,219,1),
(1057,34,220,2),
(1058,34,221,3),
(1059,34,222,4),
(1060,34,223,5),
(1061,34,224,6),
(1062,34,225,7),
(1063,34,79,8),
(1064,34,94,9),
(1065,34,173,10),
(1066,34,226,11),
(1067,34,91,12),
(1068,35,27,0),
(1069,35,28,1),
(1070,35,27,2),
(1071,35,227,3),
(1072,35,228,4),
(1073,35,229,5),
(1074,35,230,6),
(1075,35,213,7),
(1076,35,127,8),
(1077,35,231,9),
(1078,35,232,10),
(1079,35,79,11),
(1080,35,94,12),
(1081,35,27,13),
(1082,35,35,14),
(1083,35,27,15),
(1084,35,233,16),
(1085,35,234,17),
(1086,35,225,18),
(1087,35,94,19),
(1088,35,235,20),
(1089,35,173,21),
(1090,35,226,22),
(1091,35,236,23),
(1092,35,37,24),
(1093,35,237,25),
(1094,35,238,26),
(1095,35,239,27),
(1096,35,240,28),
(1097,35,241,29),
(1098,35,242,30),
(1099,35,218,31),
(1100,35,219,32),
(1101,35,242,33),
(1102,35,221,34),
(1103,35,243,35),
(1104,35,223,36),
(1105,35,224,37),
(1106,35,244,38),
(1107,35,245,39),
(1108,35,180,40),
(1109,35,246,41),
(1110,35,27,42),
(1111,35,48,43),
(1112,35,27,44),
(1113,35,218,45),
(1114,35,219,46),
(1115,35,247,47),
(1116,35,248,48),
(1117,35,249,49),
(1118,35,250,50),
(1119,35,223,51),
(1120,35,224,52),
(1121,35,37,53),
(1122,35,36,54),
(1123,35,251,55),
(1124,35,252,56),
(1125,35,253,57),
(1126,35,254,58),
(1127,35,255,59),
(1128,35,256,60),
(1129,35,257,61),
(1130,35,258,62),
(1131,35,54,63),
(1132,35,61,64),
(1133,35,27,65),
(1134,35,64,66),
(1135,35,27,67),
(1136,35,218,68),
(1137,35,219,69),
(1138,35,259,70),
(1139,35,221,71),
(1140,35,222,72),
(1141,35,260,73),
(1142,35,250,74),
(1143,35,261,75),
(1144,35,262,76),
(1145,35,263,77),
(1146,35,264,78),
(1147,35,221,79),
(1148,35,265,80),
(1149,35,266,81),
(1150,35,267,82),
(1151,37,218,0),
(1152,37,219,1),
(1153,37,79,2),
(1154,37,86,3),
(1155,37,221,4),
(1156,37,222,5),
(1157,37,239,6),
(1158,37,240,7),
(1159,37,241,8),
(1160,37,223,9),
(1161,37,224,10),
(1162,37,251,11),
(1163,37,252,12),
(1164,37,268,13),
(1165,41,218,0),
(1166,41,219,1),
(1167,41,220,2),
(1168,41,221,3),
(1169,41,222,4),
(1170,41,223,5),
(1171,41,224,6),
(1172,41,225,7),
(1173,41,79,8),
(1174,41,94,9),
(1175,41,173,10),
(1176,41,226,11),
(1177,41,91,12),
(1178,41,269,13),
(1179,41,218,14),
(1180,41,219,15),
(1181,41,270,16),
(1182,41,271,17),
(1183,41,272,18),
(1184,41,79,19),
(1185,41,34,20),
(1186,41,273,21),
(1187,41,239,22),
(1188,41,240,23),
(1189,41,241,24),
(1190,41,242,25),
(1191,41,274,26),
(1192,41,275,27),
(1193,41,231,28),
(1194,41,232,29),
(1195,41,94,30),
(1196,41,276,31),
(1197,41,120,32),
(1198,41,9,33),
(1199,41,250,34),
(1200,41,223,35),
(1201,41,224,36),
(1202,41,17,37),
(1203,41,277,38),
(1204,41,278,39),
(1205,41,211,40),
(1206,41,279,41),
(1207,41,280,42),
(1208,41,281,43),
(1209,41,229,44),
(1210,41,282,45),
(1211,41,283,46),
(1212,41,284,47),
(1213,41,285,48),
(1214,41,286,49),
(1215,41,287,50),
(1216,41,288,51),
(1217,41,151,52),
(1218,41,289,53),
(1219,41,154,54),
(1220,41,290,55),
(1221,41,7,56),
(1222,41,291,57),
(1223,41,34,58),
(1224,41,292,59),
(1225,41,247,60),
(1226,41,248,61),
(1227,41,249,62),
(1228,41,250,63),
(1229,41,293,64),
(1230,41,17,65),
(1231,41,218,66),
(1232,41,294,67),
(1233,41,221,68),
(1234,41,222,69),
(1235,41,295,70),
(1236,41,296,71),
(1237,41,91,72),
(1238,41,297,73),
(1239,41,221,74),
(1240,41,222,75),
(1241,41,223,76),
(1242,41,224,77),
(1243,41,223,78),
(1244,41,244,79),
(1245,41,298,80),
(1246,41,218,81),
(1247,41,219,82),
(1248,41,299,83),
(1249,41,300,84),
(1250,41,250,85),
(1251,41,301,86),
(1252,41,35,87),
(1253,41,141,88),
(1254,41,236,89),
(1255,41,233,90),
(1256,41,234,91),
(1257,41,225,92),
(1258,41,94,93),
(1259,41,47,94),
(1260,41,223,95),
(1261,41,50,96),
(1262,41,51,97),
(1263,41,235,98),
(1264,41,173,99),
(1265,41,226,100),
(1266,41,236,101),
(1267,41,37,102),
(1268,41,237,103),
(1269,41,302,104),
(1270,41,37,105),
(1271,41,303,106),
(1272,41,304,107),
(1273,41,305,108),
(1274,41,306,109),
(1275,41,307,110),
(1276,41,308,111),
(1277,41,37,112),
(1278,41,309,113),
(1279,41,223,114),
(1280,41,224,115),
(1281,41,310,116),
(1282,41,91,117),
(1283,41,311,118),
(1284,41,312,119),
(1285,41,313,120),
(1286,41,314,121),
(1287,41,221,122),
(1288,41,243,123),
(1289,41,315,124),
(1290,41,316,125),
(1291,41,256,126),
(1292,41,317,127),
(1293,41,47,128),
(1294,41,318,129),
(1295,41,251,130),
(1296,41,252,131),
(1297,41,268,132),
(1298,41,246,133),
(1299,41,319,134),
(1300,41,320,135),
(1301,41,221,136),
(1302,41,321,137),
(1303,41,322,138),
(1304,41,323,139),
(1305,41,324,140),
(1306,41,325,141),
(1307,41,326,142),
(1308,41,324,143),
(1309,41,327,144),
(1310,41,328,145),
(1311,41,329,146),
(1312,41,330,147),
(1313,41,17,148),
(1314,41,331,149),
(1315,41,332,150),
(1316,41,192,151),
(1317,41,318,152),
(1318,41,333,153),
(1319,41,334,154),
(1320,41,17,155),
(1321,41,86,156),
(1322,41,335,157),
(1323,41,336,158),
(1324,41,337,159),
(1325,41,338,160),
(1326,41,339,161),
(1327,41,340,162),
(1328,41,341,163),
(1329,41,342,164),
(1330,41,343,165),
(1331,41,48,166),
(1332,41,218,167),
(1333,41,219,168),
(1334,41,61,169),
(1335,41,344,170),
(1336,41,239,171),
(1337,41,345,172),
(1338,41,346,173),
(1339,41,247,174),
(1340,41,248,175),
(1341,41,249,176),
(1342,41,250,177),
(1343,41,223,178),
(1344,41,224,179),
(1345,41,255,180),
(1346,41,37,181),
(1347,41,223,182),
(1348,41,347,183),
(1349,41,254,184),
(1350,41,255,185),
(1351,41,348,186),
(1352,41,349,187),
(1353,41,349,188),
(1354,41,34,189),
(1355,41,221,190),
(1356,41,180,191),
(1357,41,238,192),
(1358,41,218,193),
(1359,41,219,194),
(1360,41,350,195),
(1361,41,351,196),
(1362,41,352,197),
(1363,41,353,198),
(1364,41,248,199),
(1365,41,249,200),
(1366,41,250,201),
(1367,41,223,202),
(1368,41,224,203),
(1369,41,223,204),
(1370,41,347,205),
(1371,41,36,206),
(1372,41,354,207),
(1373,41,355,208),
(1374,41,256,209),
(1375,41,356,210),
(1376,41,247,211),
(1377,41,251,212),
(1378,41,252,213),
(1379,41,253,214),
(1380,41,34,215),
(1381,41,218,216),
(1382,41,219,217),
(1383,41,357,218),
(1384,41,358,219),
(1385,41,248,220),
(1386,41,249,221),
(1387,41,250,222),
(1388,41,359,223),
(1389,41,360,224),
(1390,41,36,225),
(1391,41,251,226),
(1392,41,252,227),
(1393,41,268,228),
(1394,41,361,229),
(1395,41,110,230),
(1396,41,256,231),
(1397,41,247,232),
(1398,41,362,233),
(1399,41,363,234),
(1400,41,364,235),
(1401,41,365,236),
(1402,41,250,237),
(1403,41,293,238),
(1404,41,17,239),
(1405,41,218,240),
(1406,41,294,241),
(1407,41,221,242),
(1408,41,366,243),
(1409,41,367,244),
(1410,41,67,245),
(1411,41,262,246),
(1412,41,263,247),
(1413,41,264,248),
(1414,41,221,249),
(1415,41,265,250),
(1416,41,266,251),
(1417,41,267,252),
(1418,41,368,253),
(1419,41,369,254),
(1420,41,370,255),
(1421,41,371,256),
(1422,41,372,257),
(1423,41,298,258),
(1424,41,373,259),
(1425,41,374,260),
(1426,41,375,261),
(1427,41,376,262),
(1428,41,239,263),
(1429,41,377,264),
(1430,41,378,265),
(1431,41,88,266),
(1432,41,379,267),
(1433,41,289,268),
(1434,41,372,269),
(1435,41,380,270),
(1436,41,80,271),
(1437,41,381,272),
(1438,41,382,273),
(1439,41,237,274),
(1440,41,64,275),
(1441,41,218,276),
(1442,41,219,277),
(1443,41,259,278),
(1444,41,221,279),
(1445,41,222,280),
(1446,41,223,281),
(1447,41,34,282),
(1448,41,225,283),
(1449,41,94,284),
(1450,41,383,285),
(1451,41,384,286),
(1452,41,271,287),
(1453,41,385,288),
(1454,41,18,289),
(1455,41,263,290),
(1456,41,67,291),
(1457,41,221,292),
(1458,41,265,293),
(1459,42,386,0),
(1460,42,387,1),
(1461,42,388,2),
(1462,42,389,3),
(1463,43,390,0),
(1464,43,391,1),
(1465,43,392,2),
(1466,43,141,3),
(1467,43,393,4),
(1468,43,394,5),
(1469,43,155,6),
(1470,43,327,7),
(1471,44,27,0),
(1472,44,81,1),
(1473,44,27,2),
(1474,44,395,3),
(1475,44,155,4),
(1476,44,327,5),
(1477,44,390,6),
(1478,44,391,7),
(1479,44,396,8),
(1480,44,397,9),
(1481,44,398,10),
(1482,44,399,11),
(1483,44,172,12),
(1484,44,400,13),
(1485,44,27,14),
(1486,44,35,15),
(1487,44,27,16),
(1488,44,401,17),
(1489,44,402,18),
(1490,44,403,19),
(1491,44,289,20),
(1492,44,404,21),
(1493,44,405,22),
(1494,44,406,23),
(1495,44,76,24),
(1496,44,407,25),
(1497,44,408,26),
(1498,44,27,27),
(1499,44,48,28),
(1500,44,27,29),
(1501,44,391,30),
(1502,44,409,31),
(1503,44,410,32),
(1504,44,411,33),
(1505,44,412,34),
(1506,44,413,35),
(1507,44,414,36),
(1508,44,391,37),
(1509,44,415,38),
(1510,44,112,39),
(1511,44,416,40),
(1512,44,398,41),
(1513,44,286,42),
(1514,44,417,43),
(1515,44,418,44),
(1516,44,419,45),
(1517,44,27,46),
(1518,44,64,47),
(1519,44,27,48),
(1520,44,420,49),
(1521,44,155,50),
(1522,44,392,51),
(1523,44,141,52),
(1524,44,421,53),
(1525,44,12,54),
(1526,44,422,55),
(1527,46,390,0),
(1528,46,391,1),
(1529,46,399,2),
(1530,46,172,3),
(1531,46,155,4),
(1532,46,393,5),
(1533,46,394,6),
(1534,46,12,7),
(1535,17,123,0),
(1536,17,124,1),
(1537,17,125,2),
(1538,17,126,3),
(1539,18,127,0),
(1540,18,128,1),
(1541,18,129,2),
(1542,18,130,3),
(1543,18,131,4),
(1544,18,132,5),
(1545,18,133,6),
(1546,19,134,0),
(1547,19,132,1),
(1548,19,127,2),
(1549,19,133,3),
(1550,19,129,4),
(1551,19,135,5),
(1552,19,136,6),
(1553,19,137,7),
(1554,19,138,8),
(1555,19,139,9),
(1556,19,140,10),
(1557,19,141,11),
(1558,19,142,12),
(1559,19,143,13),
(1560,19,50,14),
(1561,19,144,15),
(1562,19,145,16),
(1563,19,146,17),
(1564,19,147,18),
(1565,19,133,19),
(1566,19,148,20),
(1567,19,149,21),
(1568,19,150,22),
(1569,19,151,23),
(1570,19,152,24),
(1571,19,153,25),
(1572,19,154,26),
(1573,19,155,27),
(1574,21,151,0),
(1575,21,127,1),
(1576,21,156,2),
(1577,21,129,3),
(1578,21,130,4),
(1579,21,50,5),
(1580,21,144,6),
(1581,21,145,7),
(1582,1,1,0),
(1583,1,2,1),
(1584,1,1,2),
(1585,1,2,3),
(1586,1,3,4),
(1587,1,4,5),
(1588,1,5,6),
(1589,1,6,7),
(1590,1,7,8),
(1591,1,8,9),
(1592,1,9,10),
(1593,1,10,11),
(1594,1,11,12),
(1595,1,12,13),
(1596,1,13,14),
(1597,1,14,15),
(1598,1,15,16),
(1599,1,16,17),
(1600,2,17,0),
(1601,2,18,1),
(1602,2,19,2),
(1603,2,20,3),
(1604,2,21,4),
(1605,2,22,5),
(1606,2,23,6),
(1607,2,24,7),
(1608,2,25,8),
(1609,2,26,9),
(1610,3,27,0),
(1611,3,28,1),
(1612,3,27,2),
(1613,3,29,3),
(1614,3,30,4),
(1615,3,31,5),
(1616,3,32,6),
(1617,3,21,7),
(1618,3,33,8),
(1619,3,5,9),
(1620,3,34,10),
(1621,3,27,11),
(1622,3,35,12),
(1623,3,27,13),
(1624,3,36,14),
(1625,3,37,15),
(1626,3,38,16),
(1627,3,39,17),
(1628,3,40,18),
(1629,3,41,19),
(1630,3,18,20),
(1631,3,42,21),
(1632,3,43,22),
(1633,3,44,23),
(1634,3,19,24),
(1635,3,45,25),
(1636,3,46,26),
(1637,3,47,27),
(1638,3,27,28),
(1639,3,48,29),
(1640,3,27,30),
(1641,3,20,31),
(1642,3,49,32),
(1643,3,50,33),
(1644,3,51,34),
(1645,3,52,35),
(1646,3,9,36),
(1647,3,53,37),
(1648,3,54,38),
(1649,3,55,39),
(1650,3,56,40),
(1651,3,57,41),
(1652,3,58,42),
(1653,3,57,43),
(1654,3,59,44),
(1655,3,54,45),
(1656,3,60,46),
(1657,3,61,47),
(1658,3,62,48),
(1659,3,63,49),
(1660,3,27,50),
(1661,3,64,51),
(1662,3,27,52),
(1663,3,18,53),
(1664,3,44,54),
(1665,3,65,55),
(1666,3,66,56),
(1667,3,67,57),
(1668,3,21,58),
(1669,3,23,59),
(1670,3,68,60),
(1671,3,39,61),
(1672,5,25,0),
(1673,5,19,1),
(1674,5,43,2),
(1675,5,44,3),
(1676,5,57,4),
(1677,5,58,5),
(1678,5,9,6),
(1679,5,53,7),
(1680,5,54,8),
(1681,9,69,0),
(1682,9,70,1),
(1683,9,71,2),
(1684,9,72,3),
(1685,10,73,0),
(1686,10,74,1),
(1687,10,75,2),
(1688,10,76,3),
(1689,10,77,4),
(1690,10,78,5),
(1691,10,79,6),
(1692,10,80,7),
(1693,11,27,0),
(1694,11,81,1),
(1695,11,27,2),
(1696,11,82,3),
(1697,11,73,4),
(1698,11,74,5),
(1699,11,75,6),
(1700,11,83,7),
(1701,11,84,8),
(1702,11,85,9),
(1703,11,86,10),
(1704,11,87,11),
(1705,11,76,12),
(1706,11,77,13),
(1707,11,78,14),
(1708,11,79,15),
(1709,11,88,16),
(1710,11,27,17),
(1711,11,35,18),
(1712,11,27,19),
(1713,11,89,20),
(1714,11,90,21),
(1715,11,91,22),
(1716,11,92,23),
(1717,11,93,24),
(1718,11,94,25),
(1719,11,80,26),
(1720,11,95,27),
(1721,11,96,28),
(1722,11,97,29),
(1723,11,75,30),
(1724,11,98,31),
(1725,11,99,32),
(1726,11,100,33),
(1727,11,101,34),
(1728,11,27,35),
(1729,11,48,36),
(1730,11,27,37),
(1731,11,86,38),
(1732,11,87,39),
(1733,11,83,40),
(1734,11,73,41),
(1735,11,102,42),
(1736,11,103,43),
(1737,11,104,44),
(1738,11,105,45),
(1739,11,106,46),
(1740,11,107,47),
(1741,11,108,48),
(1742,11,109,49),
(1743,11,110,50),
(1744,11,111,51),
(1745,11,83,52),
(1746,11,112,53),
(1747,11,113,54),
(1748,11,114,55),
(1749,11,115,56),
(1750,11,27,57),
(1751,11,64,58),
(1752,11,27,59),
(1753,11,116,60),
(1754,11,117,61),
(1755,11,118,62),
(1756,11,119,63),
(1757,11,120,64),
(1758,11,83,65),
(1759,11,78,66),
(1760,11,121,67),
(1761,13,79,0),
(1762,13,122,1),
(1763,13,74,2),
(1764,13,75,3),
(1765,13,97,4),
(1766,13,75,5),
(1767,13,98,6),
(1768,13,76,7),
(1769,13,77,8),
(1770,13,78,9),
(1771,25,157,0),
(1772,25,158,1),
(1773,25,157,2),
(1774,25,158,3),
(1775,25,159,4),
(1776,25,160,5),
(1777,25,98,6),
(1778,25,161,7),
(1779,25,162,8),
(1780,25,159,9),
(1781,25,163,10),
(1782,25,164,11),
(1783,25,165,12),
(1784,25,166,13),
(1785,25,167,14),
(1786,26,168,0),
(1787,26,169,1),
(1788,26,170,2),
(1789,26,171,3),
(1790,26,172,4),
(1791,26,173,5),
(1792,26,174,6),
(1793,26,175,7),
(1794,27,27,0),
(1795,27,81,1),
(1796,27,27,2),
(1797,27,176,3),
(1798,27,177,4),
(1799,27,178,5),
(1800,27,179,6),
(1801,27,180,7),
(1802,27,181,8),
(1803,27,182,9),
(1804,27,183,10),
(1805,27,184,11),
(1806,27,170,12),
(1807,27,172,13),
(1808,27,185,14),
(1809,27,186,15),
(1810,27,171,16),
(1811,27,27,17),
(1812,27,35,18),
(1813,27,27,19),
(1814,27,187,20),
(1815,27,188,21),
(1816,27,172,22),
(1817,27,40,23),
(1818,27,189,24),
(1819,27,190,25),
(1820,27,133,26),
(1821,27,191,27),
(1822,27,174,28),
(1823,27,192,29),
(1824,27,27,30),
(1825,27,48,31),
(1826,27,27,32),
(1827,27,177,33),
(1828,27,193,34),
(1829,27,194,35),
(1830,27,195,36),
(1831,27,196,37),
(1832,27,197,38),
(1833,27,106,39),
(1834,27,184,40),
(1835,27,198,41),
(1836,27,114,42),
(1837,27,181,43),
(1838,27,27,44),
(1839,27,64,45),
(1840,27,27,46),
(1841,27,170,47),
(1842,27,152,48),
(1843,27,181,49),
(1844,27,199,50),
(1845,27,200,51),
(1846,27,201,52),
(1847,27,202,53),
(1848,29,203,0),
(1849,29,204,1),
(1850,29,181,2),
(1851,29,182,3),
(1852,29,171,4),
(1853,66,205,0),
(1854,66,206,1),
(1855,66,388,2),
(1856,66,389,3),
(1857,67,489,0),
(1858,67,490,1),
(1859,67,491,2),
(1860,67,79,3),
(1861,67,94,4),
(1862,67,492,5),
(1863,67,327,6),
(1864,67,493,7),
(1865,67,494,8),
(1866,67,495,9),
(1867,68,491,0),
(1868,68,496,1),
(1869,68,127,2),
(1870,68,497,3),
(1871,68,79,4),
(1872,68,80,5),
(1873,68,498,6),
(1874,68,103,7),
(1875,68,499,8),
(1876,68,500,9),
(1877,68,501,10),
(1878,68,331,11),
(1879,68,502,12),
(1880,68,503,13),
(1881,68,492,14),
(1882,68,327,15),
(1883,68,225,16),
(1884,68,94,17),
(1885,68,55,18),
(1886,68,504,19),
(1887,68,505,20),
(1888,68,506,21),
(1889,68,193,22),
(1890,68,507,23),
(1891,68,508,24),
(1892,68,509,25),
(1893,68,94,26),
(1894,68,510,27),
(1895,68,47,28),
(1896,68,511,29),
(1897,68,147,30),
(1898,68,512,31),
(1899,68,513,32),
(1900,70,491,0),
(1901,70,79,1),
(1902,70,86,2),
(1903,70,492,3),
(1904,70,493,4),
(1905,70,494,5),
(1906,70,514,6),
(1907,70,515,7),
(1908,70,516,8),
(1909,74,166,0),
(1910,74,167,1),
(1911,74,164,2),
(1912,74,165,3),
(1913,75,18,0),
(1914,75,517,1),
(1915,75,20,2),
(1916,75,518,3),
(1917,75,519,4),
(1918,75,520,5),
(1919,75,521,6),
(1920,75,522,7),
(1921,76,246,0),
(1922,76,518,1),
(1923,76,519,2),
(1924,76,521,3),
(1925,76,523,4),
(1926,76,524,5),
(1927,76,18,6),
(1928,76,525,7),
(1929,76,47,8),
(1930,76,519,9),
(1931,76,224,10),
(1932,76,526,11),
(1933,76,527,12),
(1934,76,405,13),
(1935,76,346,14),
(1936,76,528,15),
(1937,76,529,16),
(1938,76,51,17),
(1939,76,52,18),
(1940,78,519,0),
(1941,78,522,1),
(1942,78,517,2),
(1943,78,525,3),
(1944,78,521,4),
(1945,82,386,0),
(1946,82,387,1),
(1947,82,125,2),
(1948,82,126,3),
(1949,83,530,0),
(1950,83,531,1),
(1951,83,532,2),
(1952,83,533,3),
(1953,83,534,4),
(1954,83,535,5),
(1955,83,26,6),
(1956,83,536,7),
(1957,83,76,8),
(1958,83,77,9),
(1959,84,533,0),
(1960,84,534,1),
(1961,84,26,2),
(1962,84,537,3),
(1963,84,271,4),
(1964,84,538,5),
(1965,84,531,6),
(1966,84,532,7),
(1967,84,539,8),
(1968,84,26,9),
(1969,84,540,10),
(1970,84,541,11),
(1971,84,131,12),
(1972,84,542,13),
(1973,84,98,14),
(1974,84,543,15),
(1975,84,544,16),
(1976,84,545,17),
(1977,84,546,18),
(1978,84,547,19),
(1979,84,548,20),
(1980,86,531,0),
(1981,86,532,1),
(1982,86,26,2),
(1983,86,530,3),
(1984,86,12,4),
(1985,90,425,0),
(1986,90,426,1),
(1987,91,458,0),
(1988,91,459,1),
(1989,91,549,2),
(1990,91,550,3),
(1991,91,551,4),
(1992,91,552,5),
(1993,91,553,6),
(1994,92,485,0),
(1995,92,553,1),
(1996,92,467,2),
(1997,92,554,3),
(1998,92,555,4),
(1999,92,556,5),
(2000,92,557,6),
(2001,92,558,7),
(2002,92,559,8),
(2003,92,474,9),
(2004,92,560,10),
(2005,92,561,11),
(2006,92,551,12),
(2007,92,562,13),
(2008,92,563,14),
(2009,92,564,15),
(2010,92,565,16),
(2011,92,440,17),
(2012,92,566,18),
(2013,92,567,19),
(2014,92,488,20),
(2015,94,553,0),
(2016,94,550,1),
(2017,94,551,2),
(2018,94,568,3),
(2019,94,488,4),
(2020,94,569,5),
(2021,94,570,6);
/*!40000 ALTER TABLE `submission_search_object_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_search_objects`
--

DROP TABLE IF EXISTS `submission_search_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_search_objects` (
  `object_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) NOT NULL,
  `type` int(11) NOT NULL COMMENT 'Type of item. E.g., abstract, fulltext, etc.',
  `assoc_id` bigint(20) DEFAULT NULL COMMENT 'Optional ID of an associated record (e.g., a file_id)',
  PRIMARY KEY (`object_id`),
  KEY `submission_search_objects_submission_id` (`submission_id`),
  CONSTRAINT `submission_search_object_submission` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A list of all search objects indexed in the search index';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_search_objects`
--

LOCK TABLES `submission_search_objects` WRITE;
/*!40000 ALTER TABLE `submission_search_objects` DISABLE KEYS */;
INSERT INTO `submission_search_objects` VALUES
(1,1,1,NULL),
(2,1,2,NULL),
(3,1,4,NULL),
(4,1,16,NULL),
(5,1,17,NULL),
(6,1,8,NULL),
(7,1,32,NULL),
(8,1,64,NULL),
(9,2,1,NULL),
(10,2,2,NULL),
(11,2,4,NULL),
(12,2,16,NULL),
(13,2,17,NULL),
(14,2,8,NULL),
(15,2,32,NULL),
(16,2,64,NULL),
(17,3,1,NULL),
(18,3,2,NULL),
(19,3,4,NULL),
(20,3,16,NULL),
(21,3,17,NULL),
(22,3,8,NULL),
(23,3,32,NULL),
(24,3,64,NULL),
(25,4,1,NULL),
(26,4,2,NULL),
(27,4,4,NULL),
(28,4,16,NULL),
(29,4,17,NULL),
(30,4,8,NULL),
(31,4,32,NULL),
(32,4,64,NULL),
(33,5,1,NULL),
(34,5,2,NULL),
(35,5,4,NULL),
(36,5,16,NULL),
(37,5,17,NULL),
(38,5,8,NULL),
(39,5,32,NULL),
(40,5,64,NULL),
(41,5,128,6),
(42,6,1,NULL),
(43,6,2,NULL),
(44,6,4,NULL),
(45,6,16,NULL),
(46,6,17,NULL),
(47,6,8,NULL),
(48,6,32,NULL),
(49,6,64,NULL),
(50,7,1,NULL),
(51,7,2,NULL),
(52,7,4,NULL),
(53,7,16,NULL),
(54,7,17,NULL),
(55,7,8,NULL),
(56,7,32,NULL),
(57,7,64,NULL),
(58,8,1,NULL),
(59,8,2,NULL),
(60,8,4,NULL),
(61,8,16,NULL),
(62,8,17,NULL),
(63,8,8,NULL),
(64,8,32,NULL),
(65,8,64,NULL),
(66,9,1,NULL),
(67,9,2,NULL),
(68,9,4,NULL),
(69,9,16,NULL),
(70,9,17,NULL),
(71,9,8,NULL),
(72,9,32,NULL),
(73,9,64,NULL),
(74,10,1,NULL),
(75,10,2,NULL),
(76,10,4,NULL),
(77,10,16,NULL),
(78,10,17,NULL),
(79,10,8,NULL),
(80,10,32,NULL),
(81,10,64,NULL),
(82,11,1,NULL),
(83,11,2,NULL),
(84,11,4,NULL),
(85,11,16,NULL),
(86,11,17,NULL),
(87,11,8,NULL),
(88,11,32,NULL),
(89,11,64,NULL),
(90,12,1,NULL),
(91,12,2,NULL),
(92,12,4,NULL),
(93,12,16,NULL),
(94,12,17,NULL),
(95,12,8,NULL),
(96,12,32,NULL),
(97,12,64,NULL);
/*!40000 ALTER TABLE `submission_search_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_settings`
--

DROP TABLE IF EXISTS `submission_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_settings` (
  `submission_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`submission_setting_id`),
  UNIQUE KEY `submission_settings_unique` (`submission_id`,`locale`,`setting_name`),
  KEY `submission_settings_submission_id` (`submission_id`),
  CONSTRAINT `submission_settings_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Localized data about submissions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_settings`
--

LOCK TABLES `submission_settings` WRITE;
/*!40000 ALTER TABLE `submission_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `submissions` (
  `submission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `current_publication_id` bigint(20) DEFAULT NULL,
  `date_last_activity` datetime DEFAULT NULL,
  `date_submitted` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `stage_id` bigint(20) NOT NULL DEFAULT 1,
  `locale` varchar(28) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT 1,
  `submission_progress` varchar(50) NOT NULL DEFAULT 'start',
  `work_type` smallint(6) DEFAULT 0,
  PRIMARY KEY (`submission_id`),
  KEY `submissions_context_id` (`context_id`),
  KEY `submissions_publication_id` (`current_publication_id`),
  CONSTRAINT `submissions_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `submissions_publication_id` FOREIGN KEY (`current_publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='All submissions submitted to the context, including incomplete, declined and unpublished submissions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissions`
--

LOCK TABLES `submissions` WRITE;
/*!40000 ALTER TABLE `submissions` DISABLE KEYS */;
INSERT INTO `submissions` VALUES
(1,1,1,'2026-09-25 16:09:35','2025-11-02 00:00:00','2026-09-25 16:09:35',5,'en',3,'',0),
(2,1,2,'2026-09-25 16:09:36','2025-10-18 00:00:00','2026-09-25 16:09:36',5,'en',3,'',0),
(3,1,3,'2026-09-25 16:09:36','2025-12-01 00:00:00','2026-09-25 16:09:36',5,'en',3,'',0),
(4,1,4,'2026-09-25 16:09:36','2025-09-27 00:00:00','2026-09-25 16:09:36',5,'en',3,'',0),
(5,1,5,'2026-09-25 16:09:36','2026-02-11 00:00:00','2026-09-25 16:09:36',5,'en',3,'',0),
(6,1,6,'2026-09-25 16:09:36','2026-01-20 00:00:00','2026-09-25 16:09:36',5,'en',3,'',0),
(7,1,7,'2026-09-25 16:09:36','2026-03-03 00:00:00','2026-09-25 16:09:36',5,'en',3,'',0),
(8,1,8,'2026-09-25 16:09:36','2026-02-26 00:00:00','2026-09-25 16:09:36',5,'en',3,'',0),
(9,1,9,'2026-09-25 17:47:52','2026-09-22 00:00:00','2026-09-25 17:47:52',1,'en',1,'',0),
(10,1,10,'2026-10-06 21:08:52','2026-09-18 00:00:00','2026-09-25 17:47:52',3,'en',1,'',0),
(11,1,11,'2026-09-25 17:47:52','2026-06-30 00:00:00','2026-09-25 17:47:52',4,'en',1,'',0),
(12,1,12,'2026-09-25 17:47:52','2026-05-12 00:00:00','2026-09-25 17:47:52',5,'en',1,'',0);
/*!40000 ALTER TABLE `submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_type_settings`
--

DROP TABLE IF EXISTS `subscription_type_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_type_settings` (
  `subscription_type_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`subscription_type_setting_id`),
  UNIQUE KEY `subscription_type_settings_unique` (`type_id`,`locale`,`setting_name`),
  KEY `subscription_type_settings_type_id` (`type_id`),
  CONSTRAINT `subscription_type_settings_type_id` FOREIGN KEY (`type_id`) REFERENCES `subscription_types` (`type_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about subscription types, including localized properties such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_type_settings`
--

LOCK TABLES `subscription_type_settings` WRITE;
/*!40000 ALTER TABLE `subscription_type_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_type_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_types`
--

DROP TABLE IF EXISTS `subscription_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_types` (
  `type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `journal_id` bigint(20) NOT NULL,
  `cost` decimal(8,2) unsigned NOT NULL,
  `currency_code_alpha` varchar(3) NOT NULL,
  `duration` smallint(6) DEFAULT NULL,
  `format` smallint(6) NOT NULL,
  `institutional` smallint(6) NOT NULL DEFAULT 0,
  `membership` smallint(6) NOT NULL DEFAULT 0,
  `disable_public_display` smallint(6) NOT NULL,
  `seq` double NOT NULL,
  PRIMARY KEY (`type_id`),
  KEY `subscription_types_journal_id` (`journal_id`),
  CONSTRAINT `subscription_types_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Subscription types represent the kinds of subscriptions that a user or institution may have, such as an annual subscription or a discounted subscription.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_types`
--

LOCK TABLES `subscription_types` WRITE;
/*!40000 ALTER TABLE `subscription_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `subscription_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `journal_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `type_id` bigint(20) NOT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT 1,
  `membership` varchar(40) DEFAULT NULL,
  `reference_number` varchar(40) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`subscription_id`),
  KEY `subscriptions_journal_id` (`journal_id`),
  KEY `subscriptions_user_id` (`user_id`),
  KEY `subscriptions_type_id` (`type_id`),
  CONSTRAINT `subscriptions_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_type_id` FOREIGN KEY (`type_id`) REFERENCES `subscription_types` (`type_id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='A list of subscriptions, both institutional and individual, for journals that use subscription-based publishing.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temporary_files`
--

DROP TABLE IF EXISTS `temporary_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `temporary_files` (
  `file_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `file_name` varchar(90) NOT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) NOT NULL,
  `original_file_name` varchar(127) DEFAULT NULL,
  `date_uploaded` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  KEY `temporary_files_user_id` (`user_id`),
  CONSTRAINT `temporary_files_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Temporary files, e.g. where files are kept during an upload process before they are moved somewhere more appropriate.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporary_files`
--

LOCK TABLES `temporary_files` WRITE;
/*!40000 ALTER TABLE `temporary_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `temporary_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_stats_institution_temporary_records`
--

DROP TABLE IF EXISTS `usage_stats_institution_temporary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_stats_institution_temporary_records` (
  `usage_stats_temp_institution_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `line_number` bigint(20) NOT NULL,
  `institution_id` bigint(20) NOT NULL,
  PRIMARY KEY (`usage_stats_temp_institution_id`),
  UNIQUE KEY `usitr_load_id_line_number_institution_id` (`load_id`,`line_number`,`institution_id`),
  KEY `usi_institution_id` (`institution_id`),
  CONSTRAINT `usi_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Temporary stats for views and downloads from institutions based on visitor log records. Data in this table is provisional. See the metrics_* tables for compiled stats.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_stats_institution_temporary_records`
--

LOCK TABLES `usage_stats_institution_temporary_records` WRITE;
/*!40000 ALTER TABLE `usage_stats_institution_temporary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_stats_institution_temporary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_stats_total_temporary_records`
--

DROP TABLE IF EXISTS `usage_stats_total_temporary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_stats_total_temporary_records` (
  `usage_stats_temp_total_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(64) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `line_number` bigint(20) NOT NULL,
  `canonical_url` varchar(255) NOT NULL,
  `issue_id` bigint(20) DEFAULT NULL,
  `issue_galley_id` bigint(20) DEFAULT NULL,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) DEFAULT NULL,
  `representation_id` bigint(20) DEFAULT NULL,
  `submission_file_id` bigint(20) unsigned DEFAULT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `file_type` smallint(6) DEFAULT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `load_id` varchar(50) NOT NULL,
  PRIMARY KEY (`usage_stats_temp_total_id`),
  KEY `usage_stats_total_temporary_records_issue_id` (`issue_id`),
  KEY `usage_stats_total_temporary_records_issue_galley_id` (`issue_galley_id`),
  KEY `usage_stats_total_temporary_records_context_id` (`context_id`),
  KEY `usage_stats_total_temporary_records_submission_id` (`submission_id`),
  KEY `usage_stats_total_temporary_records_representation_id` (`representation_id`),
  KEY `usage_stats_total_temporary_records_submission_file_id` (`submission_file_id`),
  KEY `ust_load_id_context_id_ip_ua_url` (`load_id`,`context_id`,`ip`,`user_agent`,`canonical_url`),
  CONSTRAINT `ust_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_issue_galley_id_foreign` FOREIGN KEY (`issue_galley_id`) REFERENCES `issue_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_issue_id_foreign` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_representation_id_foreign` FOREIGN KEY (`representation_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Temporary stats totals based on visitor log records. Data in this table is provisional. See the metrics_* tables for compiled stats.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_stats_total_temporary_records`
--

LOCK TABLES `usage_stats_total_temporary_records` WRITE;
/*!40000 ALTER TABLE `usage_stats_total_temporary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_stats_total_temporary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_stats_unique_item_investigations_temporary_records`
--

DROP TABLE IF EXISTS `usage_stats_unique_item_investigations_temporary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_stats_unique_item_investigations_temporary_records` (
  `usage_stats_temp_unique_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(64) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `line_number` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `representation_id` bigint(20) DEFAULT NULL,
  `submission_file_id` bigint(20) unsigned DEFAULT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `file_type` smallint(6) DEFAULT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `load_id` varchar(50) NOT NULL,
  PRIMARY KEY (`usage_stats_temp_unique_item_id`),
  KEY `usii_context_id` (`context_id`),
  KEY `usii_submission_id` (`submission_id`),
  KEY `usii_representation_id` (`representation_id`),
  KEY `usii_submission_file_id` (`submission_file_id`),
  KEY `usii_load_id_context_id_ip_ua` (`load_id`,`context_id`,`ip`,`user_agent`),
  CONSTRAINT `usii_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `usii_representation_id_foreign` FOREIGN KEY (`representation_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `usii_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `usii_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Temporary stats on unique downloads based on visitor log records. Data in this table is provisional. See the metrics_* tables for compiled stats.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_stats_unique_item_investigations_temporary_records`
--

LOCK TABLES `usage_stats_unique_item_investigations_temporary_records` WRITE;
/*!40000 ALTER TABLE `usage_stats_unique_item_investigations_temporary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_stats_unique_item_investigations_temporary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_stats_unique_item_requests_temporary_records`
--

DROP TABLE IF EXISTS `usage_stats_unique_item_requests_temporary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_stats_unique_item_requests_temporary_records` (
  `usage_stats_temp_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(64) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `line_number` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `representation_id` bigint(20) DEFAULT NULL,
  `submission_file_id` bigint(20) unsigned DEFAULT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `file_type` smallint(6) DEFAULT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `load_id` varchar(50) NOT NULL,
  PRIMARY KEY (`usage_stats_temp_item_id`),
  KEY `usir_context_id` (`context_id`),
  KEY `usir_submission_id` (`submission_id`),
  KEY `usir_representation_id` (`representation_id`),
  KEY `usir_submission_file_id` (`submission_file_id`),
  KEY `usir_load_id_context_id_ip_ua` (`load_id`,`context_id`,`ip`,`user_agent`),
  CONSTRAINT `usir_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `usir_representation_id_foreign` FOREIGN KEY (`representation_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `usir_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `usir_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Temporary stats on unique views based on visitor log records. Data in this table is provisional. See the metrics_* tables for compiled stats.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_stats_unique_item_requests_temporary_records`
--

LOCK TABLES `usage_stats_unique_item_requests_temporary_records` WRITE;
/*!40000 ALTER TABLE `usage_stats_unique_item_requests_temporary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_stats_unique_item_requests_temporary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_settings`
--

DROP TABLE IF EXISTS `user_group_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group_settings` (
  `user_group_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_group_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`user_group_setting_id`),
  UNIQUE KEY `user_group_settings_unique` (`user_group_id`,`locale`,`setting_name`),
  KEY `user_group_settings_user_group_id` (`user_group_id`),
  CONSTRAINT `user_group_settings_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about user groups, including localized properties such as the name.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_settings`
--

LOCK TABLES `user_group_settings` WRITE;
/*!40000 ALTER TABLE `user_group_settings` DISABLE KEYS */;
INSERT INTO `user_group_settings` VALUES
(1,2,'','nameLocaleKey','default.groups.name.manager'),
(2,2,'','abbrevLocaleKey','default.groups.abbrev.manager'),
(3,2,'en','name','Journal manager'),
(4,2,'en','abbrev','JM'),
(5,3,'','nameLocaleKey','default.groups.name.editor'),
(6,3,'','abbrevLocaleKey','default.groups.abbrev.editor'),
(7,3,'en','name','Journal editor'),
(8,3,'en','abbrev','JE'),
(9,4,'','nameLocaleKey','default.groups.name.productionEditor'),
(10,4,'','abbrevLocaleKey','default.groups.abbrev.productionEditor'),
(11,4,'en','name','Production editor'),
(12,4,'en','abbrev','ProdE'),
(13,5,'','nameLocaleKey','default.groups.name.sectionEditor'),
(14,5,'','abbrevLocaleKey','default.groups.abbrev.sectionEditor'),
(15,5,'en','name','Section editor'),
(16,5,'en','abbrev','SecE'),
(17,6,'','nameLocaleKey','default.groups.name.guestEditor'),
(18,6,'','abbrevLocaleKey','default.groups.abbrev.guestEditor'),
(19,6,'en','name','Guest editor'),
(20,6,'en','abbrev','GE'),
(21,7,'','nameLocaleKey','default.groups.name.copyeditor'),
(22,7,'','abbrevLocaleKey','default.groups.abbrev.copyeditor'),
(23,7,'en','name','Copyeditor'),
(24,7,'en','abbrev','CE'),
(25,8,'','nameLocaleKey','default.groups.name.designer'),
(26,8,'','abbrevLocaleKey','default.groups.abbrev.designer'),
(27,8,'en','name','Designer'),
(28,8,'en','abbrev','Design'),
(29,9,'','nameLocaleKey','default.groups.name.funding'),
(30,9,'','abbrevLocaleKey','default.groups.abbrev.funding'),
(31,9,'en','name','Funding coordinator'),
(32,9,'en','abbrev','FC'),
(33,10,'','nameLocaleKey','default.groups.name.indexer'),
(34,10,'','abbrevLocaleKey','default.groups.abbrev.indexer'),
(35,10,'en','name','Indexer'),
(36,10,'en','abbrev','IND'),
(37,11,'','nameLocaleKey','default.groups.name.layoutEditor'),
(38,11,'','abbrevLocaleKey','default.groups.abbrev.layoutEditor'),
(39,11,'en','name','Layout Editor'),
(40,11,'en','abbrev','LE'),
(41,12,'','nameLocaleKey','default.groups.name.marketing'),
(42,12,'','abbrevLocaleKey','default.groups.abbrev.marketing'),
(43,12,'en','name','Marketing and sales coordinator'),
(44,12,'en','abbrev','MS'),
(45,13,'','nameLocaleKey','default.groups.name.proofreader'),
(46,13,'','abbrevLocaleKey','default.groups.abbrev.proofreader'),
(47,13,'en','name','Proofreader'),
(48,13,'en','abbrev','PR'),
(49,14,'','nameLocaleKey','default.groups.name.author'),
(50,14,'','abbrevLocaleKey','default.groups.abbrev.author'),
(51,14,'en','name','Author'),
(52,14,'en','abbrev','AU'),
(53,15,'','nameLocaleKey','default.groups.name.translator'),
(54,15,'','abbrevLocaleKey','default.groups.abbrev.translator'),
(55,15,'en','name','Translator'),
(56,15,'en','abbrev','Trans'),
(57,16,'','nameLocaleKey','default.groups.name.externalReviewer'),
(58,16,'','abbrevLocaleKey','default.groups.abbrev.externalReviewer'),
(59,16,'en','name','Reviewer'),
(60,16,'en','abbrev','R'),
(61,17,'','nameLocaleKey','default.groups.name.reader'),
(62,17,'','abbrevLocaleKey','default.groups.abbrev.reader'),
(63,17,'en','name','Reader'),
(64,17,'en','abbrev','Read'),
(65,18,'','nameLocaleKey','default.groups.name.subscriptionManager'),
(66,18,'','abbrevLocaleKey','default.groups.abbrev.subscriptionManager'),
(67,18,'en','name','Subscription Manager'),
(68,18,'en','abbrev','SubM'),
(69,19,'','nameLocaleKey','default.groups.name.editorialBoardMember'),
(70,19,'','abbrevLocaleKey','default.groups.abbrev.editorialBoardMember'),
(71,19,'en','name','Editorial Board Member'),
(72,19,'en','abbrev','EBM');
/*!40000 ALTER TABLE `user_group_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_stage`
--

DROP TABLE IF EXISTS `user_group_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group_stage` (
  `user_group_stage_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) NOT NULL,
  `user_group_id` bigint(20) NOT NULL,
  `stage_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_group_stage_id`),
  UNIQUE KEY `user_group_stage_unique` (`context_id`,`user_group_id`,`stage_id`),
  KEY `user_group_stage_context_id` (`context_id`),
  KEY `user_group_stage_user_group_id` (`user_group_id`),
  KEY `user_group_stage_stage_id` (`stage_id`),
  CONSTRAINT `user_group_stage_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `user_group_stage_user_group_id` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Which stages of the editorial workflow the user_groups can access.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_stage`
--

LOCK TABLES `user_group_stage` WRITE;
/*!40000 ALTER TABLE `user_group_stage` DISABLE KEYS */;
INSERT INTO `user_group_stage` VALUES
(1,1,3,1),
(2,1,3,3),
(3,1,3,4),
(4,1,3,5),
(5,1,4,4),
(6,1,4,5),
(7,1,5,1),
(8,1,5,3),
(9,1,5,4),
(10,1,5,5),
(11,1,6,1),
(12,1,6,3),
(13,1,6,4),
(14,1,6,5),
(15,1,7,4),
(16,1,8,5),
(17,1,9,1),
(18,1,9,3),
(19,1,10,5),
(20,1,11,5),
(21,1,12,4),
(22,1,13,5),
(23,1,14,1),
(24,1,14,3),
(25,1,14,4),
(26,1,14,5),
(27,1,15,1),
(28,1,15,3),
(29,1,15,4),
(30,1,15,5),
(31,1,16,3);
/*!40000 ALTER TABLE `user_group_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_groups` (
  `user_group_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `context_id` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) NOT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `show_title` smallint(6) NOT NULL DEFAULT 1,
  `permit_self_registration` smallint(6) NOT NULL DEFAULT 0,
  `permit_metadata_edit` smallint(6) NOT NULL DEFAULT 0,
  `permit_settings` smallint(6) NOT NULL DEFAULT 0,
  `masthead` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_group_id`),
  KEY `user_groups_context_id` (`context_id`),
  KEY `user_groups_user_group_id` (`user_group_id`),
  KEY `user_groups_role_id` (`role_id`),
  CONSTRAINT `user_groups_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='All defined user roles in a context, such as Author, Reviewer, Section Editor and Journal Manager.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` VALUES
(1,NULL,1,1,1,0,0,1,0),
(2,1,16,1,1,0,1,1,0),
(3,1,16,1,1,0,1,1,1),
(4,1,16,1,1,0,1,1,0),
(5,1,17,1,1,0,1,0,1),
(6,1,17,1,1,0,0,0,0),
(7,1,4097,1,1,0,0,0,0),
(8,1,4097,1,1,0,0,0,0),
(9,1,4097,1,1,0,0,0,0),
(10,1,4097,1,1,0,0,0,0),
(11,1,4097,1,1,0,0,0,0),
(12,1,4097,1,1,0,0,0,0),
(13,1,4097,1,1,0,0,0,0),
(14,1,65536,1,1,1,0,0,0),
(15,1,65536,1,1,0,0,0,0),
(16,1,4096,1,1,1,0,0,1),
(17,1,1048576,1,1,1,0,0,0),
(18,1,2097152,1,1,0,0,0,0),
(19,1,4097,1,1,0,0,0,1);
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_interests`
--

DROP TABLE IF EXISTS `user_interests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_interests` (
  `user_interest_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `controlled_vocab_entry_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_interest_id`),
  UNIQUE KEY `u_e_pkey` (`user_id`,`controlled_vocab_entry_id`),
  KEY `user_interests_user_id` (`user_id`),
  KEY `user_interests_controlled_vocab_entry_id` (`controlled_vocab_entry_id`),
  CONSTRAINT `user_interests_controlled_vocab_entry_id_foreign` FOREIGN KEY (`controlled_vocab_entry_id`) REFERENCES `controlled_vocab_entries` (`controlled_vocab_entry_id`) ON DELETE CASCADE,
  CONSTRAINT `user_interests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Associates users with user interests (which are stored in the controlled vocabulary tables).';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_interests`
--

LOCK TABLES `user_interests` WRITE;
/*!40000 ALTER TABLE `user_interests` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_interests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_settings` (
  `user_setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`user_setting_id`),
  UNIQUE KEY `user_settings_unique` (`user_id`,`locale`,`setting_name`),
  KEY `user_settings_user_id` (`user_id`),
  KEY `user_settings_locale_setting_name_index` (`setting_name`,`locale`),
  CONSTRAINT `user_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='More data about users, including localized properties like their name and affiliation.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_settings`
--

LOCK TABLES `user_settings` WRITE;
/*!40000 ALTER TABLE `user_settings` DISABLE KEYS */;
INSERT INTO `user_settings` VALUES
(1,1,'en','familyName','admin'),
(2,1,'en','givenName','admin'),
(55,101,'en','givenName','Margaret'),
(56,101,'en','familyName','Ellison'),
(57,101,'en','affiliation','Faculty of Veterinary Medicine, Northfield University'),
(58,101,'en','biography','<p>Professor of veterinary epidemiology.</p>'),
(59,102,'en','givenName','James'),
(60,102,'en','familyName','O’Connor'),
(61,102,'en','affiliation','School of Agriculture and Food Science, Eastbrook College'),
(62,103,'en','givenName','Alice'),
(63,103,'en','familyName','Thompson'),
(64,103,'en','affiliation','Department of Surgery, Riverside Veterinary School'),
(65,104,'en','givenName','Lucas'),
(66,104,'en','familyName','Fletcher'),
(67,104,'en','affiliation','Department of Animal Nutrition, Southgate University'),
(68,105,'en','givenName','Amelia'),
(69,105,'en','familyName','Dawson'),
(70,105,'en','affiliation','Institute of Livestock Research, Westfield University'),
(71,106,'en','givenName','Henry'),
(72,106,'en','familyName','Marshall'),
(73,106,'en','affiliation','Institute of Animal Welfare, Eastbrook College'),
(74,107,'en','givenName','Philippa'),
(75,107,'en','familyName','Nash'),
(76,107,'en','affiliation','Department of Veterinary Microbiology, Northfield University'),
(77,201,'en','givenName','Sarah'),
(78,201,'en','familyName','Mitchell'),
(79,201,'en','affiliation','Department of Animal Science, Northfield University'),
(80,201,'','profileImage','{\"name\":\"photo.png\",\"uploadName\":\"profileImage-201.png\",\"width\":150,\"height\":150,\"dateUploaded\":\"2026-06-01 10:00:00\"}'),
(81,211,'en','givenName','Peter'),
(82,211,'en','familyName','Lawson'),
(83,211,'en','affiliation','School of Veterinary Medicine, Westmoor University'),
(84,212,'en','givenName','Helen'),
(85,212,'en','familyName','Carter'),
(86,212,'en','affiliation','Department of Animal Health, Lakeside Agricultural College');
/*!40000 ALTER TABLE `user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_user_groups`
--

DROP TABLE IF EXISTS `user_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_user_groups` (
  `user_user_group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_group_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `masthead` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`user_user_group_id`),
  KEY `user_user_groups_user_group_id` (`user_group_id`),
  KEY `user_user_groups_user_id` (`user_id`),
  CONSTRAINT `user_user_groups_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE,
  CONSTRAINT `user_user_groups_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Maps users to their assigned user_groups.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_user_groups`
--

LOCK TABLES `user_user_groups` WRITE;
/*!40000 ALTER TABLE `user_user_groups` DISABLE KEYS */;
INSERT INTO `user_user_groups` VALUES
(1,1,1,'2026-09-25 16:09:14',NULL,NULL),
(2,2,1,NULL,NULL,NULL),
(19,3,101,'2026-01-01 00:00:00',NULL,1),
(20,5,102,'2026-01-01 00:00:00',NULL,1),
(21,5,103,'2026-01-01 00:00:00',NULL,1),
(22,19,104,'2026-01-01 00:00:00',NULL,1),
(23,19,105,'2026-01-01 00:00:00',NULL,1),
(24,19,106,'2026-01-01 00:00:00',NULL,1),
(25,19,107,'2026-01-01 00:00:00',NULL,1),
(26,14,201,NULL,NULL,0),
(27,16,211,NULL,NULL,0),
(28,16,212,NULL,NULL,0);
/*!40000 ALTER TABLE `user_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url` varchar(2047) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `mailing_address` varchar(255) DEFAULT NULL,
  `billing_address` varchar(255) DEFAULT NULL,
  `country` varchar(90) DEFAULT NULL,
  `locales` varchar(255) NOT NULL DEFAULT '[]',
  `gossip` text DEFAULT NULL,
  `date_last_email` datetime DEFAULT NULL,
  `date_registered` datetime NOT NULL,
  `date_validated` datetime DEFAULT NULL,
  `date_last_login` datetime DEFAULT NULL,
  `must_change_password` smallint(6) DEFAULT NULL,
  `auth_id` bigint(20) DEFAULT NULL,
  `auth_str` varchar(255) DEFAULT NULL,
  `disabled` smallint(6) NOT NULL DEFAULT 0,
  `disabled_reason` text DEFAULT NULL,
  `inline_help` smallint(6) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_username` (`username`),
  UNIQUE KEY `users_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='All registered users, including authentication data and profile data.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','$2y$12$4iDvoyxV1JYOlDeRVO4Zj.YB7A/HIU4M5c4EJjfFGZ.d0.4LlUZKO','admin@example.org',NULL,NULL,NULL,NULL,NULL,'[]',NULL,NULL,'2026-09-25 16:09:14',NULL,'2026-10-06 21:36:27',NULL,NULL,NULL,0,NULL,1,'5mO76hcjaJHWqdwHReqn5olgvlJ3uLJxF6uOPqujXGu3nEaWQ2GxxOJdTlAl'),
(101,'margaret.ellison','!disabled-demo-account','margaret.ellison@example.org',NULL,NULL,NULL,NULL,'GB','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53',NULL,NULL,NULL,NULL,0,NULL,1,NULL),
(102,'james.oconnor','!disabled-demo-account','james.oconnor@example.org',NULL,NULL,NULL,NULL,'IE','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53',NULL,NULL,NULL,NULL,0,NULL,1,NULL),
(103,'alice.thompson','!disabled-demo-account','alice.thompson@example.org',NULL,NULL,NULL,NULL,'US','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53',NULL,NULL,NULL,NULL,0,NULL,1,NULL),
(104,'lucas.fletcher','!disabled-demo-account','lucas.fletcher@example.org',NULL,NULL,NULL,NULL,'AU','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53',NULL,NULL,NULL,NULL,0,NULL,1,NULL),
(105,'amelia.dawson','!disabled-demo-account','amelia.dawson@example.org',NULL,NULL,NULL,NULL,'GB','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53',NULL,NULL,NULL,NULL,0,NULL,1,NULL),
(106,'henry.marshall','!disabled-demo-account','henry.marshall@example.org',NULL,NULL,NULL,NULL,'GB','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53',NULL,NULL,NULL,NULL,0,NULL,1,NULL),
(107,'philippa.nash','!disabled-demo-account','philippa.nash@example.org',NULL,NULL,NULL,NULL,'NZ','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53',NULL,NULL,NULL,NULL,0,NULL,1,NULL),
(201,'sarah.mitchell','$2y$10$3JRxr21Ax.2XAcCPOoPTpOBdVNZAYKtRqemwwHg1GP10gwoRD0xDW','sarah.mitchell@example.org','https://example.org/~mitchell',NULL,NULL,NULL,'GB','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53',NULL,NULL,NULL,NULL,0,NULL,1,NULL),
(211,'peter.lawson','$2y$12$XDrKeZxCeKAfnRMt0CHqxeKkZ1vse.d.QvGApvFjbpd886mVSbTSi','peter.lawson@example.org',NULL,NULL,NULL,NULL,'GB','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53','2026-10-06 21:38:27',NULL,NULL,NULL,0,NULL,1,'tszbB5iTFGWzXvHBnOp9p4Ot1F55IDCm8YpFgWzANS0ZrjlkZJqqmmGDhHF7'),
(212,'helen.carter','$2y$12$/l/dqZdmiLPXZzMI9nyMv.TvZSo7eKLYQqYaGp4hb.NPNOC6tkC6G','helen.carter@example.org',NULL,NULL,NULL,NULL,'CA','[]',NULL,NULL,'2026-10-06 21:05:53','2026-10-06 21:05:53','2026-10-06 21:08:14',NULL,NULL,NULL,0,NULL,1,'rFyu5Qb1yiavfVBbWLDT6AG5L1UpNxVU9BvMJDNWa01MlvISONXNPe6XjRGZ');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `versions` (
  `version_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `major` int(11) NOT NULL DEFAULT 0 COMMENT 'Major component of version number, e.g. the 2 in OJS 2.3.8-0',
  `minor` int(11) NOT NULL DEFAULT 0 COMMENT 'Minor component of version number, e.g. the 3 in OJS 2.3.8-0',
  `revision` int(11) NOT NULL DEFAULT 0 COMMENT 'Revision component of version number, e.g. the 8 in OJS 2.3.8-0',
  `build` int(11) NOT NULL DEFAULT 0 COMMENT 'Build component of version number, e.g. the 0 in OJS 2.3.8-0',
  `date_installed` datetime NOT NULL,
  `current` smallint(6) NOT NULL DEFAULT 0 COMMENT '1 iff the version entry being described is currently active. This permits the table to store past installation history for forensic purposes.',
  `product_type` varchar(30) DEFAULT NULL COMMENT 'Describes the type of product this row describes, e.g. "plugins.generic" (for a generic plugin) or "core" for the application itself',
  `product` varchar(30) DEFAULT NULL COMMENT 'Uniquely identifies the product this version row describes, e.g. "ojs2" for OJS 2.x, "languageToggle" for the language toggle block plugin, etc.',
  `product_class_name` varchar(80) DEFAULT NULL COMMENT 'Specifies the class name associated with this product, for plugins, or the empty string where not applicable.',
  `lazy_load` smallint(6) NOT NULL DEFAULT 0 COMMENT '1 iff the row describes a lazy-load plugin; 0 otherwise',
  `sitewide` smallint(6) NOT NULL DEFAULT 0 COMMENT '1 iff the row describes a site-wide plugin; 0 otherwise',
  PRIMARY KEY (`version_id`),
  UNIQUE KEY `versions_unique` (`product_type`,`product`,`major`,`minor`,`revision`,`build`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Describes the installation and upgrade version history for the application and all installed plugins.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
INSERT INTO `versions` VALUES
(1,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.metadata','dc11','',0,0),
(2,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.blocks','makeSubmission','MakeSubmissionBlockPlugin',1,0),
(3,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.blocks','languageToggle','LanguageToggleBlockPlugin',1,0),
(4,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.blocks','developedBy','DevelopedByBlockPlugin',1,0),
(5,1,0,1,0,'2026-09-25 16:09:15',1,'plugins.blocks','browse','BrowseBlockPlugin',1,0),
(6,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.blocks','information','InformationBlockPlugin',1,0),
(7,1,1,0,0,'2026-09-25 16:09:15',1,'plugins.blocks','subscription','SubscriptionBlockPlugin',1,0),
(8,1,2,1,4,'2026-09-25 16:09:15',1,'plugins.generic','pflPlugin','PflPlugin',1,0),
(9,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','htmlArticleGalley','HtmlArticleGalleyPlugin',1,0),
(10,3,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','crossref','CrossrefPlugin',0,0),
(11,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','driver','DRIVERPlugin',1,0),
(12,1,2,0,0,'2026-09-25 16:09:15',1,'plugins.generic','customBlockManager','CustomBlockManagerPlugin',1,0),
(13,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','usageEvent','',0,0),
(14,1,2,0,0,'2026-09-25 16:09:15',1,'plugins.generic','credit','CreditPlugin',1,0),
(15,1,1,0,0,'2026-09-25 16:09:15',1,'plugins.generic','googleScholar','GoogleScholarPlugin',1,0),
(16,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','recommendBySimilarity','RecommendBySimilarityPlugin',1,1),
(17,1,2,0,0,'2026-09-25 16:09:15',1,'plugins.generic','staticPages','StaticPagesPlugin',1,0),
(18,1,0,1,0,'2026-09-25 16:09:15',1,'plugins.generic','pdfJsViewer','PdfJsViewerPlugin',1,0),
(19,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','tinymce','TinyMCEPlugin',1,0),
(20,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','googleAnalytics','GoogleAnalyticsPlugin',1,0),
(21,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','announcementFeed','AnnouncementFeedPlugin',1,0),
(22,1,0,8,0,'2026-09-25 16:09:15',1,'plugins.generic','jatsTemplate','JatsTemplatePlugin',1,0),
(23,1,0,1,0,'2026-09-25 16:09:15',1,'plugins.generic','lensGalley','LensGalleyPlugin',1,0),
(24,2,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','datacite','DatacitePlugin',0,0),
(25,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','webFeed','WebFeedPlugin',1,0),
(26,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','dublinCoreMeta','DublinCoreMetaPlugin',1,0),
(27,1,0,0,1,'2026-09-25 16:09:15',1,'plugins.generic','recommendByAuthor','RecommendByAuthorPlugin',1,1),
(28,0,1,0,0,'2026-09-25 16:09:15',1,'plugins.generic','citationStyleLanguage','CitationStyleLanguagePlugin',1,0),
(29,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','authorPages','AuthorPagesPlugin',1,0),
(30,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.generic','scholarlyReader','ScholarlyReaderPlugin',1,0),
(31,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.importexport','users','',0,0),
(32,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.importexport','pubmed','',0,0),
(33,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.importexport','native','',0,0),
(34,1,1,0,0,'2026-09-25 16:09:15',1,'plugins.importexport','doaj','',0,0),
(35,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.oaiMetadataFormats','rfc1807','',0,0),
(36,1,0,6,1,'2026-09-25 16:09:15',1,'plugins.oaiMetadataFormats','oaiJats','',0,0),
(37,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.oaiMetadataFormats','marc','',0,0),
(38,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.oaiMetadataFormats','dc','',0,0),
(39,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.oaiMetadataFormats','marcxml','',0,0),
(40,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.paymethod','paypal','',0,0),
(41,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.paymethod','manual','',0,0),
(42,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.pubIds','urn','URNPubIdPlugin',1,0),
(43,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.reports','articles','',0,0),
(44,2,0,1,0,'2026-09-25 16:09:15',1,'plugins.reports','reviewReport','',0,0),
(45,1,1,0,0,'2026-09-25 16:09:15',1,'plugins.reports','counterReport','',0,0),
(46,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.reports','subscriptions','',0,0),
(47,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.themes','default','DefaultThemePlugin',1,0),
(48,1,0,0,0,'2026-09-25 16:09:15',1,'plugins.themes','meridian','MeridianPlugin',1,0),
(49,3,5,0,5,'2026-09-25 16:09:11',1,'core','ojs2','',0,1),
(50,1,0,0,0,'2026-09-25 17:47:54',1,'plugins.generic','meridianAdmin','MeridianAdminPlugin',0,1),
(51,1,0,0,0,'2026-10-06 21:05:28',1,'plugins.generic','reviewDecline','ReviewDeclinePlugin',0,1),
(52,1,0,0,0,'2026-10-06 21:22:42',1,'plugins.generic','readership','ReadershipPlugin',0,1);
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'ojs'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed
